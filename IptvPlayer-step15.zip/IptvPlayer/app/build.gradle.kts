plugins {
    alias(libs.plugins.android.application); alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose); alias(libs.plugins.ksp); alias(libs.plugins.hilt)
}
android {
    namespace = "app.iptv.player"
    compileSdk = 34
    defaultConfig {
        applicationId = "app.iptv.player"
        minSdk = 21; targetSdk = 34
        versionCode = 1; versionName = "1.0.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = true; isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    buildFeatures { compose = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(project(":core:domain")); implementation(project(":core:data"))
    implementation(project(":feature:livetv")); implementation(project(":feature:vod")); implementation(project(":feature:series"))
    implementation(project(":feature:epg")); implementation(project(":feature:player")); implementation(project(":feature:settings")); implementation(project(":feature:search")); implementation(project(":feature:recordings"))
    implementation(libs.androidx.core.ktx); implementation(libs.androidx.activity.compose)
    implementation(platform(libs.compose.bom)); implementation(libs.compose.ui); implementation(libs.compose.ui.tooling.preview)
    implementation(libs.compose.material3); implementation(libs.tv.material); implementation(libs.compose.material.icons)
    debugImplementation(libs.compose.ui.tooling)
    implementation(libs.navigation.compose); implementation(libs.androidx.lifecycle.runtime)
    implementation(libs.hilt.android); ksp(libs.hilt.compiler); implementation(libs.hilt.navigation.compose)
    implementation(libs.work.runtime); implementation(libs.coil.compose)
    implementation(project(":core:ui")); implementation(libs.paging.compose)
}
