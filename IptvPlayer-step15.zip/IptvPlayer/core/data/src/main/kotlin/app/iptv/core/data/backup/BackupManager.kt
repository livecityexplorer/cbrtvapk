package app.iptv.core.data.backup

import app.iptv.core.domain.model.*
import app.iptv.core.domain.repository.*
import app.iptv.core.domain.validation.PlaylistValidator
import kotlinx.coroutines.flow.first
import kotlinx.serialization.Serializable
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

@Serializable
internal data class BackupFile(
    val format: String = FORMAT, val version: Int = 1, val exportedAt: Long = 0,
    val settings: BackupSettings = BackupSettings(), val playlists: List<BackupPlaylist> = emptyList()
) { companion object { const val FORMAT = "iptv-player-backup" } }

/** Enums are stored by name so older/newer files degrade to defaults instead of failing. The PIN is never exported. */
@Serializable
internal data class BackupSettings(
    val theme: String? = null, val epgAutoRefresh: Boolean? = null, val epgIntervalHours: Int? = null,
    val bufferSize: String? = null, val decoder: String? = null, val defaultAspect: String? = null,
    val subtitleSizeSp: Int? = null, val subtitleColor: String? = null, val hideAdult: Boolean? = null
)

@Serializable
internal data class BackupPlaylist(
    val name: String, val type: String, val url: String, val username: String? = null,
    val password: String? = null, val macAddress: String? = null, val epgUrls: List<String> = emptyList()
)

@Singleton
class BackupManager @Inject constructor(
    private val prefs: PreferencesRepository,
    private val playlists: PlaylistRepository
) : BackupRepository {

    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true; encodeDefaults = true }

    override suspend fun export(): String {
        val s = prefs.settings.first()
        val file = BackupFile(
            exportedAt = System.currentTimeMillis(),
            settings = BackupSettings(
                s.theme.name, s.epgAutoRefresh, s.epgIntervalHours, s.bufferSize.name, s.decoder.name,
                s.defaultAspect.name, s.subtitleSizeSp, s.subtitleColor.name, s.hideAdult
            ),
            playlists = playlists.observeAll().first().map {
                BackupPlaylist(it.name, it.type.name, it.url, it.username, it.password, it.macAddress, it.epgUrls)
            }
        )
        return json.encodeToString(BackupFile.serializer(), file)
    }

    override suspend fun import(json: String): ImportResult {
        val file = try { this.json.decodeFromString(BackupFile.serializer(), json) }
        catch (e: SerializationException) { throw IllegalArgumentException("This is not a valid backup file.") }
        catch (e: IllegalArgumentException) { throw IllegalArgumentException("This is not a valid backup file.") }
        require(file.format == BackupFile.FORMAT) { "This is not an IPTV Player backup." }
        require(file.version <= 1) { "This backup was made by a newer version of the app." }

        val existing = playlists.observeAll().first()
        var added = 0; var skipped = 0
        for (p in file.playlists) {
            val type = PlaylistType.entries.firstOrNull { it.name == p.type }
            if (type == null || p.name.isBlank() || p.url.isBlank()) { skipped++; continue }
            val duplicate = existing.any { it.type == type && it.url == p.url && it.username == p.username && it.macAddress == p.macAddress }
            if (duplicate) { skipped++; continue }
            val candidate = Playlist(name = p.name, type = type, url = p.url, username = p.username, password = p.password, macAddress = p.macAddress, epgUrls = p.epgUrls)
            if (PlaylistValidator.validate(candidate).isNotEmpty()) { skipped++; continue }
            playlists.save(candidate)
            added++
        }
        val b = file.settings
        prefs.updateSettings { cur ->
            cur.copy(
                theme = b.theme.asEnum(cur.theme),
                epgAutoRefresh = b.epgAutoRefresh ?: cur.epgAutoRefresh,
                epgIntervalHours = b.epgIntervalHours?.takeIf { it >= 1 } ?: cur.epgIntervalHours,
                bufferSize = b.bufferSize.asEnum(cur.bufferSize),
                decoder = b.decoder.asEnum(cur.decoder),
                defaultAspect = b.defaultAspect.asEnum(cur.defaultAspect),
                subtitleSizeSp = b.subtitleSizeSp?.coerceIn(AppSettings.SUBTITLE_MIN_SP, AppSettings.SUBTITLE_MAX_SP) ?: cur.subtitleSizeSp,
                subtitleColor = b.subtitleColor.asEnum(cur.subtitleColor),
                hideAdult = b.hideAdult ?: cur.hideAdult
            )
        }
        return ImportResult(added, skipped, settingsRestored = true)
    }

    private inline fun <reified E : Enum<E>> String?.asEnum(default: E): E =
        this?.let { n -> enumValues<E>().firstOrNull { it.name == n } } ?: default
}
