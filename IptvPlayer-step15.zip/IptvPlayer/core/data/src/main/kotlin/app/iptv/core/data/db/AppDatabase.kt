package app.iptv.core.data.db

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import app.iptv.core.data.db.dao.*

@Database(
    entities = [
        PlaylistEntity::class, CategoryEntity::class, ChannelEntity::class, EpgProgramEntity::class,
        FavoriteEntity::class, WatchHistoryEntity::class, RecordingEntity::class,
        MovieEntity::class, SeriesEntity::class, EpisodeEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun playlistDao(): PlaylistDao
    abstract fun categoryDao(): CategoryDao
    abstract fun channelDao(): ChannelDao
    abstract fun epgDao(): EpgDao
    abstract fun favoriteDao(): FavoriteDao
    abstract fun watchHistoryDao(): WatchHistoryDao
    abstract fun recordingDao(): RecordingDao
    abstract fun vodDao(): VodDao
    abstract fun searchDao(): SearchDao

    companion object { const val NAME = "iptv.db" }
}

/**
 * Schema v1 is the baseline, so there are no migrations yet. When bumping `version`, add a
 * `Migration(from, to)` here; the database is never wiped on upgrade (no destructive fallback).
 */
object Migrations {
    val ALL: Array<Migration> = emptyArray()
}
