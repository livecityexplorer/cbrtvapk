package app.iptv.core.data.db

import androidx.room.*
import app.iptv.core.domain.model.*

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, val type: PlaylistType, val url: String,
    val username: String?, val password: String?, val macAddress: String?,
    val epgUrls: String, val lastRefresh: Long
)

@Entity(
    tableName = "categories",
    foreignKeys = [ForeignKey(entity = PlaylistEntity::class, parentColumns = ["id"], childColumns = ["playlistId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["playlistId", "kind", "remoteId"], unique = true)]
)
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long, val remoteId: String, val name: String, val kind: CategoryKind,
    val sortOrder: Int, val isHidden: Boolean, val isLocked: Boolean, val lastSeen: Long
)

@Entity(
    tableName = "channels",
    foreignKeys = [
        ForeignKey(entity = PlaylistEntity::class, parentColumns = ["id"], childColumns = ["playlistId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = CategoryEntity::class, parentColumns = ["id"], childColumns = ["categoryId"], onDelete = ForeignKey.SET_NULL)
    ],
    indices = [Index(value = ["playlistId", "remoteId"], unique = true), Index("categoryId"), Index("tvgId"), Index("name")]
)
data class ChannelEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long, val categoryId: Long?, val remoteId: String, val name: String,
    val logoUrl: String?, val tvgId: String?, val tvgName: String?, val streamUrl: String,
    val number: Int, val archiveDays: Int, val sortOrder: Int, val isLocked: Boolean, val lastSeen: Long
)

@Entity(
    tableName = "epg_programs",
    indices = [Index(value = ["channelTvgId", "startTime"], unique = true), Index("endTime")]
)
data class EpgProgramEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val channelTvgId: String, val title: String, val description: String?,
    val startTime: Long, val endTime: Long, val posterUrl: String?
)

@Entity(
    tableName = "favorites",
    foreignKeys = [ForeignKey(entity = ChannelEntity::class, parentColumns = ["id"], childColumns = ["channelId"], onDelete = ForeignKey.CASCADE)]
)
data class FavoriteEntity(@PrimaryKey val channelId: Long, val addedAt: Long)

@Entity(
    tableName = "watch_history",
    foreignKeys = [ForeignKey(entity = PlaylistEntity::class, parentColumns = ["id"], childColumns = ["playlistId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["type", "contentKey"], unique = true), Index("playlistId"), Index("updatedAt")]
)
data class WatchHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: ContentType, val contentKey: String, val playlistId: Long,
    val title: String, val imageUrl: String?, val streamUrl: String,
    val positionMs: Long, val durationMs: Long, val updatedAt: Long
)

@Entity(tableName = "recordings", indices = [Index("startTime"), Index("status")])
data class RecordingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val channelId: Long?, val channelName: String, val title: String, val streamUrl: String,
    val startTime: Long, val endTime: Long, val status: RecordingStatus,
    val filePath: String?, val sizeBytes: Long
)

@Entity(
    tableName = "movies",
    foreignKeys = [ForeignKey(entity = PlaylistEntity::class, parentColumns = ["id"], childColumns = ["playlistId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["playlistId", "remoteId"], unique = true), Index("categoryId"), Index("name")]
)
data class MovieEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long, val categoryId: Long?, val remoteId: String, val name: String,
    val posterUrl: String?, val plot: String?, val year: String?, val rating: Float?, val castText: String?,
    val streamUrl: String, val addedAt: Long, val lastSeen: Long
)

@Entity(
    tableName = "series",
    foreignKeys = [ForeignKey(entity = PlaylistEntity::class, parentColumns = ["id"], childColumns = ["playlistId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["playlistId", "remoteId"], unique = true), Index("categoryId"), Index("name")]
)
data class SeriesEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long, val categoryId: Long?, val remoteId: String, val name: String,
    val posterUrl: String?, val plot: String?, val year: String?, val rating: Float?, val castText: String?,
    val addedAt: Long, val lastSeen: Long
)

@Entity(
    tableName = "episodes",
    foreignKeys = [ForeignKey(entity = SeriesEntity::class, parentColumns = ["id"], childColumns = ["seriesId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["seriesId", "season", "episodeNum"], unique = true)]
)
data class EpisodeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val seriesId: Long, val season: Int, val episodeNum: Int, val title: String,
    val plot: String?, val imageUrl: String?, val streamUrl: String, val durationSecs: Int
)

/** Lightweight projections used to preserve user data and ids during refresh. */
data class ChannelKeep(val id: Long, val remoteId: String, val sortOrder: Int, val isLocked: Boolean)
data class CategoryKeep(val id: Long, val remoteId: String, val sortOrder: Int, val isHidden: Boolean, val isLocked: Boolean)
data class IdKey(val id: Long, val remoteId: String)

data class CategoryName(val id: Long, val name: String)
