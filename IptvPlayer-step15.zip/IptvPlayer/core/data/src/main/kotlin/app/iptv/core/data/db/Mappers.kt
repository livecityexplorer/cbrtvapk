package app.iptv.core.data.db

import app.iptv.core.domain.model.*

fun PlaylistEntity.toDomain() = Playlist(
    id, name, type, url, username, password, macAddress,
    epgUrls.split('\n').map { it.trim() }.filter { it.isNotEmpty() }, lastRefresh
)
fun Playlist.toEntity() = PlaylistEntity(
    id, name, type, url, username, password, macAddress, epgUrls.joinToString("\n"), lastRefresh
)

fun CategoryEntity.toDomain() = Category(id, playlistId, remoteId, name, kind, sortOrder, isHidden, isLocked)

fun ChannelEntity.toDomain() = Channel(
    id, playlistId, categoryId, remoteId, name, logoUrl, tvgId, tvgName, streamUrl, number, archiveDays, sortOrder, isLocked
)

fun EpgProgramEntity.toDomain() = EpgProgram(id, channelTvgId, title, description, startTime, endTime, posterUrl)
fun EpgProgram.toEntity() = EpgProgramEntity(id, channelTvgId, title, description, startTime, endTime, posterUrl)

fun MovieEntity.toDomain() = Movie(id, playlistId, categoryId, remoteId, name, posterUrl, plot, year, rating, castText, streamUrl, addedAt)
fun SeriesEntity.toDomain() = Series(id, playlistId, categoryId, remoteId, name, posterUrl, plot, year, rating, castText, addedAt)
fun EpisodeEntity.toDomain() = Episode(id, seriesId, season, episodeNum, title, plot, imageUrl, streamUrl, durationSecs)

fun WatchHistoryEntity.toDomain() = WatchHistory(id, type, contentKey, playlistId, title, imageUrl, streamUrl, positionMs, durationMs, updatedAt)
fun WatchHistory.toEntity() = WatchHistoryEntity(id, type, contentKey, playlistId, title, imageUrl, streamUrl, positionMs, durationMs, updatedAt)

fun RecordingEntity.toDomain() = Recording(id, channelId, channelName, title, streamUrl, startTime, endTime, status, filePath, sizeBytes)
fun Recording.toEntity() = RecordingEntity(id, channelId, channelName, title, streamUrl, startTime, endTime, status, filePath, sizeBytes)
