package app.iptv.core.data.db.dao

import androidx.paging.PagingSource
import androidx.room.*
import app.iptv.core.data.db.*
import app.iptv.core.domain.model.CategoryKind
import app.iptv.core.domain.model.ContentType
import app.iptv.core.domain.model.RecordingStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY name COLLATE NOCASE") fun observeAll(): Flow<List<PlaylistEntity>>
    @Query("SELECT * FROM playlists WHERE id = :id") suspend fun get(id: Long): PlaylistEntity?
    @Insert suspend fun insert(entity: PlaylistEntity): Long
    @Update suspend fun update(entity: PlaylistEntity)
    @Query("DELETE FROM playlists WHERE id = :id") suspend fun delete(id: Long)
    @Query("UPDATE playlists SET lastRefresh = :ts WHERE id = :id") suspend fun markRefreshed(id: Long, ts: Long)
}

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories WHERE playlistId = :playlistId AND kind = :kind ORDER BY sortOrder, name COLLATE NOCASE")
    fun observe(playlistId: Long, kind: CategoryKind): Flow<List<CategoryEntity>>
    @Query("SELECT id, remoteId, sortOrder, isHidden, isLocked FROM categories WHERE playlistId = :playlistId AND kind = :kind")
    suspend fun keys(playlistId: Long, kind: CategoryKind): List<CategoryKeep>
    @Upsert suspend fun upsertAll(list: List<CategoryEntity>)
    @Query("DELETE FROM categories WHERE playlistId = :playlistId AND kind = :kind AND lastSeen < :ts")
    suspend fun deleteStale(playlistId: Long, kind: CategoryKind, ts: Long)
    @Query("UPDATE categories SET isHidden = :hidden WHERE id = :id") suspend fun setHidden(id: Long, hidden: Boolean)
    @Query("UPDATE categories SET isLocked = :locked WHERE id = :id") suspend fun setLocked(id: Long, locked: Boolean)
    @Query("SELECT isLocked FROM categories WHERE id = :id") suspend fun isLocked(id: Long): Boolean?
    @Query("SELECT id, name FROM categories") suspend fun idsAndNames(): List<CategoryName>
}

@Dao
interface ChannelDao {
    @Query(
        """SELECT * FROM channels WHERE playlistId = :playlistId
           AND (:categoryId IS NULL OR categoryId = :categoryId)
           AND (:query = '' OR name LIKE '%' || :query || '%')
           AND (categoryId IS NULL OR categoryId NOT IN (SELECT id FROM categories WHERE isHidden = 1))
           ORDER BY sortOrder, number, name COLLATE NOCASE"""
    )
    fun paging(playlistId: Long, categoryId: Long?, query: String): PagingSource<Int, ChannelEntity>

    @Query("SELECT c.* FROM channels c INNER JOIN favorites f ON f.channelId = c.id ORDER BY f.addedAt DESC")
    fun observeFavorites(): Flow<List<ChannelEntity>>

    @Query(
        """SELECT c.* FROM channels c INNER JOIN watch_history h
           ON h.type = 'CHANNEL' AND h.contentKey = CAST(c.id AS TEXT)
           ORDER BY h.updatedAt DESC LIMIT :limit"""
    )
    fun observeRecent(limit: Int): Flow<List<ChannelEntity>>

    /** Same ordering as [paging]; used to renumber sortOrder when the user moves a channel. */
    @Query(
        """SELECT id FROM channels WHERE playlistId = :playlistId AND (:categoryId IS NULL OR categoryId = :categoryId)
           ORDER BY sortOrder, number, name COLLATE NOCASE"""
    )
    suspend fun orderedIds(playlistId: Long, categoryId: Long?): List<Long>

    @Query("SELECT * FROM channels WHERE id = :id") suspend fun get(id: Long): ChannelEntity?
    @Query("SELECT id, remoteId, tvgId, tvgName, name FROM channels WHERE playlistId = :playlistId")
    suspend fun epgChannels(playlistId: Long): List<EpgChannelRow>
    @Query("SELECT * FROM channels WHERE name LIKE '%' || :query || '%' ORDER BY name COLLATE NOCASE LIMIT :limit")
    suspend fun search(query: String, limit: Int): List<ChannelEntity>
    @Query("SELECT id, remoteId, sortOrder, isLocked FROM channels WHERE playlistId = :playlistId")
    suspend fun keys(playlistId: Long): List<ChannelKeep>
    @Upsert suspend fun upsertAll(list: List<ChannelEntity>)
    @Query("DELETE FROM channels WHERE playlistId = :playlistId AND lastSeen < :ts") suspend fun deleteStale(playlistId: Long, ts: Long)
    @Query("UPDATE channels SET sortOrder = :order WHERE id = :id") suspend fun setOrder(id: Long, order: Int)
    @Query("UPDATE channels SET isLocked = :locked WHERE id = :id") suspend fun setLocked(id: Long, locked: Boolean)
}

@Dao
interface EpgDao {
    @Query(
        """SELECT * FROM epg_programs WHERE channelTvgId IN (:tvgIds) AND endTime > :from AND startTime < :to
           ORDER BY channelTvgId, startTime"""
    )
    fun observeRange(tvgIds: List<String>, from: Long, to: Long): Flow<List<EpgProgramEntity>>
    @Query("SELECT * FROM epg_programs WHERE channelTvgId = :tvgId AND endTime > :now ORDER BY startTime LIMIT 2")
    suspend fun nowAndNext(tvgId: String, now: Long): List<EpgProgramEntity>
    // REPLACE (not @Upsert): the unique key is (channel, start), so a re-import must overwrite changed titles.
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(list: List<EpgProgramEntity>)
    @Query("SELECT * FROM epg_programs WHERE channelTvgId = :tvgId AND endTime > :now ORDER BY startTime LIMIT 2")
    fun observeNowAndNext(tvgId: String, now: Long): Flow<List<EpgProgramEntity>>
    @Query("DELETE FROM epg_programs WHERE endTime < :ts") suspend fun deleteEndedBefore(ts: Long)
    @Query("SELECT * FROM epg_programs WHERE title LIKE '%' || :query || '%' AND endTime > :now ORDER BY startTime LIMIT :limit")
    suspend fun search(query: String, now: Long, limit: Int): List<EpgProgramEntity>
}

@Dao
interface FavoriteDao {
    @Query("SELECT channelId FROM favorites") fun observeIds(): Flow<List<Long>>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insert(entity: FavoriteEntity)
    @Query("DELETE FROM favorites WHERE channelId = :channelId") suspend fun delete(channelId: Long)
}

@Dao
interface WatchHistoryDao {
    @Query("SELECT * FROM watch_history WHERE type = :type AND contentKey = :key") suspend fun find(type: ContentType, key: String): WatchHistoryEntity?
    @Upsert suspend fun upsert(entity: WatchHistoryEntity)
    @Query("SELECT * FROM watch_history WHERE type = :type AND contentKey = :key LIMIT 1") fun observe(type: ContentType, key: String): Flow<WatchHistoryEntity?>
    @Query("SELECT * FROM watch_history WHERE type = :type") fun observeByType(type: ContentType): Flow<List<WatchHistoryEntity>>
    @Query(
        """SELECT * FROM watch_history WHERE type != 'CHANNEL' AND durationMs > 0 AND positionMs > 0
           AND positionMs < durationMs * 0.95 ORDER BY updatedAt DESC LIMIT :limit"""
    )
    fun observeContinueWatching(limit: Int): Flow<List<WatchHistoryEntity>>
    @Query("DELETE FROM watch_history WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM watch_history") suspend fun clear()
}

@Dao
interface RecordingDao {
    @Query("SELECT * FROM recordings ORDER BY startTime DESC") fun observeAll(): Flow<List<RecordingEntity>>
    @Query("SELECT * FROM recordings WHERE id = :id") suspend fun get(id: Long): RecordingEntity?
    @Upsert suspend fun upsert(entity: RecordingEntity): Long
    @Query("DELETE FROM recordings WHERE id = :id") suspend fun delete(id: Long)
    @Query("UPDATE recordings SET status = :status, filePath = :filePath WHERE id = :id") suspend fun updateStatus(id: Long, status: RecordingStatus, filePath: String?)
    @Query("UPDATE recordings SET sizeBytes = :size WHERE id = :id") suspend fun updateProgress(id: Long, size: Long)
    @Query("SELECT * FROM recordings WHERE status = :status AND startTime <= :now AND endTime > :now")
    suspend fun due(now: Long, status: RecordingStatus = RecordingStatus.SCHEDULED): List<RecordingEntity>
}

@Dao
interface VodDao {
    @Query(
        """SELECT * FROM movies WHERE playlistId = :playlistId AND (:categoryId IS NULL OR categoryId = :categoryId)
           AND (:query = '' OR name LIKE '%' || :query || '%')
           AND (categoryId IS NULL OR categoryId NOT IN (SELECT id FROM categories WHERE isHidden = 1))
           ORDER BY name COLLATE NOCASE"""
    )
    fun moviesPaging(playlistId: Long, categoryId: Long?, query: String): PagingSource<Int, MovieEntity>
    @Query(
        """SELECT * FROM series WHERE playlistId = :playlistId AND (:categoryId IS NULL OR categoryId = :categoryId)
           AND (:query = '' OR name LIKE '%' || :query || '%')
           AND (categoryId IS NULL OR categoryId NOT IN (SELECT id FROM categories WHERE isHidden = 1))
           ORDER BY name COLLATE NOCASE"""
    )
    fun seriesPaging(playlistId: Long, categoryId: Long?, query: String): PagingSource<Int, SeriesEntity>
    @Query(
        """SELECT * FROM movies WHERE playlistId = :playlistId
           AND (categoryId IS NULL OR categoryId NOT IN (SELECT id FROM categories WHERE isHidden = 1))
           ORDER BY addedAt DESC, id DESC LIMIT :limit"""
    )
    fun recentMovies(playlistId: Long, limit: Int): Flow<List<MovieEntity>>
    @Query(
        """SELECT * FROM series WHERE playlistId = :playlistId
           AND (categoryId IS NULL OR categoryId NOT IN (SELECT id FROM categories WHERE isHidden = 1))
           ORDER BY addedAt DESC, id DESC LIMIT :limit"""
    )
    fun recentSeries(playlistId: Long, limit: Int): Flow<List<SeriesEntity>>

    @Query("SELECT * FROM movies WHERE id = :id") suspend fun movie(id: Long): MovieEntity?
    @Query("SELECT * FROM movies WHERE id = :id") fun observeMovie(id: Long): Flow<MovieEntity?>
    @Query("SELECT * FROM series WHERE id = :id") fun observeSeries(id: Long): Flow<SeriesEntity?>
    @Query("SELECT * FROM episodes WHERE id = :id") suspend fun episode(id: Long): EpisodeEntity?
    @Query("SELECT * FROM series WHERE id = :id") suspend fun seriesById(id: Long): SeriesEntity?
    @Query("SELECT * FROM movies WHERE name LIKE '%' || :q || '%' ORDER BY name COLLATE NOCASE LIMIT :limit")
    suspend fun searchMovies(q: String, limit: Int): List<MovieEntity>
    @Query("SELECT * FROM series WHERE name LIKE '%' || :q || '%' ORDER BY name COLLATE NOCASE LIMIT :limit")
    suspend fun searchSeries(q: String, limit: Int): List<SeriesEntity>

    @Query("SELECT id, remoteId FROM movies WHERE playlistId = :p") suspend fun movieKeys(p: Long): List<IdKey>
    @Query("SELECT id, remoteId FROM series WHERE playlistId = :p") suspend fun seriesKeys(p: Long): List<IdKey>
    @Upsert suspend fun upsertMovies(list: List<MovieEntity>)
    @Upsert suspend fun upsertSeries(list: List<SeriesEntity>)
    @Query("DELETE FROM movies WHERE playlistId = :p AND lastSeen < :ts") suspend fun deleteStaleMovies(p: Long, ts: Long)
    @Query("DELETE FROM series WHERE playlistId = :p AND lastSeen < :ts") suspend fun deleteStaleSeries(p: Long, ts: Long)
    @Query("UPDATE movies SET plot = :plot, castText = :cast, year = :year, rating = :rating WHERE id = :id")
    suspend fun updateMovieDetail(id: Long, plot: String?, cast: String?, year: String?, rating: Float?)
    @Query("UPDATE series SET plot = :plot, castText = :cast, year = :year, rating = :rating WHERE id = :id")
    suspend fun updateSeriesDetail(id: Long, plot: String?, cast: String?, year: String?, rating: Float?)

    @Query("SELECT * FROM episodes WHERE seriesId = :seriesId ORDER BY season, episodeNum")
    fun observeEpisodes(seriesId: Long): Flow<List<EpisodeEntity>>
    @Upsert suspend fun upsertEpisodes(list: List<EpisodeEntity>)
    @Query("SELECT id, season, episodeNum FROM episodes WHERE seriesId = :seriesId")
    suspend fun episodeKeys(seriesId: Long): List<EpisodeKey>
}

data class EpisodeKey(val id: Long, val season: Int, val episodeNum: Int)

data class EpgChannelRow(val id: Long, val remoteId: String, val tvgId: String?, val tvgName: String?, val name: String)
