package app.iptv.core.data.db.dao

import androidx.room.Dao
import androidx.room.Query
import app.iptv.core.data.db.ChannelEntity
import app.iptv.core.data.db.EpgProgramEntity
import app.iptv.core.data.db.MovieEntity
import app.iptv.core.data.db.SeriesEntity

/**
 * Every term (:t1..:t3, LIKE-escaped with backslash; '' matches all) must occur in the title.
 * Prefix matches on the first term sort first. Titles in hidden categories are excluded.
 * Note: SQLite's LIKE ignores case only for ASCII letters.
 */
@Dao
interface SearchDao {
    @Query(
        """SELECT * FROM channels WHERE playlistId = :playlistId
           AND name LIKE '%' || :t1 || '%' ESCAPE '\' AND name LIKE '%' || :t2 || '%' ESCAPE '\' AND name LIKE '%' || :t3 || '%' ESCAPE '\'
           AND (categoryId IS NULL OR categoryId NOT IN (SELECT id FROM categories WHERE isHidden = 1))
           ORDER BY CASE WHEN name LIKE :t1 || '%' ESCAPE '\' THEN 0 ELSE 1 END, name COLLATE NOCASE LIMIT :limit"""
    )
    suspend fun channels(playlistId: Long, t1: String, t2: String, t3: String, limit: Int): List<ChannelEntity>

    @Query(
        """SELECT * FROM movies WHERE playlistId = :playlistId
           AND name LIKE '%' || :t1 || '%' ESCAPE '\' AND name LIKE '%' || :t2 || '%' ESCAPE '\' AND name LIKE '%' || :t3 || '%' ESCAPE '\'
           AND (categoryId IS NULL OR categoryId NOT IN (SELECT id FROM categories WHERE isHidden = 1))
           ORDER BY CASE WHEN name LIKE :t1 || '%' ESCAPE '\' THEN 0 ELSE 1 END, name COLLATE NOCASE LIMIT :limit"""
    )
    suspend fun movies(playlistId: Long, t1: String, t2: String, t3: String, limit: Int): List<MovieEntity>

    @Query(
        """SELECT * FROM series WHERE playlistId = :playlistId
           AND name LIKE '%' || :t1 || '%' ESCAPE '\' AND name LIKE '%' || :t2 || '%' ESCAPE '\' AND name LIKE '%' || :t3 || '%' ESCAPE '\'
           AND (categoryId IS NULL OR categoryId NOT IN (SELECT id FROM categories WHERE isHidden = 1))
           ORDER BY CASE WHEN name LIKE :t1 || '%' ESCAPE '\' THEN 0 ELSE 1 END, name COLLATE NOCASE LIMIT :limit"""
    )
    suspend fun series(playlistId: Long, t1: String, t2: String, t3: String, limit: Int): List<SeriesEntity>

    /** Programmes are stored per EPG key, not per playlist, so the caller filters by playlist afterwards. */
    @Query(
        """SELECT * FROM epg_programs WHERE endTime > :now AND startTime < :until
           AND title LIKE '%' || :t1 || '%' ESCAPE '\' AND title LIKE '%' || :t2 || '%' ESCAPE '\' AND title LIKE '%' || :t3 || '%' ESCAPE '\'
           ORDER BY startTime LIMIT :limit"""
    )
    suspend fun programs(t1: String, t2: String, t3: String, now: Long, until: Long, limit: Int): List<EpgProgramEntity>

    @Query(
        """SELECT * FROM channels WHERE id IN (:ids)
           AND (categoryId IS NULL OR categoryId NOT IN (SELECT id FROM categories WHERE isHidden = 1))"""
    )
    suspend fun channelsByIds(ids: List<Long>): List<ChannelEntity>
}
