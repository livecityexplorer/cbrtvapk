package app.iptv.core.data.di

import android.content.Context
import androidx.room.Room
import app.iptv.core.data.db.AppDatabase
import app.iptv.core.data.db.Migrations
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides @Singleton
    fun database(@ApplicationContext ctx: Context): AppDatabase =
        Room.databaseBuilder(ctx, AppDatabase::class.java, AppDatabase.NAME)
            .addMigrations(*Migrations.ALL)
            .build()

    @Provides fun playlistDao(db: AppDatabase) = db.playlistDao()
    @Provides fun categoryDao(db: AppDatabase) = db.categoryDao()
    @Provides fun channelDao(db: AppDatabase) = db.channelDao()
    @Provides fun epgDao(db: AppDatabase) = db.epgDao()
    @Provides fun favoriteDao(db: AppDatabase) = db.favoriteDao()
    @Provides fun watchHistoryDao(db: AppDatabase) = db.watchHistoryDao()
    @Provides fun recordingDao(db: AppDatabase) = db.recordingDao()
    @Provides fun vodDao(db: AppDatabase) = db.vodDao()
    @Provides fun searchDao(db: AppDatabase) = db.searchDao()
}
