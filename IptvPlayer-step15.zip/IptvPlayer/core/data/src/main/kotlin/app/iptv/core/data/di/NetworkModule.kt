package app.iptv.core.data.di

import app.iptv.core.data.network.RawHttpApi
import app.iptv.core.data.stalker.StalkerClient
import app.iptv.core.data.xtream.XtreamClient
import app.iptv.core.domain.model.Playlist
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {
    @Provides @Singleton
    fun okHttp(): OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    @Provides @Singleton
    fun json(): Json = Json { ignoreUnknownKeys = true; isLenient = true; coerceInputValues = true }

    // The base URL is a dummy: every call uses an absolute @Url.
    @Provides @Singleton
    fun rawApi(client: OkHttpClient): RawHttpApi =
        Retrofit.Builder().baseUrl("http://localhost/").client(client).build().create(RawHttpApi::class.java)
}

@Singleton
class SourceClientFactory @Inject constructor(private val api: RawHttpApi, private val json: Json) {
    fun xtream(p: Playlist) = XtreamClient(api, json, p.url, p.username.orEmpty(), p.password.orEmpty())
    fun stalker(p: Playlist) = StalkerClient(api, json, p.url, p.macAddress.orEmpty())
}
