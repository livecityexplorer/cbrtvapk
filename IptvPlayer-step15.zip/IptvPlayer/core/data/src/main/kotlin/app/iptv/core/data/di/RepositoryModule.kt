package app.iptv.core.data.di

import app.iptv.core.data.repository.*
import app.iptv.core.domain.repository.*
import app.iptv.core.data.sync.PlaylistSyncerImpl
import app.iptv.core.data.epg.EpgSyncerImpl
import app.iptv.core.data.recording.RecordingControllerImpl
import app.iptv.core.data.recording.RecordingStorage
import app.iptv.core.data.recording.RecordingStorageImpl
import app.iptv.core.data.search.SearchRepositoryImpl
import app.iptv.core.data.backup.BackupManager
import app.iptv.core.data.parental.ParentalGateImpl
import app.iptv.core.data.vod.VodDetailsLoaderImpl
import app.iptv.core.data.reminder.ReminderSchedulerImpl
import app.iptv.core.data.resolver.StreamResolverImpl
import app.iptv.core.domain.reminder.ReminderScheduler
import app.iptv.core.domain.sync.EpgSyncer
import app.iptv.core.domain.sync.PlaylistSyncer
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {
    @Binds abstract fun playlists(impl: PlaylistRepositoryImpl): PlaylistRepository
    @Binds abstract fun channels(impl: ChannelRepositoryImpl): ChannelRepository
    @Binds abstract fun epg(impl: EpgRepositoryImpl): EpgRepository
    @Binds abstract fun vod(impl: VodRepositoryImpl): VodRepository
    @Binds abstract fun userData(impl: UserDataRepositoryImpl): UserDataRepository
    @Binds abstract fun recordings(impl: RecordingRepositoryImpl): RecordingRepository
    @Binds abstract fun syncer(impl: PlaylistSyncerImpl): PlaylistSyncer
    @Binds abstract fun prefs(impl: PreferencesRepositoryImpl): PreferencesRepository
    @Binds abstract fun epgSyncer(impl: EpgSyncerImpl): EpgSyncer
    @Binds abstract fun recordingController(impl: RecordingControllerImpl): RecordingController
    @Binds abstract fun recordingStorage(impl: RecordingStorageImpl): RecordingStorage
    @Binds abstract fun search(impl: SearchRepositoryImpl): SearchRepository
    @Binds abstract fun vodDetails(impl: VodDetailsLoaderImpl): VodDetailsLoader
    @Binds abstract fun resolver(impl: StreamResolverImpl): StreamResolver
    @Binds abstract fun reminders(impl: ReminderSchedulerImpl): ReminderScheduler
    @Binds abstract fun parental(impl: ParentalGateImpl): ParentalGate
    @Binds abstract fun backup(impl: BackupManager): BackupRepository
}
