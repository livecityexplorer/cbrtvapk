package app.iptv.core.data.di

import app.iptv.core.domain.repository.PlaylistRepository
import app.iptv.core.domain.sync.PlaylistSyncer
import app.iptv.core.domain.sync.SyncManager
import app.iptv.core.domain.usecase.SavePlaylistUseCase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import javax.inject.Singleton

/** The domain module has no Hilt, so its classes are provided here. */
@Module
@InstallIn(SingletonComponent::class)
object UseCaseModule {
    @Provides @Singleton
    fun savePlaylist(repo: PlaylistRepository) = SavePlaylistUseCase(repo)

    @Provides @Singleton
    fun syncManager(syncer: PlaylistSyncer): SyncManager =
        SyncManager(syncer, CoroutineScope(SupervisorJob() + Dispatchers.Default))
}
