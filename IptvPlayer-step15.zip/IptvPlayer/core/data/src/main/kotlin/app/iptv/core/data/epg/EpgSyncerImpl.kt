package app.iptv.core.data.epg

import app.iptv.core.data.di.SourceClientFactory
import app.iptv.core.data.network.toIptvError
import app.iptv.core.data.parser.EpgChannelMatcher
import app.iptv.core.data.parser.EpgChannelRef
import app.iptv.core.data.sync.PlaylistContentOpener
import app.iptv.core.domain.error.IptvError
import app.iptv.core.domain.model.PlaylistType
import app.iptv.core.domain.repository.ChannelRepository
import app.iptv.core.domain.repository.EpgRepository
import app.iptv.core.domain.repository.PlaylistRepository
import app.iptv.core.domain.repository.PreferencesRepository
import app.iptv.core.domain.sync.EpgSyncResult
import app.iptv.core.domain.sync.EpgSyncer
import app.iptv.core.domain.util.EpgKey
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class EpgSyncerImpl @Inject constructor(
    private val playlists: PlaylistRepository,
    private val channels: ChannelRepository,
    private val epg: EpgRepository,
    private val importer: XmltvImporter,
    private val opener: PlaylistContentOpener,
    private val clients: SourceClientFactory,
    private val prefs: PreferencesRepository
) : EpgSyncer {

    override suspend fun refresh(playlistId: Long, onProgress: (Int) -> Unit): EpgSyncResult = withContext(Dispatchers.IO) {
        val p = playlists.get(playlistId) ?: throw IptvError.InvalidInput("This playlist no longer exists.")
        val infos = channels.epgChannels(playlistId)
        val sources = p.epgUrls.size + if (p.type == PlaylistType.STALKER) 1 else 0
        if (sources == 0) return@withContext EpgSyncResult(0, noSource = true)
        if (infos.isEmpty()) return@withContext EpgSyncResult(0)

        val matcher = EpgChannelMatcher(infos.map { EpgChannelRef(it.tvgId, it.tvgName, it.name) })
        val now = System.currentTimeMillis()
        var total = 0
        val failed = mutableListOf<String>()
        var lastError: IptvError? = null

        for (url in p.epgUrls) {
            try {
                val base = total
                total += opener.open(url).use { stream ->
                    importer.import(stream, matcher, now, onProgress = { onProgress(base + it) }) { epg.importPrograms(it) }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                failed += url
                lastError = e.toIptvError()
            }
        }

        if (p.type == PlaylistType.STALKER) {
            try {
                val keys = infos.associate { it.remoteId to EpgKey.of(it.tvgId, it.tvgName, it.name) }
                val programs = clients.stalker(p).fetchEpg(keys)
                epg.importPrograms(programs)
                total += programs.size
                onProgress(total)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                failed += "portal"
                lastError = e.toIptvError()
            }
        }

        if (failed.size == sources) throw lastError ?: IptvError.InvalidResponse("Could not load the program guide.")
        epg.purgeEndedBefore(now - XmltvImporter.KEEP_PAST_MS)
        prefs.setLastEpgRefresh(System.currentTimeMillis())
        EpgSyncResult(total, failed)
    }
}
