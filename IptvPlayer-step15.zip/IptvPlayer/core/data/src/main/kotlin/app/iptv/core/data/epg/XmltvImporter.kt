package app.iptv.core.data.epg

import app.iptv.core.data.parser.EpgChannelMatcher
import app.iptv.core.data.parser.XmltvChannel
import app.iptv.core.data.parser.XmltvParser
import app.iptv.core.domain.model.EpgProgram
import java.io.InputStream
import javax.inject.Inject

/**
 * Streams an XMLTV document into [EpgProgram]s keyed for OUR channels. Programmes of channels we don't
 * have are dropped, as are ones that ended over a day ago or start over two weeks ahead (keeps the DB small).
 */
class XmltvImporter @Inject constructor(private val parser: XmltvParser) {

    suspend fun import(
        input: InputStream,
        matcher: EpgChannelMatcher,
        now: Long,
        onProgress: (Int) -> Unit = {},
        sink: suspend (List<EpgProgram>) -> Unit
    ): Int {
        val xmlChannels = HashMap<String, XmltvChannel>()
        val targetCache = HashMap<String, Set<String>>()
        val minEnd = now - KEEP_PAST_MS
        val maxStart = now + KEEP_AHEAD_MS
        var imported = 0
        parser.parse(input, BATCH, onChannel = { xmlChannels[it.id] = it }) { batch ->
            val out = ArrayList<EpgProgram>(batch.size)
            for (p in batch) {
                if (p.endTime < minEnd || p.startTime > maxStart) continue
                val targets = targetCache.getOrPut(p.channelId) {
                    matcher.targets(p.channelId, xmlChannels[p.channelId]?.displayNames.orEmpty())
                }
                for (key in targets) {
                    out += EpgProgram(
                        channelTvgId = key, title = p.title, description = p.description,
                        startTime = p.startTime, endTime = p.endTime, posterUrl = p.posterUrl
                    )
                }
            }
            if (out.isNotEmpty()) sink(out)
            imported += out.size
            onProgress(imported)
        }
        return imported
    }

    companion object {
        const val BATCH = 2000
        const val KEEP_PAST_MS = 24L * 60 * 60 * 1000
        const val KEEP_AHEAD_MS = 14L * 24 * 60 * 60 * 1000
    }
}
