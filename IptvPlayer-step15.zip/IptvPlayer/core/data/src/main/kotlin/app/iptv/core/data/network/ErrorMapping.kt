package app.iptv.core.data.network

import app.iptv.core.domain.error.IptvError
import kotlinx.serialization.SerializationException
import retrofit2.HttpException
import java.io.IOException

fun Throwable.toIptvError(): IptvError = when (this) {
    is IptvError -> this
    is HttpException -> when (code()) {
        401, 403 -> IptvError.InvalidCredentials()
        404 -> IptvError.InvalidResponse("The server address looks wrong (404 not found).")
        else -> IptvError.Server(code())
    }
    is IOException -> IptvError.Network(this)
    is SerializationException -> IptvError.InvalidResponse("The server did not return valid data.", this)
    is IllegalArgumentException -> IptvError.InvalidResponse("The server did not return valid data.", this)
    else -> IptvError.Unknown(this)
}
