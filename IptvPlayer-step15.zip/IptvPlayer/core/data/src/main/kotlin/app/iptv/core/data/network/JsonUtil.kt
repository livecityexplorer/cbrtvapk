package app.iptv.core.data.network

import app.iptv.core.data.parser.XmltvParser
import kotlinx.serialization.json.*
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction

// Xtream/Stalker JSON is inconsistent (numbers as strings, [] or false instead of objects), so we read leniently.
internal fun JsonElement?.field(key: String): JsonElement? = (this as? JsonObject)?.get(key)
internal fun JsonElement?.arr(): JsonArray = this as? JsonArray ?: JsonArray(emptyList())
internal fun JsonElement?.str(): String? {
    val p = this as? JsonPrimitive ?: return null
    if (p is JsonNull) return null
    return p.content.trim().takeIf { it.isNotEmpty() && it != "null" }
}
internal fun JsonElement?.long(): Long? = str()?.let { it.toLongOrNull() ?: it.toDoubleOrNull()?.toLong() }
internal fun JsonElement?.int(): Int? = long()?.toInt()
internal fun JsonElement?.float(): Float? = str()?.toFloatOrNull()

/** "2024-01-01 12:00:00" (no zone info) -> epoch millis interpreted as UTC. */
internal fun parseLooseDateTime(s: String?): Long? =
    s?.filter { it.isDigit() }?.takeIf { it.length >= 12 }?.let { XmltvParser.parseXmltvTime(it) }

/** Xtream sends EPG title/description base64-encoded, but some servers send plain text. */
internal object Base64Lenient {
    private const val ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

    fun decodeOrSelf(s: String?): String? {
        if (s == null) return null
        val t = s.trim()
        if (t.isEmpty() || t.length % 4 == 1) return s
        val norm = t.replace('-', '+').replace('_', '/').trimEnd('=')
        if (norm.any { it !in ALPHA }) return s
        val out = ByteArrayOutputStream()
        var buffer = 0
        var bits = 0
        for (c in norm) {
            buffer = (buffer shl 6) or ALPHA.indexOf(c)
            bits += 6
            if (bits >= 8) {
                bits -= 8
                out.write((buffer shr bits) and 0xFF)
                buffer = buffer and ((1 shl bits) - 1)
            }
        }
        return try {
            val text = Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(out.toByteArray())).toString()
            if (text.any { it < ' ' && it != '\n' && it != '\r' && it != '\t' }) s else text
        } catch (e: java.nio.charset.CharacterCodingException) { s }
    }
}
