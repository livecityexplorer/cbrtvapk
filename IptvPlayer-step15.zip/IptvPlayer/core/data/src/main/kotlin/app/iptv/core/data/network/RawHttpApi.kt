package app.iptv.core.data.network

import okhttp3.ResponseBody
import retrofit2.http.GET
import retrofit2.http.HeaderMap
import retrofit2.http.Streaming
import retrofit2.http.Url

/** One generic GET used by the Xtream and Stalker clients (servers differ too much for fixed paths). */
interface RawHttpApi {
    @Streaming @GET
    suspend fun get(@Url url: String, @HeaderMap headers: Map<String, String>): ResponseBody
}
