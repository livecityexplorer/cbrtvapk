package app.iptv.core.data.parental

import android.os.SystemClock
import app.iptv.core.data.db.dao.CategoryDao
import app.iptv.core.domain.repository.*
import app.iptv.core.domain.util.AdultFilter
import app.iptv.core.domain.util.PinHasher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ParentalGateImpl @Inject constructor(
    private val prefs: PreferencesRepository,
    private val categoryDao: CategoryDao,
    private val channels: ChannelRepository,
    private val vod: VodRepository
) : ParentalGate {

    @Volatile private var unlockedUntil = 0L

    override val hasPin: Flow<Boolean> = prefs.settings.map { it.hasPin }

    override suspend fun setPin(newPin: String, currentPin: String?): Boolean {
        if (!PinHasher.isValidPin(newPin)) return false
        val existing = prefs.settings.first().pinHash
        if (existing != null && !PinHasher.verify(currentPin.orEmpty(), existing)) return false
        val hash = PinHasher.hash(newPin)
        prefs.updateSettings { it.copy(pinHash = hash) }
        return true
    }

    override suspend fun clearPin(currentPin: String): Boolean {
        val existing = prefs.settings.first().pinHash ?: return true
        if (!PinHasher.verify(currentPin, existing)) return false
        prefs.updateSettings { it.copy(pinHash = null) }
        unlockedUntil = 0L
        return true
    }

    override suspend fun verify(pin: String): Boolean {
        val ok = PinHasher.verify(pin, prefs.settings.first().pinHash)
        if (ok) unlockedUntil = SystemClock.elapsedRealtime() + ParentalGate.UNLOCK_WINDOW_MS
        return ok
    }

    override suspend fun isLockedNow(): Boolean =
        prefs.settings.first().hasPin && SystemClock.elapsedRealtime() >= unlockedUntil

    override fun lockAll() { unlockedUntil = 0L }

    private suspend fun gated(isLocked: suspend () -> Boolean): Boolean = isLockedNow() && isLocked()

    override suspend fun categoryNeedsPin(categoryId: Long) = gated { categoryDao.isLocked(categoryId) == true }

    override suspend fun channelNeedsPin(channelId: Long) = gated {
        val ch = channels.getChannel(channelId) ?: return@gated false
        ch.isLocked || (ch.categoryId?.let { categoryDao.isLocked(it) } == true)
    }

    override suspend fun movieNeedsPin(movieId: Long) = gated {
        vod.getMovie(movieId)?.categoryId?.let { categoryDao.isLocked(it) } == true
    }

    override suspend fun episodeNeedsPin(episodeId: Long) = gated {
        val ep = vod.getEpisode(episodeId) ?: return@gated false
        vod.getSeries(ep.seriesId)?.categoryId?.let { categoryDao.isLocked(it) } == true
    }

    /** Hides (or un-hides) every category whose name looks adult; new categories are handled by CategoryStore. */
    override suspend fun setHideAdult(enabled: Boolean) {
        prefs.updateSettings { it.copy(hideAdult = enabled) }
        categoryDao.idsAndNames().filter { AdultFilter.isAdult(it.name) }.forEach { categoryDao.setHidden(it.id, enabled) }
    }
}
