package app.iptv.core.data.parser

import app.iptv.core.domain.util.EpgKey

data class EpgChannelRef(val tvgId: String?, val tvgName: String?, val name: String) {
    val key: String get() = EpgKey.of(tvgId, tvgName, name)
}

/**
 * Maps an XMLTV channel to the EPG keys of our channels: tvg-id first (case-insensitive),
 * then fallback on normalized tvg-name / channel name vs. the XMLTV display-names.
 * One XMLTV channel can feed several of our channels (duplicates across groups).
 */
class EpgChannelMatcher(channels: Collection<EpgChannelRef>) {
    private val byId = HashMap<String, MutableSet<String>>()
    private val byName = HashMap<String, MutableSet<String>>()

    init {
        for (c in channels) {
            val key = c.key
            c.tvgId?.trim()?.takeIf { it.isNotEmpty() }?.let { byId.getOrPut(it.lowercase()) { linkedSetOf() }.add(key) }
            listOfNotNull(c.tvgName, c.name).map { EpgKey.normalizeName(it) }.filter { it.isNotEmpty() }
                .forEach { byName.getOrPut(it) { linkedSetOf() }.add(key) }
        }
    }

    fun targets(xmlChannelId: String, displayNames: List<String>): Set<String> {
        byId[xmlChannelId.trim().lowercase()]?.let { return it }
        val out = linkedSetOf<String>()
        (displayNames + xmlChannelId).map { EpgKey.normalizeName(it) }.filter { it.isNotEmpty() }
            .forEach { n -> byName[n]?.let { out.addAll(it) } }
        return out
    }
}
