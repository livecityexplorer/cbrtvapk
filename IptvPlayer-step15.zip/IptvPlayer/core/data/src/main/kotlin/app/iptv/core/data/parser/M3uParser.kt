package app.iptv.core.data.parser

import app.iptv.core.domain.model.CategoryImport
import app.iptv.core.domain.model.ChannelImport
import app.iptv.core.domain.util.StreamHeaders
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import javax.inject.Inject

data class M3uResult(
    val categories: List<CategoryImport>,
    val channels: List<ChannelImport>,
    val epgUrls: List<String>
)

internal data class ExtInf(val attrs: Map<String, String>, val title: String)

private val ATTR = Regex("""([A-Za-z0-9_\-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"',]+))""")

internal fun parseAttributes(s: String): Map<String, String> {
    val out = HashMap<String, String>()
    for (m in ATTR.findAll(s)) {
        val v = m.groups[2]?.value ?: m.groups[3]?.value ?: m.groups[4]?.value ?: ""
        out[m.groupValues[1].lowercase()] = v
    }
    return out
}

internal fun parseExtInf(line: String): ExtInf {
    val body = line.substring(line.indexOf(':') + 1)
    var quote = 0.toChar()
    var comma = -1
    for (i in body.indices) {
        val ch = body[i]
        if (quote != 0.toChar()) { if (ch == quote) quote = 0.toChar() }
        else if (ch == '"' || ch == '\'') quote = ch
        else if (ch == ',') { comma = i; break }
    }
    val attrPart = if (comma >= 0) body.substring(0, comma) else body
    val title = if (comma >= 0) body.substring(comma + 1).trim() else ""
    return ExtInf(parseAttributes(attrPart), title)
}

/**
 * Streaming M3U/M3U8 parser. Reads line by line (constant memory apart from the result),
 * runs on Dispatchers.IO, is cancellable, and reports the number of channels parsed so far.
 * Per-stream headers from #EXTVLCOPT are appended to the URL via [StreamHeaders].
 */
class M3uParser @Inject constructor() {

    suspend fun parse(input: InputStream, onProgress: (channelsParsed: Int) -> Unit = {}): M3uResult =
        withContext(Dispatchers.IO) {
            val channels = ArrayList<ChannelImport>()
            val categories = LinkedHashMap<String, CategoryImport>()
            val epgUrls = LinkedHashSet<String>()
            val seen = HashMap<String, Int>()
            val headers = LinkedHashMap<String, String>()
            var info: ExtInf? = null
            var pendingGroup: String? = null
            var lineNo = 0

            BufferedReader(InputStreamReader(input, Charsets.UTF_8), 64 * 1024).use { reader ->
                while (true) {
                    val raw = reader.readLine() ?: break
                    var t = raw.trim()
                    if (lineNo == 0) t = t.removePrefix("\uFEFF").trim()
                    lineNo++
                    if (lineNo % 2000 == 0) ensureActive()
                    if (t.isEmpty()) continue

                    when {
                        t.startsWith("#EXTM3U", ignoreCase = true) -> {
                            val a = parseAttributes(t)
                            listOf("url-tvg", "x-tvg-url", "tvg-url").mapNotNull { a[it] }
                                .flatMap { it.split(',') }.map { it.trim() }.filter { it.isNotEmpty() }
                                .forEach { epgUrls += it }
                        }
                        t.startsWith("#EXTINF", ignoreCase = true) -> info = parseExtInf(t)
                        t.startsWith("#EXTGRP:", ignoreCase = true) -> pendingGroup = t.substringAfter(':').trim()
                        t.startsWith("#EXTVLCOPT:", ignoreCase = true) -> {
                            val kv = t.substringAfter(':')
                            val key = kv.substringBefore('=').trim().lowercase()
                            val value = kv.substringAfter('=', "").trim()
                            val header = when (key) {
                                "http-user-agent" -> "User-Agent"
                                "http-referrer", "http-referer" -> "Referer"
                                "http-origin" -> "Origin"
                                else -> null
                            }
                            if (header != null && value.isNotEmpty()) headers[header] = value
                        }
                        t.startsWith("#") -> Unit
                        t.contains("://") -> {
                            val a = info?.attrs ?: emptyMap()
                            val group = (a["group-title"]?.trim()?.takeIf { it.isNotEmpty() } ?: pendingGroup?.takeIf { it.isNotEmpty() })
                            val tvgId = a["tvg-id"]?.trim()?.takeIf { it.isNotEmpty() }
                            val tvgName = a["tvg-name"]?.trim()?.takeIf { it.isNotEmpty() }
                            val name = info?.title?.takeIf { it.isNotEmpty() } ?: tvgName ?: t.substringAfterLast('/').substringBefore('?').ifEmpty { t }
                            val logo = a["tvg-logo"]?.trim()?.takeIf { it.isNotEmpty() }
                            val number = a["tvg-chno"]?.trim()?.toIntOrNull() ?: (channels.size + 1)
                            val archive = (a["catchup-days"] ?: a["tvg-rec"])?.trim()?.toIntOrNull() ?: 0

                            val base = "$name|${group.orEmpty()}|${tvgId.orEmpty()}"
                            val n = seen.merge(base, 1, Int::plus)!! - 1
                            val remoteId = if (n == 0) base else "$base#$n"

                            if (group != null) categories.getOrPut(group) { CategoryImport(group, group) }
                            channels += ChannelImport(
                                remoteId = remoteId, name = name, logoUrl = logo, tvgId = tvgId, tvgName = tvgName,
                                streamUrl = StreamHeaders.encode(t, headers), number = number,
                                archiveDays = archive, categoryRemoteId = group
                            )
                            if (channels.size % 250 == 0) onProgress(channels.size)
                            info = null; pendingGroup = null; headers.clear()
                        }
                        else -> Unit
                    }
                }
            }
            onProgress(channels.size)
            M3uResult(categories.values.toList(), channels, epgUrls.toList())
        }
}
