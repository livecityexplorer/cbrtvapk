package app.iptv.core.data.parser

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.BufferedInputStream
import java.io.InputStream
import java.util.zip.GZIPInputStream
import javax.inject.Inject

data class XmltvChannel(val id: String, val displayNames: List<String>, val iconUrl: String?)
data class XmltvProgram(
    val channelId: String, val title: String, val description: String?,
    val startTime: Long, val endTime: Long, val posterUrl: String?
)

/**
 * Streaming XMLTV parser (pull-based, constant memory). Channels are reported through [onChannel]
 * as they are read (XMLTV lists them before programmes); programmes are delivered in batches.
 * Programmes with missing/invalid start, stop, channel or title are skipped.
 */
class XmltvParser(private val newParser: () -> XmlPullParser) {

    @Inject constructor() : this({ XmlPullParserFactory.newInstance().newPullParser() })

    /** Returns the number of programmes delivered. */
    suspend fun parse(
        input: InputStream,
        batchSize: Int = 1000,
        onChannel: (XmltvChannel) -> Unit = {},
        onBatch: suspend (List<XmltvProgram>) -> Unit
    ): Int = withContext(Dispatchers.IO) {
        val stream = openStream(input)
        val p = newParser()
        p.setInput(stream, null) // encoding auto-detected from the XML prolog
        val batch = ArrayList<XmltvProgram>(batchSize)
        var total = 0
        var event = p.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                when (p.name) {
                    "channel" -> onChannel(readChannel(p))
                    "programme" -> readProgramme(p)?.let { batch += it; total++ }
                }
                if (batch.size >= batchSize) {
                    ensureActive()
                    onBatch(batch.toList()); batch.clear()
                }
            }
            event = p.next()
        }
        if (batch.isNotEmpty()) onBatch(batch.toList())
        total
    }

    private fun readChannel(p: XmlPullParser): XmltvChannel {
        val id = p.getAttributeValue(null, "id").orEmpty()
        val names = ArrayList<String>()
        var icon: String? = null
        var depth = 1
        while (depth > 0) {
            when (p.next()) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "display-name" -> p.nextText().trim().takeIf { it.isNotEmpty() }?.let { names += it }
                    "icon" -> { icon = p.getAttributeValue(null, "src"); depth++ }
                    else -> depth++
                }
                XmlPullParser.END_TAG -> depth--
                XmlPullParser.END_DOCUMENT -> return XmltvChannel(id, names, icon)
            }
        }
        return XmltvChannel(id, names, icon)
    }

    private fun readProgramme(p: XmlPullParser): XmltvProgram? {
        val channel = p.getAttributeValue(null, "channel")?.trim().orEmpty()
        val start = parseXmltvTime(p.getAttributeValue(null, "start").orEmpty())
        val stop = parseXmltvTime(p.getAttributeValue(null, "stop").orEmpty())
        var title: String? = null
        var desc: String? = null
        var icon: String? = null
        var depth = 1
        while (depth > 0) {
            when (p.next()) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "title" -> { val t = p.nextText().trim(); if (title == null && t.isNotEmpty()) title = t }
                    "desc" -> { val t = p.nextText().trim(); if (desc == null && t.isNotEmpty()) desc = t }
                    "icon" -> { if (icon == null) icon = p.getAttributeValue(null, "src"); depth++ }
                    else -> depth++
                }
                XmlPullParser.END_TAG -> depth--
                XmlPullParser.END_DOCUMENT -> depth = 0
            }
        }
        if (channel.isEmpty() || start == null || stop == null || stop <= start || title == null) return null
        return XmltvProgram(channel, title, desc, start, stop, icon)
    }

    companion object {
        /** Wraps the stream in a GZIPInputStream when it starts with the gzip magic bytes. */
        fun openStream(raw: InputStream): InputStream {
            val buffered = BufferedInputStream(raw, 64 * 1024)
            buffered.mark(2)
            val b0 = buffered.read()
            val b1 = buffered.read()
            buffered.reset()
            return if (b0 == 0x1f && b1 == 0x8b) GZIPInputStream(buffered, 64 * 1024) else buffered
        }

        /** "20240101120000 +0100" -> epoch millis. Accepts yyyyMMdd[HH[mm[ss]]] and offsets like +0100, -05:00, Z. */
        fun parseXmltvTime(raw: String): Long? {
            val s = raw.trim()
            var i = 0
            while (i < s.length && s[i].isDigit()) i++
            if (i != 8 && i != 10 && i != 12 && i != 14) return null
            val digits = s.substring(0, i).padEnd(14, '0')
            val y = digits.substring(0, 4).toInt()
            val mo = digits.substring(4, 6).toInt()
            val d = digits.substring(6, 8).toInt()
            val h = digits.substring(8, 10).toInt()
            val mi = digits.substring(10, 12).toInt()
            val sec = digits.substring(12, 14).toInt()
            if (mo !in 1..12 || d !in 1..31 || h > 23 || mi > 59 || sec > 60) return null

            var offsetSec = 0
            val rest = s.substring(i).trim()
            if (rest.isNotEmpty() && rest != "Z") {
                val sign = when (rest[0]) { '+' -> 1; '-' -> -1; else -> return null }
                val od = rest.substring(1).replace(":", "")
                if (od.length != 4 || !od.all { it.isDigit() }) return null
                offsetSec = sign * (od.substring(0, 2).toInt() * 3600 + od.substring(2, 4).toInt() * 60)
            }
            val days = daysFromCivil(y, mo, d)
            return (days * 86400L + h * 3600L + mi * 60L + sec - offsetSec) * 1000L
        }

        // Howard Hinnant's days-from-civil: pure arithmetic, no java.time (minSdk 21).
        private fun daysFromCivil(year: Int, month: Int, day: Int): Long {
            val y = if (month <= 2) year - 1 else year
            val era = (if (y >= 0) y else y - 399) / 400
            val yoe = y - era * 400
            val doy = (153 * (month + (if (month > 2) -3 else 9)) + 2) / 5 + day - 1
            val doe = yoe * 365 + yoe / 4 - yoe / 100 + doy
            return era * 146097L + doe - 719468L
        }
    }
}
