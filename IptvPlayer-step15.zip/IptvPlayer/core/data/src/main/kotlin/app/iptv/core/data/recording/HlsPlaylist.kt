package app.iptv.core.data.recording

data class HlsVariant(val uri: String, val bandwidth: Long)
data class HlsSegment(val uri: String, val durationSec: Double, val sequence: Long)

sealed interface HlsPlaylist {
    data class Master(val variants: List<HlsVariant>) : HlsPlaylist
    data class Media(
        val targetDurationSec: Int, val mediaSequence: Long, val segments: List<HlsSegment>,
        val ended: Boolean, val encrypted: Boolean, val fragmentedMp4: Boolean
    ) : HlsPlaylist
}

/** Just enough of RFC 8216 to record MPEG-TS HLS: master -> variants, media -> numbered segments. */
object HlsParser {
    private val BANDWIDTH = Regex("""(?:^|,)BANDWIDTH=(\d+)""")

    fun parse(text: String): HlsPlaylist {
        val lines = text.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
        require(lines.firstOrNull()?.startsWith("#EXTM3U") == true) { "Not an HLS playlist" }
        return if (lines.any { it.startsWith("#EXT-X-STREAM-INF") }) master(lines) else media(lines)
    }

    private fun master(lines: List<String>): HlsPlaylist.Master {
        val out = ArrayList<HlsVariant>()
        var bandwidth: Long? = null
        for (l in lines) {
            when {
                l.startsWith("#EXT-X-STREAM-INF:") -> bandwidth = BANDWIDTH.find(l.substringAfter(':'))?.groupValues?.get(1)?.toLongOrNull() ?: 0L
                !l.startsWith("#") && bandwidth != null -> { out += HlsVariant(l, bandwidth); bandwidth = null }
            }
        }
        return HlsPlaylist.Master(out)
    }

    private fun media(lines: List<String>): HlsPlaylist.Media {
        var target = 0
        var sequence = 0L
        var ended = false
        var encrypted = false
        var fmp4 = false
        val raw = ArrayList<Pair<String, Double>>()
        var pending: Double? = null
        for (l in lines) {
            when {
                l.startsWith("#EXT-X-TARGETDURATION:") -> target = l.substringAfter(':').trim().toIntOrNull() ?: 0
                l.startsWith("#EXT-X-MEDIA-SEQUENCE:") -> sequence = l.substringAfter(':').trim().toLongOrNull() ?: 0L
                l.startsWith("#EXT-X-ENDLIST") -> ended = true
                l.startsWith("#EXT-X-KEY:") -> if (!l.contains("METHOD=NONE")) encrypted = true
                l.startsWith("#EXT-X-MAP:") -> fmp4 = true
                l.startsWith("#EXTINF:") -> pending = l.substringAfter(':').substringBefore(',').trim().toDoubleOrNull() ?: 0.0
                !l.startsWith("#") -> { raw += l to (pending ?: 0.0); pending = null }
            }
        }
        val segments = raw.mapIndexed { i, (uri, d) -> HlsSegment(uri, d, sequence + i) }
        return HlsPlaylist.Media(target, sequence, segments, ended, encrypted, fmp4)
    }
}
