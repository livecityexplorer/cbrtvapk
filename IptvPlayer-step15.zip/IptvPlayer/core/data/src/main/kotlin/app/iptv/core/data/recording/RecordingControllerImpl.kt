package app.iptv.core.data.recording

import android.content.Context
import androidx.core.content.ContextCompat
import app.iptv.core.domain.model.Channel
import app.iptv.core.domain.model.EpgProgram
import app.iptv.core.domain.model.Recording
import app.iptv.core.domain.model.RecordingStatus
import app.iptv.core.domain.repository.RecordingController
import app.iptv.core.domain.repository.RecordingRepository
import app.iptv.core.domain.repository.ScheduleResult
import app.iptv.core.domain.util.RecordingConflicts
import app.iptv.core.domain.util.RecordingPolicy
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RecordingControllerImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repo: RecordingRepository,
    private val scheduler: RecordingScheduler,
    private val storage: RecordingStorage
) : RecordingController {

    override suspend fun scheduleProgram(channel: Channel, program: EpgProgram) =
        schedule(channel, program.title, program.startTime, program.endTime)

    override suspend fun recordNow(channel: Channel, title: String, endTime: Long) =
        schedule(channel, title, System.currentTimeMillis(), endTime)

    private suspend fun schedule(channel: Channel, title: String, start: Long, end: Long): ScheduleResult {
        val now = System.currentTimeMillis()
        RecordingPolicy.validate(start, end, now)?.let { return ScheduleResult.Invalid(it) }
        val existing = repo.observeAll().first()
        val startsNow = start <= now + START_NOW_SLACK_MS

        existing.firstOrNull {
            it.channelId == channel.id && it.status in RecordingConflicts.ACTIVE &&
                (it.startTime == start || (startsNow && it.startTime <= now && now < it.endTime))
        }?.let { return ScheduleResult.AlreadyScheduled(it.id) }

        val conflicts = RecordingConflicts.overlapping(existing, maxOf(start, now), end)
        val id = repo.save(Recording(0, channel.id, channel.name, title, channel.streamUrl, start, end, RecordingStatus.SCHEDULED))
        if (startsNow) startService(id) else scheduler.schedule(id, start)
        return ScheduleResult.Scheduled(id, startsNow, conflicts)
    }

    override suspend fun stop(id: Long) {
        val rec = repo.get(id) ?: return
        when (rec.status) {
            RecordingStatus.RECORDING ->
                if (id in RecordingService.activeIds) {
                    try { context.startService(RecordingService.stopIntent(context, id)) } catch (e: Exception) { }
                } else finalizeOrphan(rec)
            RecordingStatus.SCHEDULED -> { scheduler.cancel(id); repo.updateStatus(id, RecordingStatus.CANCELLED, null) }
            else -> Unit
        }
    }

    override suspend fun delete(id: Long) {
        val rec = repo.get(id) ?: return
        if (rec.status == RecordingStatus.RECORDING || rec.status == RecordingStatus.SCHEDULED) {
            stop(id)
            // let the service close the file before it is removed
            withTimeoutOrNull(3_000) { while (id in RecordingService.activeIds) delay(100) }
        }
        (repo.get(id)?.filePath ?: rec.filePath)?.let { storage.delete(it) }
        repo.delete(id)
    }

    override suspend fun rescheduleAll() {
        val now = System.currentTimeMillis()
        for (rec in repo.observeAll().first()) {
            when (rec.status) {
                RecordingStatus.SCHEDULED -> when {
                    RecordingPolicy.stopAt(rec.endTime) <= now -> repo.updateStatus(rec.id, RecordingStatus.FAILED, null) // missed
                    rec.startTime <= now + START_NOW_SLACK_MS -> startService(rec.id)
                    else -> scheduler.schedule(rec.id, rec.startTime)
                }
                // the process died mid-recording: close the entry with whatever reached the disk
                RecordingStatus.RECORDING -> if (rec.id !in RecordingService.activeIds) finalizeOrphan(rec)
                else -> Unit
            }
        }
    }

    override fun exactAlarmsAllowed(): Boolean = scheduler.canScheduleExact()

    private suspend fun startService(id: Long) {
        try {
            ContextCompat.startForegroundService(context, RecordingService.startIntent(context, id))
        } catch (e: Exception) {
            repo.updateStatus(id, RecordingStatus.FAILED, null) // background start refused
        }
    }

    private suspend fun finalizeOrphan(rec: Recording) {
        val size = rec.filePath?.let { storage.size(it) } ?: 0L
        val ok = size >= RecordingService.MIN_USEFUL_BYTES
        repo.updateStatus(rec.id, if (ok) RecordingStatus.COMPLETED else RecordingStatus.FAILED, rec.filePath)
        repo.updateProgress(rec.id, size)
    }

    private companion object { const val START_NOW_SLACK_MS = 5_000L }
}
