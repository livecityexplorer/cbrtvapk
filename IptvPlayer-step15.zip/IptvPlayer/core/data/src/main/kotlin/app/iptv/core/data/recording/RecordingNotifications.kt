package app.iptv.core.data.recording

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

internal object RecordingNotifications {
    private const val CHANNEL_ID = "recordings"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Recordings", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun openApp(context: Context): PendingIntent? =
        context.packageManager.getLaunchIntentForPackage(context.packageName)?.let {
            PendingIntent.getActivity(context, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }

    /** The foreground-service notification: what is being recorded + a Stop button. */
    fun ongoing(context: Context, titles: List<String>): Notification {
        ensureChannel(context)
        val stop = PendingIntent.getService(context, 0, RecordingService.stopIntent(context, -1L), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.presence_video_busy)
            .setContentTitle(if (titles.size > 1) "Recording ${titles.size} programs" else "Recording")
            .setContentText(titles.joinToString(", ").ifEmpty { "Starting…" })
            .setOngoing(true).setOnlyAlertOnce(true).setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setContentIntent(openApp(context))
            .addAction(0, "Stop", stop)
            .build()
    }

    fun finished(context: Context, recordingId: Long, title: String, success: Boolean, detail: String?) {
        ensureChannel(context)
        val n = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(if (success) "Recording saved" else "Recording failed")
            .setContentText(listOfNotNull(title, detail).joinToString(" – "))
            .setAutoCancel(true).setContentIntent(openApp(context))
            .build()
        notify(context, recordingId, n)
    }

    fun failed(context: Context, recordingId: Long, message: String) = finished(context, recordingId, "", false, message)

    private fun notify(context: Context, id: Long, n: Notification) {
        try {
            if (NotificationManagerCompat.from(context).areNotificationsEnabled()) {
                NotificationManagerCompat.from(context).notify(10_000 + id.toInt(), n)
            }
        } catch (e: SecurityException) { /* POST_NOTIFICATIONS denied */ }
    }
}
