package app.iptv.core.data.recording

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/** Arms an alarm for each scheduled recording; the alarm starts [RecordingService] (alarms are the OS-sanctioned way to do that from the background). */
@Singleton
class RecordingScheduler @Inject constructor(@ApplicationContext private val context: Context) {
    private val alarms get() = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    /** Android 12+ only allows exact alarms when the user granted "Alarms & reminders". Otherwise starts may be a few minutes late. */
    fun canScheduleExact(): Boolean = Build.VERSION.SDK_INT < 31 || alarms.canScheduleExactAlarms()

    fun schedule(id: Long, startTime: Long) {
        val at = maxOf(startTime, System.currentTimeMillis() + 1_000)
        val pi = pending(id)
        try {
            if (canScheduleExact()) alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) {
            alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun cancel(id: Long) { alarms.cancel(pending(id)) }

    private fun pending(id: Long): PendingIntent = PendingIntent.getBroadcast(
        context, id.toInt(),
        Intent(context, RecordingAlarmReceiver::class.java).setAction(ACTION_START).putExtra(RecordingService.EXTRA_ID, id),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private companion object { const val ACTION_START = "app.iptv.recording.ALARM" }
}

class RecordingAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(RecordingService.EXTRA_ID, -1L)
        if (id < 0) return
        try {
            ContextCompat.startForegroundService(context, RecordingService.startIntent(context, id))
        } catch (e: Exception) {
            // Android refused a background foreground-service start. The entry stays SCHEDULED and is
            // handled (started or marked failed) the next time the app opens.
            RecordingNotifications.failed(context, id, "Android blocked the recording from starting in the background. Open the app.")
        }
    }
}

/** Alarms don't survive a reboot. Receiving this starts the app process, and IptvApp re-arms everything. */
class RecordingBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) = Unit
}
