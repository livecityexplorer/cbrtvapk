package app.iptv.core.data.recording

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import app.iptv.core.domain.model.RecordingStatus
import app.iptv.core.domain.repository.ChannelRepository
import app.iptv.core.domain.repository.RecordingRepository
import app.iptv.core.domain.repository.StreamResolver
import app.iptv.core.domain.util.RecordingNaming
import app.iptv.core.domain.util.RecordingPolicy
import app.iptv.core.domain.util.RecordingUrl
import app.iptv.core.domain.util.StreamHeaders
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import javax.inject.Inject

/**
 * Foreground service that records one or more channels to disk. Status/size are kept in the database,
 * so the UI just observes it. Pressing Stop (notification or app) keeps what was recorded so far.
 */
@AndroidEntryPoint
class RecordingService : Service() {
    @Inject lateinit var recordings: RecordingRepository
    @Inject lateinit var channels: ChannelRepository
    @Inject lateinit var resolver: StreamResolver
    @Inject lateinit var storage: RecordingStorage
    @Inject lateinit var okHttp: OkHttpClient

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val jobs = ConcurrentHashMap<Long, Job>()
    private val titles = ConcurrentHashMap<Long, String>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getLongExtra(EXTRA_ID, -1L) ?: -1L
        when (intent?.action) {
            ACTION_STOP -> {
                if (id >= 0) jobs[id]?.cancel() else jobs.values.forEach { it.cancel() }
                if (jobs.isEmpty()) shutdown()
            }
            else -> {
                if (!promoteToForeground()) { shutdown(); return START_NOT_STICKY }
                if (id >= 0 && jobs[id]?.isActive != true) launchRecording(id) else if (jobs.isEmpty()) shutdown()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        activeIds.clear()
        super.onDestroy()
    }

    // ------------------------------------------------------------ jobs

    private fun launchRecording(id: Long) {
        val job = scope.launch(start = CoroutineStart.LAZY) {
            try {
                record(id)
            } finally {
                jobs.remove(id); titles.remove(id); activeIds.remove(id)
                if (jobs.isEmpty()) shutdown() else refreshNotification()
            }
        }
        jobs[id] = job
        activeIds.add(id)
        job.start()
    }

    private suspend fun record(id: Long): Unit = coroutineScope {
        val rec = recordings.get(id) ?: return@coroutineScope
        if (rec.status != RecordingStatus.SCHEDULED && rec.status != RecordingStatus.RECORDING) return@coroutineScope
        val stopAt = RecordingPolicy.stopAt(rec.endTime)
        if (System.currentTimeMillis() >= stopAt) {
            recordings.updateStatus(id, RecordingStatus.FAILED, rec.filePath)
            RecordingNotifications.finished(this@RecordingService, id, rec.title, false, "It was too late to start.")
            return@coroutineScope
        }
        titles[id] = rec.title
        recordings.updateStatus(id, RecordingStatus.RECORDING, rec.filePath)
        refreshNotification()

        val counter = AtomicLong(0)
        var output: RecordingOutput? = null
        var location: String? = null
        var failure: Throwable? = null
        val ticker = launch { while (isActive) { delay(PROGRESS_EVERY_MS); recordings.updateProgress(id, counter.get()) } }
        try {
            // Stalker links are short-lived, so always resolve at the moment recording starts.
            val url = rec.channelId?.let { channels.getChannel(it) }?.let { resolver.resolveLive(it) } ?: rec.streamUrl
            val (clean, headers) = StreamHeaders.decode(url)
            val out = storage.create(RecordingNaming.fileName(rec.channelName, rec.title, rec.startTime)).also { output = it }
            location = out.location
            recordings.updateStatus(id, RecordingStatus.RECORDING, location)

            val recorder = StreamRecorder(okHttp)
            var lastError: Throwable? = null
            for (candidate in listOf(RecordingUrl.preferTs(clean), clean).distinct()) { // plain TS first, HLS as fallback
                val before = counter.get()
                try {
                    recorder.record(candidate, headers, out.stream, stopAt) { total -> counter.set(before + total) }
                    lastError = null
                    break
                } catch (e: CancellationException) {
                    throw e
                } catch (e: IOException) {
                    lastError = e
                    if (counter.get() > before) break // it did record something; don't start over with another URL
                }
            }
            lastError?.let { throw it }
        } catch (e: CancellationException) {
            // Stop pressed (or the service is going away): keep what has been recorded.
        } catch (e: Throwable) {
            failure = e
        } finally {
            ticker.cancel()
            withContext(NonCancellable) {
                try { output?.stream?.close() } catch (e: IOException) { }
                val bytes = counter.get()
                val ok = bytes >= MIN_USEFUL_BYTES
                val size = location?.let { storage.size(it) } ?: 0L
                if (!ok && location != null) { storage.delete(location!!); location = null }
                val status = when { ok -> RecordingStatus.COMPLETED; failure != null -> RecordingStatus.FAILED; else -> RecordingStatus.CANCELLED }
                recordings.updateStatus(id, status, location)
                recordings.updateProgress(id, if (ok) size else 0L)
                if (status != RecordingStatus.CANCELLED) {
                    RecordingNotifications.finished(this@RecordingService, id, rec.title, ok, if (ok) null else failure?.message)
                }
            }
        }
    }

    // ------------------------------------------------------------ foreground notification

    private fun promoteToForeground(): Boolean = try {
        val n = RecordingNotifications.ongoing(this, titles.values.toList())
        ServiceCompat.startForeground(
            this, NOTIFICATION_ID, n,
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        )
        true
    } catch (e: Exception) {
        false // e.g. ForegroundServiceStartNotAllowedException
    }

    private fun refreshNotification() {
        try {
            if (NotificationManagerCompat.from(this).areNotificationsEnabled()) {
                NotificationManagerCompat.from(this).notify(NOTIFICATION_ID, RecordingNotifications.ongoing(this, titles.values.toList()))
            }
        } catch (e: SecurityException) { }
    }

    private fun shutdown() {
        Handler(Looper.getMainLooper()).post {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    companion object {
        const val ACTION_START = "app.iptv.recording.START"
        const val ACTION_STOP = "app.iptv.recording.STOP"
        const val EXTRA_ID = "recording_id"
        private const val NOTIFICATION_ID = 4242
        private const val PROGRESS_EVERY_MS = 5_000L
        /** Less than this means nothing usable was recorded. */
        const val MIN_USEFUL_BYTES = 256L * 1024

        /** Recordings currently being written by this process. */
        val activeIds: MutableSet<Long> = ConcurrentHashMap.newKeySet()

        fun startIntent(context: Context, id: Long): Intent =
            Intent(context, RecordingService::class.java).setAction(ACTION_START).putExtra(EXTRA_ID, id)

        fun stopIntent(context: Context, id: Long): Intent =
            Intent(context, RecordingService::class.java).setAction(ACTION_STOP).putExtra(EXTRA_ID, id)
    }
}
