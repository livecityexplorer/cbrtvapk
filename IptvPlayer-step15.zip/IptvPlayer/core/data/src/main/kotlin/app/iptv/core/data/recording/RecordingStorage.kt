package app.iptv.core.data.recording

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import app.iptv.core.domain.repository.PreferencesRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import javax.inject.Inject
import javax.inject.Singleton

/** [location] is an absolute file path (app storage) or a content:// document URI (folder chosen with the system picker). */
class RecordingOutput(val location: String, val stream: OutputStream)

interface RecordingStorage {
    suspend fun create(fileName: String): RecordingOutput
    suspend fun delete(location: String)
    fun size(location: String): Long
}

@Singleton
class RecordingStorageImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    private val prefs: PreferencesRepository
) : RecordingStorage {

    override suspend fun create(fileName: String): RecordingOutput = withContext(Dispatchers.IO) {
        val tree = prefs.recordingsFolder.first()
        if (tree != null) {
            try {
                return@withContext createInTree(Uri.parse(tree), fileName)
            } catch (e: Exception) {
                // permission revoked or folder removed: don't lose the recording, use app storage instead
            }
        }
        createLocal(fileName)
    }

    private fun createInTree(tree: Uri, fileName: String): RecordingOutput {
        val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        val doc = DocumentsContract.createDocument(context.contentResolver, parent, "video/mp2t", fileName)
            ?: throw IOException("Can't create the file in the chosen folder")
        val stream = context.contentResolver.openOutputStream(doc, "w") ?: throw IOException("Can't open the file")
        return RecordingOutput(doc.toString(), stream.buffered(BUFFER))
    }

    private fun createLocal(fileName: String): RecordingOutput {
        val dir = (context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)?.let { File(it, "Recordings") }
            ?: File(context.filesDir, "recordings")).apply { mkdirs() }
        var file = File(dir, fileName)
        var n = 1
        while (file.exists()) { file = File(dir, fileName.removeSuffix(".ts") + " ($n).ts"); n++ }
        return RecordingOutput(file.absolutePath, FileOutputStream(file).buffered(BUFFER))
    }

    override suspend fun delete(location: String) {
        withContext(Dispatchers.IO) {
            try {
                if (location.startsWith("content://")) DocumentsContract.deleteDocument(context.contentResolver, Uri.parse(location))
                else File(location).delete()
            } catch (e: Exception) { /* already gone */ }
        }
    }

    override fun size(location: String): Long = try {
        if (location.startsWith("content://")) {
            context.contentResolver.query(Uri.parse(location), arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else 0L
            } ?: 0L
        } else File(location).length()
    } catch (e: Exception) { 0L }

    private companion object { const val BUFFER = 256 * 1024 }
}
