package app.iptv.core.data.recording

import app.iptv.core.domain.util.Backoff
import app.iptv.core.domain.util.RecordingUrl
import kotlinx.coroutines.*
import okhttp3.Call
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.io.OutputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Copies a live stream into [out] until [stopAt]. Plain MPEG-TS is streamed and re-connected when it drops;
 * HLS (MPEG-TS segments, unencrypted) is followed playlist by playlist and the segments are concatenated.
 * Returns the number of bytes written. Cancelling the coroutine stops promptly (the HTTP call is cancelled).
 */
class StreamRecorder(
    private val client: OkHttpClient,
    private val clock: () -> Long = System::currentTimeMillis
) {
    class UnsupportedStreamException(message: String) : IOException(message)

    suspend fun record(url: String, headers: Map<String, String>, out: OutputStream, stopAt: Long, onBytes: (Long) -> Unit = {}): Long =
        withContext(Dispatchers.IO) {
            if (RecordingUrl.isHls(url)) hls(url, headers, out, stopAt, onBytes) else progressive(url, headers, out, stopAt, onBytes)
        }

    // ------------------------------------------------------------ progressive (MPEG-TS over HTTP)

    private suspend fun progressive(url: String, headers: Map<String, String>, out: OutputStream, stopAt: Long, onBytes: (Long) -> Unit): Long =
        coroutineScope {
            var total = 0L
            var failures = 0
            val buf = ByteArray(BUFFER)
            while (isActive && clock() < stopAt) {
                val call = client.newCall(request(url, headers))
                // a stalled connection must not run past the end time
                val watchdog = launch { delay((stopAt - clock()).coerceAtLeast(0)); call.cancel() }
                try {
                    call.executeCancellable { resp ->
                        if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
                        val src = resp.body?.byteStream() ?: throw IOException("Empty response")
                        var gotData = false
                        while (true) {
                            val n = src.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            total += n
                            onBytes(total)
                            if (!gotData) { gotData = true; failures = 0 }
                            if (clock() >= stopAt) break
                        }
                    }
                } catch (e: IOException) {
                    if (clock() >= stopAt) break
                    failures++
                    if (failures > MAX_FAILURES) throw e
                    delay(Backoff.delayMs(failures, 1_000, 10_000))
                    continue
                } finally {
                    watchdog.cancel()
                }
                if (clock() < stopAt) delay(RECONNECT_PAUSE_MS) // the server closed the stream early: reconnect
            }
            total
        }

    // ------------------------------------------------------------ HLS

    private suspend fun hls(url: String, headers: Map<String, String>, out: OutputStream, stopAt: Long, onBytes: (Long) -> Unit): Long =
        coroutineScope {
            var total = 0L
            var mediaUrl = url
            var playlist = HlsParser.parse(fetchText(mediaUrl, headers))
            if (playlist is HlsPlaylist.Master) {
                val best = playlist.variants.maxByOrNull { it.bandwidth } ?: throw IOException("The playlist has no variants")
                mediaUrl = resolve(mediaUrl, best.uri)
                playlist = HlsParser.parse(fetchText(mediaUrl, headers))
            }
            var nextSeq = -1L
            var failures = 0
            while (isActive && clock() < stopAt) {
                val media = playlist as? HlsPlaylist.Media ?: throw IOException("Unexpected playlist type")
                if (media.encrypted) throw UnsupportedStreamException("Encrypted HLS streams can't be recorded.")
                if (media.fragmentedMp4) throw UnsupportedStreamException("fMP4 HLS streams can't be recorded.")

                val segments = media.segments
                if (segments.isNotEmpty()) {
                    // first pass: start a couple of segments behind the live edge; later: continue, or jump if we fell behind
                    if (nextSeq < 0) nextSeq = maxOf(segments.first().sequence, segments.last().sequence - 2)
                    else if (nextSeq < segments.first().sequence) nextSeq = segments.first().sequence
                }
                for (s in segments) {
                    if (s.sequence < nextSeq) continue
                    if (!isActive || clock() >= stopAt) break
                    try {
                        total += download(resolve(mediaUrl, s.uri), headers, out)
                        onBytes(total)
                        failures = 0
                    } catch (e: IOException) {
                        if (clock() >= stopAt) break
                        if (++failures > MAX_FAILURES) throw e // otherwise skip this segment and carry on
                    }
                    nextSeq = s.sequence + 1
                }
                if (media.ended || clock() >= stopAt) break

                delay((media.targetDurationSec * 500L).coerceIn(500L, 5_000L))
                try {
                    playlist = HlsParser.parse(fetchText(mediaUrl, headers))
                    failures = 0
                } catch (e: IOException) {
                    if (clock() >= stopAt) break
                    if (++failures > MAX_FAILURES) throw e
                }
            }
            total
        }

    private suspend fun fetchText(url: String, headers: Map<String, String>): String =
        client.newCall(request(url, headers)).executeCancellable { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
            resp.body?.string() ?: throw IOException("Empty response")
        }

    private suspend fun download(url: String, headers: Map<String, String>, out: OutputStream): Long =
        client.newCall(request(url, headers)).executeCancellable { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
            val src = resp.body?.byteStream() ?: throw IOException("Empty response")
            val buf = ByteArray(BUFFER)
            var n = 0L
            while (true) {
                val r = src.read(buf)
                if (r < 0) break
                out.write(buf, 0, r)
                n += r
            }
            n
        }

    private fun resolve(base: String, ref: String): String =
        base.toHttpUrl().resolve(ref)?.toString() ?: throw IOException("Bad segment URL: $ref")

    private fun request(url: String, headers: Map<String, String>): Request =
        Request.Builder().url(url).apply {
            header("User-Agent", headers["User-Agent"] ?: USER_AGENT)
            headers.forEach { (k, v) -> header(k, v) }
        }.build()

    /** Runs the blocking call so that cancelling the coroutine cancels the HTTP call (and unblocks the read). */
    private suspend fun <T> Call.executeCancellable(block: (Response) -> T): T = suspendCancellableCoroutine { cont ->
        cont.invokeOnCancellation { cancel() }
        try {
            cont.resume(execute().use(block))
        } catch (e: Throwable) {
            cont.resumeWithException(e)
        }
    }

    private companion object {
        const val BUFFER = 64 * 1024
        const val MAX_FAILURES = 6
        const val RECONNECT_PAUSE_MS = 500L
        const val USER_AGENT = "IPTVPlayer/1.0 (Recorder)"
    }
}
