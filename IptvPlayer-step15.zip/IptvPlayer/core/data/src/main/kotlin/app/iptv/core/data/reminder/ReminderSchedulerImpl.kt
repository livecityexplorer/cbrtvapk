package app.iptv.core.data.reminder

import android.content.Context
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.workDataOf
import app.iptv.core.domain.reminder.ReminderRequest
import app.iptv.core.domain.reminder.ReminderScheduler
import app.iptv.core.domain.util.ReminderTiming
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/** Reminders are unique WorkManager jobs, so no extra database table is needed. Delivery may be a bit late in Doze. */
@Singleton
class ReminderSchedulerImpl @Inject constructor(@ApplicationContext private val context: Context) : ReminderScheduler {
    private val work get() = WorkManager.getInstance(context)

    override fun schedule(request: ReminderRequest): Boolean {
        val delay = ReminderTiming.delayMillis(request.startTime, System.currentTimeMillis()) ?: return false
        val req = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(
                workDataOf(
                    ReminderWorker.KEY_CHANNEL_ID to request.channelId, ReminderWorker.KEY_CHANNEL_NAME to request.channelName,
                    ReminderWorker.KEY_TITLE to request.programTitle, ReminderWorker.KEY_START to request.startTime
                )
            ).build()
        work.enqueueUniqueWork(ReminderRequest.key(request.channelId, request.startTime), ExistingWorkPolicy.REPLACE, req)
        return true
    }

    override fun cancel(channelId: Long, startTime: Long) {
        work.cancelUniqueWork(ReminderRequest.key(channelId, startTime))
    }

    override fun observeScheduled(channelId: Long, startTime: Long): Flow<Boolean> =
        work.getWorkInfosForUniqueWorkFlow(ReminderRequest.key(channelId, startTime)).map { infos ->
            infos.any { it.state == WorkInfo.State.ENQUEUED || it.state == WorkInfo.State.RUNNING || it.state == WorkInfo.State.BLOCKED }
        }
}
