package app.iptv.core.data.reminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import app.iptv.core.domain.reminder.ReminderRequest
import java.text.DateFormat
import java.util.Date

class ReminderWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val channelId = inputData.getLong(KEY_CHANNEL_ID, -1L)
        val channelName = inputData.getString(KEY_CHANNEL_NAME).orEmpty()
        val title = inputData.getString(KEY_TITLE).orEmpty()
        val start = inputData.getLong(KEY_START, 0L)
        val ctx = applicationContext

        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Program reminders", NotificationManager.IMPORTANCE_HIGH))
        }
        // Opens the app on the channel; MainActivity reads EXTRA_CHANNEL_ID.
        val launch = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)?.apply {
            putExtra(ReminderRequest.EXTRA_CHANNEL_ID, channelId)
        }
        val pending = launch?.let { PendingIntent.getActivity(ctx, (channelId xor start).toInt(), it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT) }
        val time = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(start))

        val notification = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText("$time on $channelName")
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .apply { if (pending != null) setContentIntent(pending) }
            .build()
        try {
            if (NotificationManagerCompat.from(ctx).areNotificationsEnabled()) {
                NotificationManagerCompat.from(ctx).notify((channelId * 31 + start).toInt(), notification)
            }
        } catch (e: SecurityException) { /* POST_NOTIFICATIONS denied */ }
        return Result.success()
    }

    companion object {
        const val KEY_CHANNEL_ID = "channel_id"
        const val KEY_CHANNEL_NAME = "channel_name"
        const val KEY_TITLE = "title"
        const val KEY_START = "start"
        private const val CHANNEL_ID = "reminders"
    }
}
