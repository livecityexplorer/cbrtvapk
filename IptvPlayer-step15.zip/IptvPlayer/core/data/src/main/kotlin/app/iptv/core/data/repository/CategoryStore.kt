package app.iptv.core.data.repository

import app.iptv.core.data.db.CategoryEntity
import app.iptv.core.data.db.dao.CategoryDao
import app.iptv.core.domain.model.CategoryImport
import app.iptv.core.domain.model.CategoryKind
import app.iptv.core.domain.repository.PreferencesRepository
import app.iptv.core.domain.util.AdultFilter
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

/** Upserts categories while keeping user flags (hidden/locked/order); returns remoteId -> local id. */
@Singleton
class CategoryStore @Inject constructor(private val dao: CategoryDao, private val prefs: PreferencesRepository) {
    suspend fun sync(playlistId: Long, kind: CategoryKind, imports: List<CategoryImport>, ts: Long): Map<String, Long> {
        val keep = dao.keys(playlistId, kind).associateBy { it.remoteId }
        val hideAdult = prefs.settings.first().hideAdult // new adult-looking categories start hidden when the toggle is on
        val entities = imports.distinctBy { it.remoteId }.mapIndexed { i, c ->
            val k = keep[c.remoteId]
            CategoryEntity(
                id = k?.id ?: 0, playlistId = playlistId, remoteId = c.remoteId, name = c.name, kind = kind,
                sortOrder = k?.sortOrder ?: i, isHidden = k?.isHidden ?: (hideAdult && AdultFilter.isAdult(c.name)), isLocked = k?.isLocked ?: false, lastSeen = ts
            )
        }
        dao.upsertAll(entities)
        return dao.keys(playlistId, kind).associate { it.remoteId to it.id }
    }
}
