package app.iptv.core.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import app.iptv.core.domain.model.*
import app.iptv.core.domain.repository.LiveViewMode
import app.iptv.core.domain.repository.PreferencesRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.settingsStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

@Singleton
class PreferencesRepositoryImpl @Inject constructor(@ApplicationContext private val context: Context) : PreferencesRepository {
    private val store get() = context.settingsStore

    override val activePlaylistId: Flow<Long?> = store.data.map { it[ACTIVE_PLAYLIST] }
    override suspend fun setActivePlaylistId(id: Long) { store.edit { it[ACTIVE_PLAYLIST] = id } }

    override val liveViewMode: Flow<LiveViewMode> =
        store.data.map { p -> p[LIVE_VIEW]?.let { runCatching { LiveViewMode.valueOf(it) }.getOrNull() } ?: LiveViewMode.LIST }
    override suspend fun setLiveViewMode(mode: LiveViewMode) { store.edit { it[LIVE_VIEW] = mode.name } }

    override val lastEpgRefresh: Flow<Long> = store.data.map { it[LAST_EPG] ?: 0L }
    override suspend fun setLastEpgRefresh(timestamp: Long) { store.edit { it[LAST_EPG] = timestamp } }

    override val recordingsFolder: Flow<String?> = store.data.map { it[REC_FOLDER] }
    override suspend fun setRecordingsFolder(uri: String?) { store.edit { if (uri == null) it.remove(REC_FOLDER) else it[REC_FOLDER] = uri } }

    override val settings: Flow<AppSettings> = store.data.map { it.toSettings() }

    override suspend fun updateSettings(transform: (AppSettings) -> AppSettings) {
        store.edit { p ->
            val n = transform(p.toSettings())
            p[THEME] = n.theme.name
            p[EPG_AUTO] = n.epgAutoRefresh
            p[EPG_INTERVAL] = n.epgIntervalHours
            p[BUFFER] = n.bufferSize.name
            p[DECODER] = n.decoder.name
            p[ASPECT] = n.defaultAspect.name
            p[SUB_SIZE] = n.subtitleSizeSp
            p[SUB_COLOR] = n.subtitleColor.name
            p[HIDE_ADULT] = n.hideAdult
            if (n.pinHash == null) p.remove(PIN_HASH) else p[PIN_HASH] = n.pinHash
            p[DISCLAIMER] = n.disclaimerAccepted
        }
    }

    private fun Preferences.toSettings(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            theme = enumOf(this[THEME], d.theme),
            epgAutoRefresh = this[EPG_AUTO] ?: d.epgAutoRefresh,
            epgIntervalHours = (this[EPG_INTERVAL] ?: d.epgIntervalHours).coerceAtLeast(1),
            bufferSize = enumOf(this[BUFFER], d.bufferSize),
            decoder = enumOf(this[DECODER], d.decoder),
            defaultAspect = enumOf(this[ASPECT], d.defaultAspect),
            subtitleSizeSp = (this[SUB_SIZE] ?: d.subtitleSizeSp).coerceIn(AppSettings.SUBTITLE_MIN_SP, AppSettings.SUBTITLE_MAX_SP),
            subtitleColor = enumOf(this[SUB_COLOR], d.subtitleColor),
            hideAdult = this[HIDE_ADULT] ?: d.hideAdult,
            pinHash = this[PIN_HASH],
            disclaimerAccepted = this[DISCLAIMER] ?: d.disclaimerAccepted
        )
    }

    private inline fun <reified E : Enum<E>> enumOf(name: String?, default: E): E =
        name?.let { n -> enumValues<E>().firstOrNull { it.name == n } } ?: default

    private companion object {
        val REC_FOLDER = stringPreferencesKey("recordings_folder")
        val LAST_EPG = longPreferencesKey("last_epg_refresh")
        val ACTIVE_PLAYLIST = longPreferencesKey("active_playlist_id")
        val LIVE_VIEW = stringPreferencesKey("live_view_mode")
        val THEME = stringPreferencesKey("theme")
        val EPG_AUTO = booleanPreferencesKey("epg_auto_refresh")
        val EPG_INTERVAL = intPreferencesKey("epg_interval_hours")
        val BUFFER = stringPreferencesKey("buffer_size")
        val DECODER = stringPreferencesKey("decoder")
        val ASPECT = stringPreferencesKey("default_aspect")
        val SUB_SIZE = intPreferencesKey("subtitle_size_sp")
        val SUB_COLOR = stringPreferencesKey("subtitle_color")
        val HIDE_ADULT = booleanPreferencesKey("hide_adult")
        val PIN_HASH = stringPreferencesKey("pin_hash")
        val DISCLAIMER = booleanPreferencesKey("disclaimer_accepted")
    }
}
