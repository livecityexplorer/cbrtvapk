package app.iptv.core.data.repository

import androidx.paging.*
import androidx.room.withTransaction
import app.iptv.core.data.db.*
import app.iptv.core.data.db.dao.*
import app.iptv.core.domain.model.*
import app.iptv.core.domain.repository.*
import app.iptv.core.domain.util.ChannelOrdering
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

private val PAGING = PagingConfig(pageSize = 60, prefetchDistance = 120, enablePlaceholders = false)
private const val UPSERT_CHUNK = 500

@Singleton
class PlaylistRepositoryImpl @Inject constructor(private val dao: PlaylistDao) : PlaylistRepository {
    override fun observeAll() = dao.observeAll().map { l -> l.map { it.toDomain() } }
    override suspend fun get(id: Long) = dao.get(id)?.toDomain()
    override suspend fun save(playlist: Playlist): Long =
        if (playlist.id == 0L) dao.insert(playlist.toEntity()) else { dao.update(playlist.toEntity()); playlist.id }
    override suspend fun delete(id: Long) = dao.delete(id)
    override suspend fun markRefreshed(id: Long, timestamp: Long) = dao.markRefreshed(id, timestamp)
}

@Singleton
class ChannelRepositoryImpl @Inject constructor(
    private val db: AppDatabase, private val channelDao: ChannelDao,
    private val categoryDao: CategoryDao, private val categoryStore: CategoryStore
) : ChannelRepository {
    override fun observeCategories(playlistId: Long, kind: CategoryKind) =
        categoryDao.observe(playlistId, kind).map { l -> l.map { it.toDomain() } }

    override fun channels(playlistId: Long, categoryId: Long?, query: String): Flow<PagingData<Channel>> =
        Pager(PAGING) { channelDao.paging(playlistId, categoryId, query.trim()) }.flow.map { p -> p.map { it.toDomain() } }

    override fun observeFavorites() = channelDao.observeFavorites().map { l -> l.map { it.toDomain() } }
    override fun observeRecent(limit: Int) = channelDao.observeRecent(limit).map { l -> l.map { it.toDomain() } }
    override suspend fun getChannel(id: Long) = channelDao.get(id)?.toDomain()
    override suspend fun orderedChannelIds(playlistId: Long, categoryId: Long?) = channelDao.orderedIds(playlistId, categoryId)
    override suspend fun epgChannels(playlistId: Long) =
        channelDao.epgChannels(playlistId).map { EpgChannelInfo(it.id, it.remoteId, it.tvgId, it.tvgName, it.name) }
    override suspend fun searchChannels(query: String, limit: Int) = channelDao.search(query.trim(), limit).map { it.toDomain() }

    override suspend fun replaceLiveContent(playlistId: Long, categories: List<CategoryImport>, channels: List<ChannelImport>) {
        val ts = System.currentTimeMillis()
        db.withTransaction {
            val catIds = categoryStore.sync(playlistId, CategoryKind.LIVE, categories, ts)
            val keep = channelDao.keys(playlistId).associateBy { it.remoteId }
            channels.distinctBy { it.remoteId }.chunked(UPSERT_CHUNK).forEach { chunk ->
                channelDao.upsertAll(chunk.map { c ->
                    val k = keep[c.remoteId]
                    ChannelEntity(
                        id = k?.id ?: 0, playlistId = playlistId, categoryId = c.categoryRemoteId?.let { catIds[it] },
                        remoteId = c.remoteId, name = c.name, logoUrl = c.logoUrl, tvgId = c.tvgId, tvgName = c.tvgName,
                        streamUrl = c.streamUrl, number = c.number, archiveDays = c.archiveDays,
                        sortOrder = k?.sortOrder ?: 0, isLocked = k?.isLocked ?: false, lastSeen = ts
                    )
                })
            }
            channelDao.deleteStale(playlistId, ts)
            categoryDao.deleteStale(playlistId, CategoryKind.LIVE, ts)
        }
    }

    override suspend fun setCategoryHidden(categoryId: Long, hidden: Boolean) = categoryDao.setHidden(categoryId, hidden)
    override suspend fun setCategoryLocked(categoryId: Long, locked: Boolean) = categoryDao.setLocked(categoryId, locked)
    override suspend fun setChannelLocked(channelId: Long, locked: Boolean) = channelDao.setLocked(channelId, locked)
    override suspend fun saveChannelOrder(orderedChannelIds: List<Long>) {
        db.withTransaction { orderedChannelIds.forEachIndexed { i, id -> channelDao.setOrder(id, i) } }
    }

    override suspend fun moveChannel(playlistId: Long, categoryId: Long?, channelId: Long, up: Boolean) {
        db.withTransaction {
            val ids = channelDao.orderedIds(playlistId, categoryId)
            val moved = ChannelOrdering.move(ids, channelId, up) ?: return@withTransaction
            moved.forEachIndexed { i, id -> channelDao.setOrder(id, i) }
        }
    }
}

@Singleton
class EpgRepositoryImpl @Inject constructor(private val dao: EpgDao) : EpgRepository {
    override fun observeRange(tvgIds: List<String>, from: Long, to: Long): Flow<List<EpgProgram>> =
        if (tvgIds.isEmpty()) flowOf(emptyList())
        else dao.observeRange(tvgIds.take(900), from, to).map { l -> l.map { it.toDomain() } } // SQLite var limit

    override suspend fun nowAndNext(tvgId: String, now: Long) = dao.nowAndNext(tvgId, now).map { it.toDomain() }
    override fun observeNowAndNext(tvgId: String, now: Long) = dao.observeNowAndNext(tvgId, now).map { l -> l.map { it.toDomain() } }
    override suspend fun importPrograms(programs: List<EpgProgram>) {
        programs.chunked(UPSERT_CHUNK).forEach { dao.upsertAll(it.map { p -> p.toEntity().copy(id = 0) }) }
    }
    override suspend fun purgeEndedBefore(timestamp: Long) = dao.deleteEndedBefore(timestamp)
    override suspend fun search(query: String, now: Long, limit: Int) = dao.search(query.trim(), now, limit).map { it.toDomain() }
}

@Singleton
class VodRepositoryImpl @Inject constructor(
    private val db: AppDatabase, private val dao: VodDao,
    private val categoryDao: CategoryDao, private val categoryStore: CategoryStore
) : VodRepository {
    override fun movies(playlistId: Long, categoryId: Long?, query: String): Flow<PagingData<Movie>> =
        Pager(PAGING) { dao.moviesPaging(playlistId, categoryId, query.trim()) }.flow.map { p -> p.map { it.toDomain() } }
    override fun series(playlistId: Long, categoryId: Long?, query: String): Flow<PagingData<Series>> =
        Pager(PAGING) { dao.seriesPaging(playlistId, categoryId, query.trim()) }.flow.map { p -> p.map { it.toDomain() } }
    override fun observeEpisodes(seriesId: Long) = dao.observeEpisodes(seriesId).map { l -> l.map { it.toDomain() } }
    override fun observeRecentMovies(playlistId: Long, limit: Int) = dao.recentMovies(playlistId, limit).map { l -> l.map { it.toDomain() } }
    override fun observeRecentSeries(playlistId: Long, limit: Int) = dao.recentSeries(playlistId, limit).map { l -> l.map { it.toDomain() } }
    override suspend fun getMovie(id: Long) = dao.movie(id)?.toDomain()
    override fun observeMovie(id: Long) = dao.observeMovie(id).map { it?.toDomain() }
    override fun observeSeries(id: Long) = dao.observeSeries(id).map { it?.toDomain() }
    override suspend fun getEpisode(id: Long) = dao.episode(id)?.toDomain()
    override suspend fun getSeries(id: Long) = dao.seriesById(id)?.toDomain()
    override suspend fun searchMovies(query: String, limit: Int) = dao.searchMovies(query.trim(), limit).map { it.toDomain() }
    override suspend fun searchSeries(query: String, limit: Int) = dao.searchSeries(query.trim(), limit).map { it.toDomain() }

    override suspend fun replaceMovies(playlistId: Long, categories: List<CategoryImport>, movies: List<MovieImport>) {
        val ts = System.currentTimeMillis()
        db.withTransaction {
            val catIds = categoryStore.sync(playlistId, CategoryKind.MOVIE, categories, ts)
            val keep = dao.movieKeys(playlistId).associate { it.remoteId to it.id }
            movies.distinctBy { it.remoteId }.chunked(UPSERT_CHUNK).forEach { chunk ->
                dao.upsertMovies(chunk.map { m ->
                    MovieEntity(
                        id = keep[m.remoteId] ?: 0, playlistId = playlistId, categoryId = m.categoryRemoteId?.let { catIds[it] },
                        remoteId = m.remoteId, name = m.name, posterUrl = m.posterUrl, plot = m.plot, year = m.year,
                        rating = m.rating, castText = m.cast, streamUrl = m.streamUrl, addedAt = m.addedAt, lastSeen = ts
                    )
                })
            }
            dao.deleteStaleMovies(playlistId, ts)
            categoryDao.deleteStale(playlistId, CategoryKind.MOVIE, ts)
        }
    }

    override suspend fun replaceSeries(playlistId: Long, categories: List<CategoryImport>, series: List<SeriesImport>) {
        val ts = System.currentTimeMillis()
        db.withTransaction {
            val catIds = categoryStore.sync(playlistId, CategoryKind.SERIES, categories, ts)
            val keep = dao.seriesKeys(playlistId).associate { it.remoteId to it.id }
            series.distinctBy { it.remoteId }.chunked(UPSERT_CHUNK).forEach { chunk ->
                dao.upsertSeries(chunk.map { s ->
                    SeriesEntity(
                        id = keep[s.remoteId] ?: 0, playlistId = playlistId, categoryId = s.categoryRemoteId?.let { catIds[it] },
                        remoteId = s.remoteId, name = s.name, posterUrl = s.posterUrl, plot = s.plot, year = s.year,
                        rating = s.rating, castText = s.cast, addedAt = s.addedAt, lastSeen = ts
                    )
                })
            }
            dao.deleteStaleSeries(playlistId, ts)
            categoryDao.deleteStale(playlistId, CategoryKind.SERIES, ts)
        }
    }

    override suspend fun updateMovieDetail(id: Long, plot: String?, cast: String?, year: String?, rating: Float?) =
        dao.updateMovieDetail(id, plot, cast, year, rating)
    override suspend fun updateSeriesDetail(id: Long, plot: String?, cast: String?, year: String?, rating: Float?) =
        dao.updateSeriesDetail(id, plot, cast, year, rating)

    override suspend fun upsertEpisodes(seriesId: Long, episodes: List<Episode>) {
        db.withTransaction {
            val keep = dao.episodeKeys(seriesId).associate { (it.season to it.episodeNum) to it.id }
            dao.upsertEpisodes(episodes.distinctBy { it.season to it.episodeNum }.map { e ->
                EpisodeEntity(
                    id = keep[e.season to e.episodeNum] ?: 0, seriesId = seriesId, season = e.season, episodeNum = e.episodeNum,
                    title = e.title, plot = e.plot, imageUrl = e.imageUrl, streamUrl = e.streamUrl, durationSecs = e.durationSecs
                )
            })
        }
    }
}

@Singleton
class UserDataRepositoryImpl @Inject constructor(
    private val db: AppDatabase, private val favorites: FavoriteDao, private val history: WatchHistoryDao
) : UserDataRepository {
    override fun observeFavoriteIds() = favorites.observeIds().map { it.toSet() }
    override suspend fun setFavorite(channelId: Long, favorite: Boolean) {
        if (favorite) favorites.insert(FavoriteEntity(channelId, System.currentTimeMillis())) else favorites.delete(channelId)
    }
    override suspend fun saveProgress(entry: WatchHistory) {
        db.withTransaction {
            val existing = history.find(entry.type, entry.contentKey)
            history.upsert(entry.toEntity().copy(id = existing?.id ?: 0))
        }
    }
    override suspend fun getProgress(type: ContentType, contentKey: String) = history.find(type, contentKey)?.toDomain()
    override fun observeProgress(type: ContentType, contentKey: String) = history.observe(type, contentKey).map { it?.toDomain() }
    override fun observeProgressByType(type: ContentType) = history.observeByType(type).map { l -> l.map { it.toDomain() } }
    override fun observeContinueWatching(limit: Int) = history.observeContinueWatching(limit).map { l -> l.map { it.toDomain() } }
    override suspend fun removeHistory(id: Long) = history.delete(id)
    override suspend fun clearHistory() = history.clear()
}

@Singleton
class RecordingRepositoryImpl @Inject constructor(private val dao: RecordingDao) : RecordingRepository {
    override fun observeAll() = dao.observeAll().map { l -> l.map { it.toDomain() } }
    override suspend fun get(id: Long) = dao.get(id)?.toDomain()
    override suspend fun save(recording: Recording): Long {
        val rowId = dao.upsert(recording.toEntity())
        return if (recording.id == 0L) rowId else recording.id
    }
    override suspend fun delete(id: Long) = dao.delete(id)
    override suspend fun dueToStart(now: Long) = dao.due(now).map { it.toDomain() }
    override suspend fun updateStatus(id: Long, status: RecordingStatus, filePath: String?) = dao.updateStatus(id, status, filePath)
    override suspend fun updateProgress(id: Long, sizeBytes: Long) = dao.updateProgress(id, sizeBytes)
}
