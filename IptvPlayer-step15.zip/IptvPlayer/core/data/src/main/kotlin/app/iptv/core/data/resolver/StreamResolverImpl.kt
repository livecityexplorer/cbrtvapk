package app.iptv.core.data.resolver

import app.iptv.core.data.di.SourceClientFactory
import app.iptv.core.data.network.toIptvError
import app.iptv.core.data.stalker.StalkerClient
import app.iptv.core.domain.error.IptvError
import app.iptv.core.domain.model.Channel
import app.iptv.core.domain.model.EpgProgram
import app.iptv.core.domain.model.PlaylistType
import app.iptv.core.domain.repository.PlaylistRepository
import app.iptv.core.domain.repository.StreamResolver
import app.iptv.core.domain.util.Catchup
import app.iptv.core.domain.util.StalkerStreamUrl
import kotlinx.coroutines.CancellationException
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class StreamResolverImpl @Inject constructor(
    private val playlists: PlaylistRepository,
    private val clients: SourceClientFactory
) : StreamResolver {

    // Stalker needs a handshake; keep the authenticated client so zapping isn't slowed by 3 extra requests.
    private val stalker = ConcurrentHashMap<Long, StalkerClient>()

    override suspend fun resolveLive(channel: Channel): String {
        if (!StalkerStreamUrl.isStalker(channel.streamUrl)) return channel.streamUrl
        val cmd = StalkerStreamUrl.decode(channel.streamUrl)
        var last: Throwable? = null
        repeat(2) { attempt -> // 2nd attempt = fresh handshake, in case the cached token expired
            try {
                if (attempt > 0) stalker.remove(channel.playlistId)
                val client = stalker.getOrPut(channel.playlistId) {
                    val p = playlists.get(channel.playlistId) ?: throw IptvError.InvalidInput("This playlist no longer exists.")
                    clients.stalker(p)
                }
                return client.resolveStreamUrl(cmd)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                last = e
            }
        }
        stalker.remove(channel.playlistId)
        throw (last ?: IllegalStateException()).toIptvError()
    }

    override suspend fun resolveCatchup(channel: Channel, program: EpgProgram): String? {
        val p = playlists.get(channel.playlistId) ?: return null
        if (p.type != PlaylistType.XTREAM || channel.archiveDays <= 0) return null
        return try {
            clients.xtream(p).catchupUrl(channel.remoteId, program.startTime, Catchup.durationMinutes(program))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            throw e.toIptvError()
        }
    }
}
