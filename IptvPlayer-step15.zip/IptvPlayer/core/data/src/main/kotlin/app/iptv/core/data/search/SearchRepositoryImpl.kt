package app.iptv.core.data.search

import app.iptv.core.data.db.dao.ChannelDao
import app.iptv.core.data.db.dao.SearchDao
import app.iptv.core.data.db.toDomain
import app.iptv.core.domain.model.ProgramHit
import app.iptv.core.domain.model.SearchResults
import app.iptv.core.domain.repository.SearchRepository
import app.iptv.core.domain.util.EpgKey
import app.iptv.core.domain.util.SearchQuery
import app.iptv.core.domain.util.SearchTokens
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SearchRepositoryImpl @Inject constructor(
    private val dao: SearchDao,
    private val channelDao: ChannelDao
) : SearchRepository {

    /** EPG key -> channel ids of one playlist; rebuilt at most once a minute (a search runs on every pause in typing). */
    private class KeyIndex(val builtAt: Long, val keyToIds: Map<String, List<Long>>)
    private val indexes = ConcurrentHashMap<Long, KeyIndex>()

    override suspend fun search(playlistId: Long, query: String, limitPerType: Int): SearchResults = coroutineScope {
        val t = SearchQuery.parse(query) ?: return@coroutineScope SearchResults()
        val channels = async { dao.channels(playlistId, t.t1, t.t2, t.t3, limitPerType).map { it.toDomain() } }
        val movies = async { dao.movies(playlistId, t.t1, t.t2, t.t3, limitPerType).map { it.toDomain() } }
        val series = async { dao.series(playlistId, t.t1, t.t2, t.t3, limitPerType).map { it.toDomain() } }
        val programs = async { programHits(playlistId, t, limitPerType) }
        SearchResults(channels.await(), movies.await(), series.await(), programs.await())
    }

    private suspend fun programHits(playlistId: Long, t: SearchTokens, limit: Int): List<ProgramHit> {
        val now = System.currentTimeMillis()
        val candidates = dao.programs(t.t1, t.t2, t.t3, now, now + HORIZON_MS, PROGRAM_CANDIDATES)
        if (candidates.isEmpty()) return emptyList()

        val index = indexFor(playlistId).keyToIds
        val picked = ArrayList<Pair<app.iptv.core.data.db.EpgProgramEntity, Long>>()
        for (p in candidates) {
            val channelId = index[p.channelTvgId]?.firstOrNull() ?: continue // programme of another playlist's channel
            picked += p to channelId
            if (picked.size >= limit) break
        }
        if (picked.isEmpty()) return emptyList()
        val channels = dao.channelsByIds(picked.map { it.second }.distinct()).associateBy { it.id }
        return picked.mapNotNull { (p, id) -> channels[id]?.let { ProgramHit(p.toDomain(), it.toDomain()) } }
    }

    private suspend fun indexFor(playlistId: Long): KeyIndex {
        val now = System.currentTimeMillis()
        indexes[playlistId]?.takeIf { now - it.builtAt < INDEX_TTL_MS }?.let { return it }
        val built = channelDao.epgChannels(playlistId)
            .groupBy({ EpgKey.of(it.tvgId, it.tvgName, it.name) }, { it.id })
        return KeyIndex(now, built).also { indexes[playlistId] = it }
    }

    private companion object {
        const val HORIZON_MS = 48L * 60 * 60 * 1000
        const val PROGRAM_CANDIDATES = 400
        const val INDEX_TTL_MS = 60_000L
    }
}
