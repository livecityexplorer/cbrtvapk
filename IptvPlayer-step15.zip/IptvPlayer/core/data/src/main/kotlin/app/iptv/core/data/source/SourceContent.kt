package app.iptv.core.data.source

import app.iptv.core.domain.model.*

data class LiveContent(val categories: List<CategoryImport>, val channels: List<ChannelImport>, val epgUrls: List<String> = emptyList())
data class VodContent(val categories: List<CategoryImport>, val movies: List<MovieImport>)
data class SeriesContent(val categories: List<CategoryImport>, val series: List<SeriesImport>)
