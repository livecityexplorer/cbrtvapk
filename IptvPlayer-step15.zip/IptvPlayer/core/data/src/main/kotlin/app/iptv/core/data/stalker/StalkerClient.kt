package app.iptv.core.data.stalker

import app.iptv.core.data.network.RawHttpApi
import app.iptv.core.data.network.arr
import app.iptv.core.data.network.field
import app.iptv.core.data.network.int
import app.iptv.core.data.network.str
import app.iptv.core.data.network.toIptvError
import app.iptv.core.data.source.LiveContent
import app.iptv.core.domain.error.IptvError
import app.iptv.core.domain.model.EpgProgram
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import java.net.URLEncoder

/**
 * Stalker/Ministra portal client: handshake -> get_profile -> channels/genres/EPG, with link resolution
 * (create_link) at play time. Live TV only; portal VOD is not implemented.
 */
class StalkerClient(
    private val api: RawHttpApi,
    private val json: Json,
    portalUrl: String,
    macAddress: String,
    private val timezone: String = "Europe/London"
) {
    private val mac = StalkerUrls.normalizeMac(macAddress)
        ?: throw IptvError.InvalidInput("Invalid MAC address. Expected format 00:1A:79:AA:BB:CC.")
    private val candidates = StalkerUrls.candidates(portalUrl).ifEmpty { throw IptvError.InvalidInput("Enter the portal address.") }
    private val deviceId = StalkerUrls.deviceId(mac)
    @Volatile private var endpoint: String? = null
    @Volatile private var token: String? = null
    private var mapper: StalkerMapper? = null

    /** Handshake + profile; doubles as the "test connection" step. */
    suspend fun authenticate() {
        handshake()
        call(
            mapOf(
                "type" to "stb", "action" to "get_profile", "hd" to "1", "num_banks" to "2",
                "ver" to "ImageDescription: 0.2.18-r14-pub-250; PORTAL version: 5.1.0; API Version: JS API version: 328",
                "sn" to deviceId.take(13), "stb_type" to "MAG250", "client_type" to "STB", "image_version" to "218",
                "video_out" to "hdmi", "device_id" to deviceId, "device_id2" to deviceId, "signature" to "",
                "auth_second_step" to "1", "hw_version" to "1.7-BD-00", "not_valid_token" to "0",
                "timestamp" to (System.currentTimeMillis() / 1000).toString(), "api_signature" to "262", "prehash" to ""
            )
        )
    }

    suspend fun fetchLive(): LiveContent {
        ensureAuth()
        val m = mapper ?: throw IptvError.InvalidResponse()
        val genres = m.genres(call(mapOf("type" to "itv", "action" to "get_genres")).field("js"))
        var channels = m.channels(call(mapOf("type" to "itv", "action" to "get_all_channels")).field("js").dataArray())
        if (channels.isEmpty()) channels = pagedChannels(m)
        if (channels.isEmpty()) throw IptvError.InvalidResponse("The portal returned no channels. Check that the MAC address is active.")
        return LiveContent(genres, channels)
    }

    /** Turns a stored `cmd` into a playable URL (links are short-lived, call right before playback). */
    suspend fun resolveStreamUrl(cmd: String): String {
        ensureAuth()
        val root = call(mapOf("type" to "itv", "action" to "create_link", "cmd" to cmd, "forced_storage" to "undefined", "disable_ad" to "0", "download" to "0"))
        val link = root.field("js").field("cmd").str() ?: throw IptvError.InvalidResponse("The portal did not return a stream link.")
        return (mapper ?: StalkerMapper("")).cleanLink(link)
    }

    suspend fun shortEpg(channelId: String, epgKey: String, size: Int = 10): List<EpgProgram> {
        ensureAuth()
        val js = call(mapOf("type" to "itv", "action" to "get_short_epg", "ch_id" to channelId, "size" to size.toString())).field("js")
        return (mapper ?: return emptyList()).epg(js.dataArray(), epgKey)
    }

    /** Bulk EPG for [hours] ahead. [keysByChannelId] maps portal channel id -> EpgKey; others are ignored. */
    suspend fun fetchEpg(keysByChannelId: Map<String, String>, hours: Int = 6): List<EpgProgram> {
        ensureAuth()
        val m = mapper ?: return emptyList()
        val data = call(mapOf("type" to "itv", "action" to "get_epg_info", "period" to hours.toString())).field("js").field("data") as? JsonObject
            ?: return emptyList()
        return data.entries.flatMap { (chId, items) -> keysByChannelId[chId]?.let { m.epg(items.arr(), it) }.orEmpty() }
    }

    // ---------------- internals ----------------

    private suspend fun ensureAuth() { if (token == null || endpoint == null) authenticate() }

    private suspend fun handshake() {
        var last: IptvError? = null
        var network: IptvError? = null
        for (c in candidates) {
            try {
                val root = request(c, mapOf("type" to "stb", "action" to "handshake", "token" to ""), authorized = false)
                val tok = root.field("js").field("token").str()
                if (tok != null) {
                    endpoint = c; token = tok; mapper = StalkerMapper(StalkerUrls.portalRoot(c))
                    return
                }
                last = IptvError.InvalidResponse("The portal did not return a token.")
            } catch (e: IptvError) {
                if (e is IptvError.InvalidCredentials) throw e
                if (e is IptvError.Network) network = e
                last = e
            }
        }
        throw network ?: last ?: IptvError.InvalidInput("Enter the portal address.")
    }

    private suspend fun pagedChannels(m: StalkerMapper): List<app.iptv.core.domain.model.ChannelImport> {
        val out = ArrayList<app.iptv.core.domain.model.ChannelImport>()
        var page = 1
        var total = Int.MAX_VALUE
        while (out.size < total && page <= 500) {
            val js = call(
                mapOf(
                    "type" to "itv", "action" to "get_ordered_list", "genre" to "*", "force_ch_link_check" to "",
                    "fav" to "0", "sortby" to "number", "hd" to "0", "p" to page.toString()
                )
            ).field("js")
            total = js.field("total_items").int() ?: 0
            val items = m.channels(js.dataArray())
            if (items.isEmpty()) break
            out += items
            page++
        }
        return out
    }

    private suspend fun call(params: Map<String, String>): JsonElement {
        ensureAuthIfNeeded(params)
        val ep = endpoint ?: throw IptvError.InvalidResponse("Not connected to the portal.")
        return request(ep, params, authorized = true)
    }

    private suspend fun ensureAuthIfNeeded(params: Map<String, String>) {
        // get_profile is called from authenticate() itself, after the handshake has set the endpoint.
        if (params["action"] != "get_profile" && (token == null || endpoint == null)) authenticate()
    }

    private suspend fun request(base: String, params: Map<String, String>, authorized: Boolean): JsonElement =
        withContext(Dispatchers.IO) {
            try {
                val text = api.get(buildUrl(base, params), headers(authorized)).use { it.string() }
                if (text.contains("Authorization failed", ignoreCase = true)) {
                    throw IptvError.InvalidCredentials("This MAC address is not authorized on the portal.")
                }
                json.parseToJsonElement(text)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                throw e.toIptvError()
            }
        }

    private fun buildUrl(base: String, params: Map<String, String>): String =
        base + "?" + (params + ("JsHttpRequest" to "1-xml")).entries.joinToString("&") { "${enc(it.key)}=${enc(it.value)}" }

    private fun headers(authorized: Boolean): Map<String, String> = buildMap {
        put("Cookie", "mac=$mac; stb_lang=en; timezone=$timezone")
        put("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
        put("X-User-Agent", "Model: MAG250; Link: WiFi")
        put("Accept", "*/*")
        val t = token
        if (authorized && t != null) put("Authorization", "Bearer $t")
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
}
