package app.iptv.core.data.stalker

import app.iptv.core.data.network.*
import app.iptv.core.domain.model.CategoryImport
import app.iptv.core.domain.model.ChannelImport
import app.iptv.core.domain.model.EpgProgram
import app.iptv.core.domain.util.StalkerStreamUrl
import kotlinx.serialization.json.*

internal fun JsonElement?.dataArray(): JsonArray = when (this) {
    is JsonArray -> this
    is JsonObject -> this["data"].arr()
    else -> JsonArray(emptyList())
}

internal class StalkerMapper(private val portalRoot: String) {

    fun genres(js: JsonElement?): List<CategoryImport> = js.dataArray().mapNotNull { e ->
        val id = e.field("id").str() ?: return@mapNotNull null
        if (id == "*") null else CategoryImport(id, e.field("title").str() ?: id)
    }

    fun channels(items: JsonArray): List<ChannelImport> = items.mapNotNull { e ->
        val id = e.field("id").str() ?: return@mapNotNull null
        val cmd = e.field("cmd").str() ?: e.field("cmds").arr().firstOrNull().field("url").str() ?: return@mapNotNull null
        ChannelImport(
            remoteId = id, name = e.field("name").str() ?: "Channel $id", logoUrl = logo(e.field("logo").str()),
            tvgId = e.field("xmltv_id").str(), tvgName = null, streamUrl = StalkerStreamUrl.encode(cmd),
            number = e.field("number").int() ?: 0, archiveDays = e.field("tv_archive_duration").int()?.takeIf { it > 0 } ?: 0,
            categoryRemoteId = e.field("tv_genre_id").str()?.takeIf { it != "0" }
        )
    }

    fun epg(items: JsonArray, epgKey: String): List<EpgProgram> = items.mapNotNull { e ->
        val start = e.field("start_timestamp").long()?.times(1000) ?: parseLooseDateTime(e.field("time").str())
        val end = e.field("stop_timestamp").long()?.times(1000) ?: parseLooseDateTime(e.field("time_to").str())
        val title = e.field("name").str()
        if (start == null || end == null || end <= start || title == null) null
        else EpgProgram(channelTvgId = epgKey, title = title, description = e.field("descr").str(), startTime = start, endTime = end)
    }

    /** `ffmpeg http://x/y`, `auto http://x/y`, `ffrt3 http://...` -> the bare URL. */
    fun cleanLink(cmd: String): String {
        val t = cmd.trim()
        return t.split(' ').firstOrNull { it.contains("://") } ?: t
    }

    private fun logo(l: String?): String? = when {
        l == null -> null
        l.startsWith("http", true) -> l
        else -> "$portalRoot/misc/logos/320/${l.trimStart('/')}"
    }
}
