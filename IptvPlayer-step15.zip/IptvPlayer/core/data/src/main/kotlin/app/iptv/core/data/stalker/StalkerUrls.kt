package app.iptv.core.data.stalker

import java.security.MessageDigest

object StalkerUrls {
    private val MAC = Regex("^([0-9A-F]{2}:){5}[0-9A-F]{2}$")

    /** Accepts `aa:bb:..` or `AA-BB-..`; returns upper-case colon form or null when invalid. */
    fun normalizeMac(input: String): String? =
        input.trim().uppercase().replace('-', ':').takeIf { MAC.matches(it) }

    /** Portal endpoints to try, in order, for a user-entered URL such as `http://host/c/`. */
    fun candidates(input: String): List<String> {
        var s = input.trim()
        if (s.isEmpty()) return emptyList()
        if (!s.contains("://")) s = "http://$s"
        s = s.substringBefore('#').substringBefore('?').trimEnd('/')
        if (s.endsWith("/portal.php", true) || s.endsWith("/load.php", true)) return listOf(s)
        if (s.endsWith("/c", true)) {
            val cand = s.dropLast(2).trimEnd('/')
            if (cand.contains("://") && cand.substringAfter("://").isNotEmpty()) s = cand
        }
        return if (s.contains("stalker_portal", true)) listOf("$s/server/load.php", "$s/portal.php")
        else listOf("$s/portal.php", "$s/stalker_portal/server/load.php", "$s/server/load.php")
    }

    fun portalRoot(endpoint: String): String = endpoint.removeSuffix("/server/load.php").removeSuffix("/load.php").removeSuffix("/portal.php")

    /** Deterministic fake STB identifiers derived from the MAC. */
    fun deviceId(mac: String): String =
        MessageDigest.getInstance("SHA-256").digest(mac.toByteArray()).joinToString("") { "%02X".format(it) }
}
