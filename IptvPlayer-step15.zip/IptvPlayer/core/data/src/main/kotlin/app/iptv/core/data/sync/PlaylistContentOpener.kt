package app.iptv.core.data.sync

import android.content.Context
import android.net.Uri
import app.iptv.core.data.parser.XmltvParser
import app.iptv.core.domain.error.IptvError
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.InputStream
import javax.inject.Inject
import javax.inject.Singleton

/** Opens an M3U source: http(s) download or a SAF `content://` document. Transparently un-gzips. */
@Singleton
class PlaylistContentOpener @Inject constructor(
    @ApplicationContext private val context: Context,
    private val client: OkHttpClient
) {
    suspend fun open(url: String): InputStream = withContext(Dispatchers.IO) {
        val raw: InputStream = if (url.startsWith("content://")) {
            try {
                context.contentResolver.openInputStream(Uri.parse(url))
            } catch (e: SecurityException) {
                throw IptvError.InvalidInput("Access to this file was lost. Choose the file again.")
            } catch (e: java.io.FileNotFoundException) {
                throw IptvError.InvalidInput("The selected file no longer exists. Choose it again.")
            } ?: throw IptvError.InvalidInput("Can't open the selected file.")
        } else {
            val request = Request.Builder().url(url).header("User-Agent", USER_AGENT).build()
            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                val code = response.code
                response.close()
                throw when (code) {
                    401, 403 -> IptvError.InvalidCredentials("The server refused access to this playlist ($code).")
                    404 -> IptvError.InvalidResponse("Playlist not found at this address (404).")
                    else -> IptvError.Server(code)
                }
            }
            response.body?.byteStream() ?: run { response.close(); throw IptvError.InvalidResponse("The server sent an empty response.") }
        }
        XmltvParser.openStream(raw) // handles .m3u.gz as well
    }

    private companion object { const val USER_AGENT = "IPTVPlayer/1.0 (Android)" }
}
