package app.iptv.core.data.sync

import app.iptv.core.data.di.SourceClientFactory
import app.iptv.core.data.network.toIptvError
import app.iptv.core.data.parser.M3uParser
import app.iptv.core.domain.error.IptvError
import app.iptv.core.domain.model.Playlist
import app.iptv.core.domain.model.PlaylistType
import app.iptv.core.domain.repository.ChannelRepository
import app.iptv.core.domain.repository.PlaylistRepository
import app.iptv.core.domain.repository.VodRepository
import app.iptv.core.domain.sync.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.InputStream
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PlaylistSyncerImpl @Inject constructor(
    private val playlists: PlaylistRepository,
    private val channels: ChannelRepository,
    private val vod: VodRepository,
    private val clients: SourceClientFactory,
    private val m3u: M3uParser,
    private val opener: PlaylistContentOpener
) : PlaylistSyncer {

    override fun sync(playlistId: Long): Flow<SyncState> = channelFlow {
        try {
            val p = playlists.get(playlistId) ?: throw IptvError.InvalidInput("This playlist no longer exists.")
            send(SyncState.Running(SyncStage.CONNECTING))
            val progress: (SyncStage, Int) -> Unit = { stage, n -> trySend(SyncState.Running(stage, n)) }
            val summary = when (p.type) {
                PlaylistType.M3U -> syncM3u(p, progress)
                PlaylistType.XTREAM -> syncXtream(p, progress)
                PlaylistType.STALKER -> syncStalker(p, progress)
            }
            playlists.markRefreshed(playlistId, System.currentTimeMillis())
            send(SyncState.Success(summary))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            send(SyncState.Failed(e.toIptvError()))
        }
    }.flowOn(Dispatchers.IO)

    override suspend fun testConnection(draft: Playlist): ConnectionInfo = withContext(Dispatchers.IO) {
        try {
            when (draft.type) {
                PlaylistType.M3U -> {
                    opener.open(draft.url).use { if (!looksLikeM3u(it)) throw IptvError.InvalidResponse("This doesn't look like an M3U playlist.") }
                    ConnectionInfo()
                }
                PlaylistType.XTREAM -> clients.xtream(draft).authenticate().let { ConnectionInfo(it.status, it.expiresAt, it.maxConnections) }
                PlaylistType.STALKER -> { clients.stalker(draft).authenticate(); ConnectionInfo() }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            throw e.toIptvError()
        }
    }

    private suspend fun syncM3u(p: Playlist, progress: (SyncStage, Int) -> Unit): SyncSummary {
        val result = opener.open(p.url).use { stream -> m3u.parse(stream) { n -> progress(SyncStage.LIVE, n) } }
        // Keep the old content if the download was garbage, instead of wiping the library.
        if (result.channels.isEmpty()) throw IptvError.InvalidResponse("No channels found. Is this an M3U playlist?")
        progress(SyncStage.SAVING, result.channels.size)
        channels.replaceLiveContent(p.id, result.categories, result.channels)
        mergeEpgUrls(p, result.epgUrls)
        return SyncSummary(result.channels.size, 0, 0, result.categories.size)
    }

    private suspend fun syncXtream(p: Playlist, progress: (SyncStage, Int) -> Unit): SyncSummary {
        val client = clients.xtream(p)
        client.authenticate()
        progress(SyncStage.LIVE, 0)
        val live = client.fetchLive()
        progress(SyncStage.SAVING, live.channels.size)
        channels.replaceLiveContent(p.id, live.categories, live.channels)
        mergeEpgUrls(p, live.epgUrls)

        // Many panels have no VOD/series and answer oddly; that must not fail the whole sync.
        progress(SyncStage.MOVIES, 0)
        val movies = try { client.fetchMovies() } catch (e: IptvError.InvalidResponse) { null }
        movies?.let { vod.replaceMovies(p.id, it.categories, it.movies) }
        progress(SyncStage.SERIES, 0)
        val series = try { client.fetchSeries() } catch (e: IptvError.InvalidResponse) { null }
        series?.let { vod.replaceSeries(p.id, it.categories, it.series) }

        return SyncSummary(live.channels.size, movies?.movies?.size ?: 0, series?.series?.size ?: 0, live.categories.size)
    }

    private suspend fun syncStalker(p: Playlist, progress: (SyncStage, Int) -> Unit): SyncSummary {
        val client = clients.stalker(p)
        client.authenticate()
        progress(SyncStage.LIVE, 0)
        val live = client.fetchLive()
        progress(SyncStage.SAVING, live.channels.size)
        channels.replaceLiveContent(p.id, live.categories, live.channels)
        return SyncSummary(live.channels.size, 0, 0, live.categories.size)
    }

    private suspend fun mergeEpgUrls(p: Playlist, discovered: List<String>) {
        val merged = (p.epgUrls + discovered).map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        if (merged != p.epgUrls) playlists.save(p.copy(epgUrls = merged)) // markRefreshed runs afterwards
    }

    private fun looksLikeM3u(stream: InputStream): Boolean {
        val reader = stream.bufferedReader(Charsets.UTF_8)
        repeat(200) {
            val line = reader.readLine()?.trim()?.removePrefix("\uFEFF") ?: return false
            if (line.startsWith("#EXTM3U", true) || line.startsWith("#EXTINF", true)) return true
        }
        return false
    }
}
