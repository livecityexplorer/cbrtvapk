package app.iptv.core.data.vod

import app.iptv.core.data.di.SourceClientFactory
import app.iptv.core.data.network.toIptvError
import app.iptv.core.domain.model.Movie
import app.iptv.core.domain.model.PlaylistType
import app.iptv.core.domain.model.Series
import app.iptv.core.domain.repository.PlaylistRepository
import app.iptv.core.domain.repository.VodDetailsLoader
import app.iptv.core.domain.repository.VodRepository
import kotlinx.coroutines.CancellationException
import javax.inject.Inject
import javax.inject.Singleton

/** Xtream's list endpoints omit plot/cast/episodes; they come from get_vod_info / get_series_info when a title is opened. */
@Singleton
class VodDetailsLoaderImpl @Inject constructor(
    private val playlists: PlaylistRepository,
    private val vod: VodRepository,
    private val clients: SourceClientFactory
) : VodDetailsLoader {

    override suspend fun loadMovie(movie: Movie) {
        val p = playlists.get(movie.playlistId) ?: return
        if (p.type != PlaylistType.XTREAM) return
        try {
            val d = clients.xtream(p).vodInfo(movie.remoteId)
            // keep what the list already had when the detail response lacks a field
            vod.updateMovieDetail(movie.id, d.plot ?: movie.plot, d.cast ?: movie.cast, d.year ?: movie.year, d.rating ?: movie.rating)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            throw e.toIptvError()
        }
    }

    override suspend fun loadSeries(series: Series) {
        val p = playlists.get(series.playlistId) ?: return
        if (p.type != PlaylistType.XTREAM) return
        try {
            val d = clients.xtream(p).seriesInfo(series.remoteId)
            vod.updateSeriesDetail(series.id, d.plot ?: series.plot, d.cast ?: series.cast, d.year ?: series.year, d.rating ?: series.rating)
            vod.upsertEpisodes(series.id, d.episodes.map { it.toDomain(series.id) }) // ids are kept, so watch progress survives
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            throw e.toIptvError()
        }
    }
}
