package app.iptv.core.data.work

import android.content.Context
import androidx.work.*
import app.iptv.core.domain.repository.PlaylistRepository
import app.iptv.core.domain.sync.EpgSyncer
import app.iptv.core.domain.sync.PlaylistSyncer
import app.iptv.core.domain.sync.SyncState
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.lastOrNull
import java.util.concurrent.TimeUnit

@EntryPoint
@InstallIn(SingletonComponent::class)
interface WorkerEntryPoint {
    fun playlists(): PlaylistRepository
    fun playlistSyncer(): PlaylistSyncer
    fun epgSyncer(): EpgSyncer
}

/** Background refresh: re-syncs every playlist, then its EPG. */
class PeriodicRefreshWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val ep = EntryPointAccessors.fromApplication(applicationContext, WorkerEntryPoint::class.java)
        val all = ep.playlists().observeAll().first()
        var failures = 0
        for (p in all) {
            try {
                if (ep.playlistSyncer().sync(p.id).lastOrNull() is SyncState.Failed) failures++
                ep.epgSyncer().refresh(p.id)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                failures++
            }
        }
        return if (all.isNotEmpty() && failures >= all.size && runAttemptCount < 2) Result.retry() else Result.success()
    }
}

object RefreshScheduler {
    private const val WORK_NAME = "periodic_refresh"

    /** [intervalHours] is user-configurable from step 13; WorkManager's minimum is 15 minutes. */
    fun schedule(context: Context, intervalHours: Long = 12) {
        val request = PeriodicWorkRequestBuilder<PeriodicRefreshWorker>(intervalHours, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, request)
    }

    fun cancel(context: Context) { WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME) }
}
