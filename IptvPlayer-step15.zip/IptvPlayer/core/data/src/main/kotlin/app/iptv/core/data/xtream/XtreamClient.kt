package app.iptv.core.data.xtream

import app.iptv.core.data.network.RawHttpApi
import app.iptv.core.data.network.toIptvError
import app.iptv.core.data.source.LiveContent
import app.iptv.core.data.source.SeriesContent
import app.iptv.core.data.source.VodContent
import app.iptv.core.domain.model.EpgProgram
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.decodeFromStream
import java.util.TimeZone

/** Xtream Codes `player_api.php` client. All failures surface as [app.iptv.core.domain.error.IptvError]. */
class XtreamClient(
    private val api: RawHttpApi,
    private val json: Json,
    serverUrl: String,
    username: String,
    password: String,
    private val preferredLiveFormat: String = "m3u8"
) {
    val urls = XtreamUrlBuilder(serverUrl, username, password)
    private val mapper = XtreamMapper(urls)
    @Volatile var account: XtreamAccount? = null
        private set

    /** Also serves as the "test connection" step. Throws on bad credentials / expired / disabled accounts. */
    suspend fun authenticate(): XtreamAccount =
        mapper.account(get(urls.playerApi())).also { account = it }

    suspend fun fetchLive(): LiveContent = coroutineScope {
        val acc = account ?: authenticate()
        val format = liveFormat(acc)
        val cats = async { mapper.categories(get(urls.playerApi("get_live_categories"))) }
        val streams = async { mapper.liveChannels(get(urls.playerApi("get_live_streams")), format) }
        LiveContent(cats.await(), streams.await(), listOf(urls.xmltv()))
    }

    suspend fun fetchMovies(): VodContent = coroutineScope {
        account ?: authenticate()
        val cats = async { mapper.categories(get(urls.playerApi("get_vod_categories"))) }
        val items = async { mapper.movies(get(urls.playerApi("get_vod_streams"))) }
        VodContent(cats.await(), items.await())
    }

    suspend fun fetchSeries(): SeriesContent = coroutineScope {
        account ?: authenticate()
        val cats = async { mapper.categories(get(urls.playerApi("get_series_categories"))) }
        val items = async { mapper.series(get(urls.playerApi("get_series"))) }
        SeriesContent(cats.await(), items.await())
    }

    suspend fun seriesInfo(remoteSeriesId: String): XtreamSeriesDetail =
        mapper.seriesDetail(get(urls.playerApi("get_series_info", mapOf("series_id" to remoteSeriesId))))

    suspend fun vodInfo(remoteVodId: String): XtreamVodDetail =
        mapper.vodDetail(get(urls.playerApi("get_vod_info", mapOf("vod_id" to remoteVodId))))

    suspend fun shortEpg(streamId: String, epgKey: String, limit: Int = 4): List<EpgProgram> =
        mapper.epg(get(urls.playerApi("get_short_epg", mapOf("stream_id" to streamId, "limit" to limit.toString()))), epgKey)

    /** Full per-channel table incl. past programmes (needed for catch-up). */
    suspend fun fullEpg(streamId: String, epgKey: String): List<EpgProgram> =
        mapper.epg(get(urls.playerApi("get_simple_data_table", mapOf("stream_id" to streamId))), epgKey)

    fun timeshiftUrl(streamId: String, startEpochMs: Long, durationMinutes: Int): String {
        val tz = account?.serverTimezone?.let { TimeZone.getTimeZone(it) } ?: TimeZone.getTimeZone("UTC")
        return urls.timeshift(streamId, startEpochMs, durationMinutes, tz)
    }

    /** Authenticates first if needed (the panel's timezone is required to format the start time). */
    suspend fun catchupUrl(streamId: String, startEpochMs: Long, durationMinutes: Int): String {
        val acc = account ?: authenticate()
        val tz = acc.serverTimezone?.let { TimeZone.getTimeZone(it) } ?: TimeZone.getTimeZone("UTC")
        return urls.timeshift(streamId, startEpochMs, durationMinutes, tz)
    }

    private fun liveFormat(acc: XtreamAccount): String {
        val allowed = acc.allowedFormats
        return when {
            allowed.isEmpty() || preferredLiveFormat in allowed -> preferredLiveFormat
            else -> allowed.firstOrNull { it == "m3u8" || it == "ts" } ?: preferredLiveFormat
        }
    }

    @OptIn(ExperimentalSerializationApi::class)
    private suspend fun get(url: String): JsonElement = withContext(Dispatchers.IO) {
        try {
            api.get(url, mapOf("Accept" to "application/json")).use { json.decodeFromStream<JsonElement>(it.byteStream()) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            throw e.toIptvError()
        }
    }
}
