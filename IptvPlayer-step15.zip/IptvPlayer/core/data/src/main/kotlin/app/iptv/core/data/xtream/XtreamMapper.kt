package app.iptv.core.data.xtream

import app.iptv.core.data.network.*
import app.iptv.core.domain.error.IptvError
import app.iptv.core.domain.model.*
import kotlinx.serialization.json.*

internal class XtreamMapper(private val urls: XtreamUrlBuilder) {

    fun account(root: JsonElement, now: Long = System.currentTimeMillis()): XtreamAccount {
        val ui = root.field("user_info") as? JsonObject ?: throw IptvError.InvalidCredentials()
        val auth = ui["auth"].str()
        if (auth == "0" || auth.equals("false", ignoreCase = true)) throw IptvError.InvalidCredentials()
        val status = ui["status"].str() ?: "Active"
        val exp = ui["exp_date"].long()?.takeIf { it > 0 }?.times(1000)
        when {
            status.equals("Expired", true) -> throw IptvError.AccountExpired(exp)
            status.equals("Banned", true) || status.equals("Disabled", true) -> throw IptvError.AccountDisabled(status.lowercase())
            exp != null && exp < now -> throw IptvError.AccountExpired(exp)
        }
        return XtreamAccount(
            username = ui["username"].str().orEmpty(), status = status, expiresAt = exp,
            isTrial = ui["is_trial"].str().let { it == "1" || it.equals("true", true) },
            maxConnections = ui["max_connections"].int(), activeConnections = ui["active_cons"].int(),
            allowedFormats = ui["allowed_output_formats"].arr().mapNotNull { it.str()?.lowercase() },
            serverTimezone = root.field("server_info").field("timezone").str()
        )
    }

    fun categories(root: JsonElement): List<CategoryImport> = root.arr().mapNotNull { e ->
        val id = e.field("category_id").str() ?: return@mapNotNull null
        CategoryImport(id, e.field("category_name").str() ?: id)
    }

    fun liveChannels(root: JsonElement, format: String): List<ChannelImport> = root.arr().mapNotNull { e ->
        val id = e.field("stream_id").str() ?: return@mapNotNull null
        val archive = if (e.field("tv_archive").int() == 1) (e.field("tv_archive_duration").int()?.takeIf { it > 0 } ?: 1) else 0
        ChannelImport(
            remoteId = id, name = e.field("name").str() ?: "Channel $id", logoUrl = e.field("stream_icon").str(),
            tvgId = e.field("epg_channel_id").str(), tvgName = null, streamUrl = urls.live(id, format),
            number = e.field("num").int() ?: 0, archiveDays = archive, categoryRemoteId = e.field("category_id").str()
        )
    }

    fun movies(root: JsonElement): List<MovieImport> = root.arr().mapNotNull { e ->
        val id = e.field("stream_id").str() ?: return@mapNotNull null
        MovieImport(
            remoteId = id, name = e.field("name").str() ?: "Movie $id", posterUrl = e.field("stream_icon").str(),
            plot = null, year = null, rating = e.field("rating").float()?.takeIf { it > 0f }, cast = null,
            streamUrl = urls.movie(id, e.field("container_extension").str() ?: "mp4"),
            categoryRemoteId = e.field("category_id").str(), addedAt = (e.field("added").long() ?: 0L) * 1000
        )
    }

    fun series(root: JsonElement): List<SeriesImport> = root.arr().mapNotNull { e ->
        val id = e.field("series_id").str() ?: return@mapNotNull null
        SeriesImport(
            remoteId = id, name = e.field("name").str() ?: "Series $id", posterUrl = e.field("cover").str(),
            plot = e.field("plot").str(), year = year(e.field("releaseDate").str() ?: e.field("release_date").str()),
            rating = e.field("rating").float()?.takeIf { it > 0f }, cast = e.field("cast").str(),
            categoryRemoteId = e.field("category_id").str(), addedAt = (e.field("last_modified").long() ?: 0L) * 1000
        )
    }

    fun seriesDetail(root: JsonElement): XtreamSeriesDetail {
        val info = root.field("info")
        val groups: List<Pair<Int?, JsonArray>> = when (val eps = root.field("episodes")) {
            is JsonObject -> eps.entries.map { (k, v) -> k.toIntOrNull() to v.arr() }
            is JsonArray -> eps.map { null to it.arr() }
            else -> emptyList()
        }
        val episodes = groups.flatMap { (seasonKey, list) ->
            list.mapIndexedNotNull { i, e ->
                val id = e.field("id").str() ?: return@mapIndexedNotNull null
                val n = e.field("episode_num").int() ?: (i + 1)
                val ei = e.field("info")
                XtreamEpisode(
                    season = e.field("season").int() ?: seasonKey ?: 1, episodeNum = n,
                    title = e.field("title").str() ?: "Episode $n", plot = ei.field("plot").str(),
                    imageUrl = ei.field("movie_image").str(),
                    streamUrl = urls.series(id, e.field("container_extension").str() ?: "mkv"),
                    durationSecs = ei.field("duration_secs").int() ?: 0
                )
            }
        }
        return XtreamSeriesDetail(
            plot = info.field("plot").str(), cast = info.field("cast").str(),
            year = year(info.field("releaseDate").str() ?: info.field("release_date").str()),
            rating = info.field("rating").float()?.takeIf { it > 0f }, episodes = episodes
        )
    }

    fun vodDetail(root: JsonElement): XtreamVodDetail {
        val info = root.field("info")
        return XtreamVodDetail(
            plot = info.field("plot").str() ?: info.field("description").str(),
            cast = info.field("cast").str() ?: info.field("actors").str(),
            year = year(info.field("releasedate").str() ?: info.field("release_date").str()),
            rating = info.field("rating").float()?.takeIf { it > 0f },
            durationSecs = info.field("duration_secs").int(),
            backdropUrl = info.field("backdrop_path").arr().firstOrNull().str() ?: info.field("backdrop_path").str(),
            containerExtension = root.field("movie_data").field("container_extension").str()
        )
    }

    /** [epgKey] is the EpgKey of the channel the listing belongs to. */
    fun epg(root: JsonElement, epgKey: String): List<EpgProgram> = root.field("epg_listings").arr().mapNotNull { e ->
        val start = e.field("start_timestamp").long()?.times(1000) ?: parseLooseDateTime(e.field("start").str())
        val end = e.field("stop_timestamp").long()?.times(1000) ?: parseLooseDateTime(e.field("end").str())
        val title = Base64Lenient.decodeOrSelf(e.field("title").str())
        if (start == null || end == null || end <= start || title.isNullOrBlank()) null
        else EpgProgram(
            channelTvgId = epgKey, title = title.trim(),
            description = Base64Lenient.decodeOrSelf(e.field("description").str())?.trim()?.takeIf { it.isNotEmpty() },
            startTime = start, endTime = end
        )
    }

    private fun year(date: String?): String? = date?.take(4)?.takeIf { it.length == 4 && it.all(Char::isDigit) }
}
