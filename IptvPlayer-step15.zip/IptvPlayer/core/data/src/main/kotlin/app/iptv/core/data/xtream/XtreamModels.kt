package app.iptv.core.data.xtream

import app.iptv.core.domain.model.Episode

data class XtreamAccount(
    val username: String, val status: String, val expiresAt: Long?, val isTrial: Boolean,
    val maxConnections: Int?, val activeConnections: Int?, val allowedFormats: List<String>,
    val serverTimezone: String?
)

data class XtreamEpisode(
    val season: Int, val episodeNum: Int, val title: String, val plot: String?,
    val imageUrl: String?, val streamUrl: String, val durationSecs: Int
) {
    fun toDomain(seriesId: Long) = Episode(
        seriesId = seriesId, season = season, episodeNum = episodeNum, title = title,
        plot = plot, imageUrl = imageUrl, streamUrl = streamUrl, durationSecs = durationSecs
    )
}

data class XtreamSeriesDetail(
    val plot: String?, val cast: String?, val year: String?, val rating: Float?, val episodes: List<XtreamEpisode>
)

data class XtreamVodDetail(
    val plot: String?, val cast: String?, val year: String?, val rating: Float?,
    val durationSecs: Int?, val backdropUrl: String?, val containerExtension: String?
)
