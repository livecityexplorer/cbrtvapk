package app.iptv.core.data.xtream

import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class XtreamCredentials(val serverUrl: String, val username: String, val password: String)

class XtreamUrlBuilder(serverUrl: String, private val username: String, private val password: String) {
    val baseUrl: String = normalizeBase(serverUrl)

    fun playerApi(action: String? = null, params: Map<String, String> = emptyMap()): String {
        val sb = StringBuilder("$baseUrl/player_api.php?username=${q(username)}&password=${q(password)}")
        if (action != null) sb.append("&action=").append(q(action))
        params.forEach { (k, v) -> sb.append('&').append(q(k)).append('=').append(q(v)) }
        return sb.toString()
    }

    fun live(streamId: String, ext: String = "m3u8") = "$baseUrl/live/${seg(username)}/${seg(password)}/$streamId.$ext"
    fun movie(streamId: String, ext: String = "mp4") = "$baseUrl/movie/${seg(username)}/${seg(password)}/$streamId.$ext"
    fun series(episodeId: String, ext: String = "mkv") = "$baseUrl/series/${seg(username)}/${seg(password)}/$episodeId.$ext"
    fun xmltv() = "$baseUrl/xmltv.php?username=${q(username)}&password=${q(password)}"

    /** Catch-up URL. [serverTz] is the panel's timezone (server_info.timezone): `start` is in server local time. */
    fun timeshift(streamId: String, startEpochMs: Long, durationMinutes: Int, serverTz: TimeZone = TimeZone.getTimeZone("UTC")): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd:HH-mm", Locale.US).apply { timeZone = serverTz }
        return "$baseUrl/streaming/timeshift.php?username=${q(username)}&password=${q(password)}" +
            "&stream=$streamId&start=${fmt.format(Date(startEpochMs))}&duration=$durationMinutes"
    }

    companion object {
        private val SUFFIXES = listOf("/player_api.php", "/get.php", "/panel_api.php", "/xmltv.php", "/c")

        private fun q(s: String) = URLEncoder.encode(s, "UTF-8")
        private fun seg(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

        /** "host:8080", "http://host/", "http://host/player_api.php?x=1" -> "http://host[:port]". */
        fun normalizeBase(input: String): String {
            var s = input.trim()
            if (!s.contains("://")) s = "http://$s"
            s = s.substringBefore('#').substringBefore('?').trimEnd('/')
            for (suffix in SUFFIXES) {
                if (s.endsWith(suffix, ignoreCase = true)) {
                    val cand = s.dropLast(suffix.length).trimEnd('/')
                    if (cand.contains("://") && cand.substringAfter("://").isNotEmpty()) s = cand
                }
            }
            return s
        }

        /** Detects Xtream credentials in a provider's `.../get.php?username=U&password=P&type=m3u...` link. */
        fun parseGetPhpUrl(url: String): XtreamCredentials? {
            val u = url.trim()
            if (!u.contains("get.php", ignoreCase = true) || !u.contains('?')) return null
            val query = u.substringAfter('?').substringBefore('#')
            val map = query.split('&').mapNotNull {
                val i = it.indexOf('=')
                if (i <= 0) null else java.net.URLDecoder.decode(it.substring(0, i), "UTF-8") to
                    java.net.URLDecoder.decode(it.substring(i + 1), "UTF-8")
            }.toMap()
            val user = map["username"]?.takeIf { it.isNotEmpty() } ?: return null
            val pass = map["password"]?.takeIf { it.isNotEmpty() } ?: return null
            return XtreamCredentials(normalizeBase(u), user, pass)
        }
    }
}
