package app.iptv.core.data

import app.iptv.core.data.network.RawHttpApi
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.ResponseBody
import okhttp3.ResponseBody.Companion.toResponseBody

class FakeApi(private val handler: (url: String, headers: Map<String, String>) -> String) : RawHttpApi {
    val calls = mutableListOf<Pair<String, Map<String, String>>>()
    override suspend fun get(url: String, headers: Map<String, String>): ResponseBody {
        calls += url to headers
        return handler(url, headers).toResponseBody("application/json".toMediaType())
    }
}
