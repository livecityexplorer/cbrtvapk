package app.iptv.core.data.backup

import app.iptv.core.domain.model.*
import app.iptv.core.domain.repository.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test

class BackupManagerTest {
    private class FakePrefs : PreferencesRepository {
        val state = MutableStateFlow(AppSettings())
        override val activePlaylistId: Flow<Long?> = flowOf(null)
        override suspend fun setActivePlaylistId(id: Long) {}
        override val liveViewMode: Flow<LiveViewMode> = flowOf(LiveViewMode.LIST)
        override suspend fun setLiveViewMode(mode: LiveViewMode) {}
        override val lastEpgRefresh: Flow<Long> = flowOf(0)
        override suspend fun setLastEpgRefresh(timestamp: Long) {}
        override val recordingsFolder: Flow<String?> = flowOf(null)
        override suspend fun setRecordingsFolder(uri: String?) {}
        override val settings: Flow<AppSettings> = state
        override suspend fun updateSettings(transform: (AppSettings) -> AppSettings) { state.value = transform(state.value) }
    }
    private class FakePlaylists : PlaylistRepository {
        val list = MutableStateFlow<List<Playlist>>(emptyList())
        override fun observeAll(): Flow<List<Playlist>> = list
        override suspend fun get(id: Long) = list.value.firstOrNull { it.id == id }
        override suspend fun save(playlist: Playlist): Long { val id = list.value.size + 1L; list.value += playlist.copy(id = id); return id }
        override suspend fun delete(id: Long) { list.value = list.value.filterNot { it.id == id } }
        override suspend fun markRefreshed(id: Long, timestamp: Long) {}
    }

    @Test fun roundTripRestoresPlaylistsAndSettingsButNeverThePin() = runTest {
        val p1 = FakePrefs().apply { state.value = AppSettings(theme = ThemeMode.AMOLED, subtitleSizeSp = 30, pinHash = "salt:hash") }
        val l1 = FakePlaylists().apply { save(Playlist(name = "Home", type = PlaylistType.XTREAM, url = "http://x.tv:8080", username = "u", password = "p")) }
        val json = BackupManager(p1, l1).export()
        assertFalse(json.contains("salt:hash"))

        val p2 = FakePrefs(); val l2 = FakePlaylists()
        val result = BackupManager(p2, l2).import(json)
        assertEquals(1, result.playlistsAdded)
        assertEquals("Home", l2.list.value.single().name)
        assertEquals(ThemeMode.AMOLED, p2.state.value.theme); assertEquals(30, p2.state.value.subtitleSizeSp)
        assertNull(p2.state.value.pinHash)
    }

    @Test fun importSkipsDuplicates() = runTest {
        val l = FakePlaylists().apply { save(Playlist(name = "A", type = PlaylistType.M3U, url = "http://a.tv/list.m3u")) }
        val mgr = BackupManager(FakePrefs(), l)
        val r = mgr.import(mgr.export())
        assertEquals(0, r.playlistsAdded); assertEquals(1, r.playlistsSkipped); assertEquals(1, l.list.value.size)
    }

    @Test fun rejectsGarbageAndForeignFiles() = runTest {
        val mgr = BackupManager(FakePrefs(), FakePlaylists())
        assertThrows(IllegalArgumentException::class.java) { kotlinx.coroutines.runBlocking { mgr.import("not json") } }
        assertThrows(IllegalArgumentException::class.java) { kotlinx.coroutines.runBlocking { mgr.import("""{"format":"other"}""") } }
    }
}
