package app.iptv.core.data.epg

import app.iptv.core.data.parser.EpgChannelMatcher
import app.iptv.core.data.parser.EpgChannelRef
import app.iptv.core.data.parser.XmltvParser
import app.iptv.core.domain.model.EpgProgram
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.kxml2.io.KXmlParser

class XmltvImporterTest {
    private val now = 1_704_110_400_000L // 2024-01-01T12:00:00Z
    private val importer = XmltvImporter(XmltvParser { KXmlParser() })

    private val matcher = EpgChannelMatcher(
        listOf(
            EpgChannelRef("bbc1.uk", "BBC One", "BBC One HD"),   // matched by id
            EpgChannelRef(null, null, "Sky Sports 1"),           // matched by display-name
            EpgChannelRef("dup.id", null, "Dup A"),
            EpgChannelRef("dup.id", null, "Dup B")               // same id twice -> one key
        )
    )

    private val xml = """<tv>
      <channel id="BBC1.UK"><display-name>BBC One</display-name></channel>
      <channel id="sky.s1"><display-name>Sky Sports 1</display-name></channel>
      <channel id="unknown.ch"><display-name>Not In Playlist</display-name></channel>
      <programme start="20240101110000 +0000" stop="20240101130000 +0000" channel="BBC1.UK"><title>Now Show</title><desc>Live</desc></programme>
      <programme start="20240101130000 +0000" stop="20240101140000 +0000" channel="BBC1.UK"><title>Next Show</title></programme>
      <programme start="20240101120000 +0000" stop="20240101130000 +0000" channel="sky.s1"><title>Match</title></programme>
      <programme start="20240101120000 +0000" stop="20240101130000 +0000" channel="unknown.ch"><title>Dropped</title></programme>
      <programme start="20231228100000 +0000" stop="20231228110000 +0000" channel="BBC1.UK"><title>Too Old</title></programme>
      <programme start="20240601100000 +0000" stop="20240601110000 +0000" channel="BBC1.UK"><title>Too Far Ahead</title></programme>
      <programme start="20240101150000 +0000" stop="20240101160000 +0000" channel="dup.id"><title>Dup Show</title></programme>
    </tv>"""

    private fun run(text: String): Pair<Int, List<EpgProgram>> {
        val sink = ArrayList<EpgProgram>()
        val n = runBlocking { importer.import(text.byteInputStream(), matcher, now) { sink += it } }
        return n to sink
    }

    @Test fun mapsByTvgIdThenByNameAndFiltersEverythingElse() {
        val (n, out) = run(xml)
        assertEquals(4, n)
        assertEquals(setOf("Now Show", "Next Show", "Match", "Dup Show"), out.map { it.title }.toSet())
        assertEquals("bbc1.uk", out.first { it.title == "Now Show" }.channelTvgId)            // case-insensitive id match
        assertEquals("name:skysports1", out.first { it.title == "Match" }.channelTvgId)       // name fallback key
        assertEquals("Live", out.first { it.title == "Now Show" }.description)
    }

    @Test fun duplicateChannelIdsDoNotMultiplyProgrammes() {
        assertEquals(1, run(xml).second.count { it.title == "Dup Show" })
    }

    @Test fun reportsProgressAndBatches() {
        val sb = StringBuilder("<tv><channel id=\"bbc1.uk\"><display-name>x</display-name></channel>")
        repeat(4500) { i ->
            val m = i % 60; val h = 12 + (i / 60) % 10
            sb.append("<programme start=\"2024010${1 + i / 600}${"%02d".format(h)}${"%02d".format(m)}00 +0000\" stop=\"2024010${1 + i / 600}${"%02d".format(h)}${"%02d".format(m)}59 +0000\" channel=\"bbc1.uk\"><title>T$i</title></programme>")
        }
        sb.append("</tv>")
        val batches = ArrayList<Int>(); val progress = ArrayList<Int>()
        runBlocking { importer.import(sb.toString().byteInputStream(), matcher, now, { progress += it }) { batches += it.size } }
        assertTrue(batches.size >= 2)
        assertEquals(progress.sorted(), progress)
        assertEquals(batches.sum(), progress.last())
    }
}
