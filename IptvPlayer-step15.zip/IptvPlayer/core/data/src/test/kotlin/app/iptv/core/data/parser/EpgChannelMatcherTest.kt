package app.iptv.core.data.parser

import org.junit.Assert.assertEquals
import org.junit.Test

class EpgChannelMatcherTest {
    private val channels = listOf(
        EpgChannelRef("BBC1.uk", "BBC One", "BBC One HD"),
        EpgChannelRef(null, null, "Sky Sports 1"),
        EpgChannelRef("", "CNN", "CNN International"),
        EpgChannelRef("dup.id", null, "Dup A"),
        EpgChannelRef("dup.id", null, "Dup A")
    )
    private val matcher = EpgChannelMatcher(channels)

    @Test fun matchesByTvgIdCaseInsensitive() =
        assertEquals(setOf("bbc1.uk"), matcher.targets("bbc1.UK", emptyList()))

    @Test fun fallsBackToDisplayNameForChannelsWithoutTvgId() =
        assertEquals(setOf("name:skysports1"), matcher.targets("unknown.id", listOf("Sky Sports 1")))

    @Test fun fallsBackUsingTvgNameOfChannel() =
        assertEquals(setOf("name:cnn"), matcher.targets("zzz", listOf("CNN")))

    @Test fun noMatchGivesEmptySet() =
        assertEquals(emptySet<String>(), matcher.targets("nope", listOf("Nothing Here")))

    @Test fun duplicateIdsCollapseToOneKey() =
        assertEquals(setOf("dup.id"), matcher.targets("dup.id", emptyList()))
}
