package app.iptv.core.data.parser

import app.iptv.core.domain.util.StreamHeaders
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class M3uParserTest {
    private fun parse(text: String, progress: (Int) -> Unit = {}) =
        runBlocking { M3uParser().parse(text.byteInputStream(), progress) }

    private val sample = """
        #EXTM3U url-tvg="http://epg.example/a.xml.gz, http://epg.example/b.xml"
        #EXTINF:-1 tvg-id="bbc1.uk" tvg-name="BBC One" tvg-logo="http://img/bbc1.png" group-title="UK" tvg-chno="7" catchup-days="3",BBC One HD
        http://host/live/1.m3u8
        #EXTINF:-1 group-title="News, World" tvg-id="",Channel, With Comma
        #EXTGRP:Ignored
        http://host/live/2.ts
        #EXTGRP:Sports
        #EXTINF:-1,Sport 1
        #EXTVLCOPT:http-user-agent=MyAgent/1.0
        #EXTVLCOPT:http-referrer=http://ref.example/
        http://host/live/3.m3u8
    """.trimIndent()

    @Test fun parsesAttributesGroupsAndEpgUrls() {
        val r = parse(sample)
        assertEquals(listOf("http://epg.example/a.xml.gz", "http://epg.example/b.xml"), r.epgUrls)
        assertEquals(3, r.channels.size)
        assertEquals(listOf("UK", "News, World", "Sports"), r.categories.map { it.name })

        val c1 = r.channels[0]
        assertEquals("BBC One HD", c1.name)
        assertEquals("bbc1.uk", c1.tvgId)
        assertEquals("BBC One", c1.tvgName)
        assertEquals("http://img/bbc1.png", c1.logoUrl)
        assertEquals(7, c1.number)
        assertEquals(3, c1.archiveDays)
        assertEquals("UK", c1.categoryRemoteId)
        assertEquals("http://host/live/1.m3u8", c1.streamUrl)
    }

    @Test fun commaInNameAndGroupTitleWinsOverExtgrp() {
        val c2 = parse(sample).channels[1]
        assertEquals("Channel, With Comma", c2.name)
        assertEquals("News, World", c2.categoryRemoteId)
        assertNull(c2.tvgId)
    }

    @Test fun extgrpAppliesAndVlcOptHeadersAreEncoded() {
        val c3 = parse(sample).channels[2]
        assertEquals("Sports", c3.categoryRemoteId)
        assertEquals(3, c3.number) // falls back to playlist position
        val (url, headers) = StreamHeaders.decode(c3.streamUrl)
        assertEquals("http://host/live/3.m3u8", url)
        assertEquals("MyAgent/1.0", headers["User-Agent"])
        assertEquals("http://ref.example/", headers["Referer"])
    }

    @Test fun headersDoNotLeakToNextChannel() {
        val r = parse(sample + "\n#EXTINF:-1,Next\nhttp://host/live/4.ts")
        assertEquals("http://host/live/4.ts", r.channels[3].streamUrl)
    }

    @Test fun duplicatesGetUniqueStableRemoteIds() {
        val text = "#EXTM3U\n#EXTINF:-1 group-title=\"G\",Dup\nhttp://a/1\n#EXTINF:-1 group-title=\"G\",Dup\nhttp://a/2\n"
        val ids = parse(text).channels.map { it.remoteId }
        assertEquals(2, ids.toSet().size)
        assertEquals(ids, parse(text).channels.map { it.remoteId })
    }

    @Test fun handlesBomCrlfAndPlainUrlLists() {
        val r = parse("\uFEFF#EXTM3U\r\n#EXTINF:-1,Alpha\r\nhttp://a/alpha.ts\r\nrtmp://b/live/beta\r\n")
        assertEquals(2, r.channels.size)
        assertEquals("Alpha", r.channels[0].name)
        assertEquals("beta", r.channels[1].name)
    }

    @Test fun singleQuotedAndUnquotedAttributes() {
        val r = parse("#EXTINF:-1 tvg-id='x1' group-title=News,Name\nhttp://a/1")
        assertEquals("x1", r.channels[0].tvgId)
        assertEquals("News", r.channels[0].categoryRemoteId)
    }

    @Test fun ignoresGarbageAndEmptyInput() {
        assertEquals(0, parse("").channels.size)
        assertEquals(0, parse("#EXTM3U\nnot a url\n# comment\n").channels.size)
    }

    @Test fun streamsLargePlaylistWithProgress() {
        val sb = StringBuilder("#EXTM3U\n")
        repeat(12_000) { i -> sb.append("#EXTINF:-1 tvg-id=\"id$i\" group-title=\"G${i % 40}\",Channel $i\nhttp://h/$i.ts\n") }
        val calls = ArrayList<Int>()
        val r = parse(sb.toString()) { calls += it }
        assertEquals(12_000, r.channels.size)
        assertEquals(40, r.categories.size)
        assertEquals(12_000, calls.last())
        assertTrue(calls.size >= 40)
        assertEquals(calls.sorted(), calls)
    }
}
