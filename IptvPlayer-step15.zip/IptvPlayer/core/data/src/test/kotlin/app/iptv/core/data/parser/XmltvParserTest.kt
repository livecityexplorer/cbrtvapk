package app.iptv.core.data.parser

import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.kxml2.io.KXmlParser
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.GZIPOutputStream

class XmltvParserTest {
    // KXmlParser directly, so the test does not depend on android.jar stubs.
    private val parser = XmltvParser { KXmlParser() }

    private val xml = """<?xml version="1.0" encoding="UTF-8"?>
<tv generator-info-name="test">
  <channel id="bbc1.uk"><display-name>BBC One</display-name><display-name lang="en">BBC 1</display-name><icon src="http://img/bbc.png"/></channel>
  <programme start="20240101120000 +0000" stop="20240101130000 +0000" channel="bbc1.uk">
    <title lang="en">News</title><desc lang="en">Headlines &amp; weather</desc><icon src="http://img/news.jpg"/>
  </programme>
  <programme start="20240101130000 +0100" stop="20240101140000 +0100" channel="bbc1.uk"><title>Film</title></programme>
  <programme start="bad" stop="20240101140000 +0000" channel="x"><title>Broken</title></programme>
  <programme start="20240101140000 +0000" stop="20240101130000 +0000" channel="x"><title>Backwards</title></programme>
</tv>"""

    private fun run(bytes: ByteArray, batch: Int = 1000): Triple<List<XmltvChannel>, List<List<XmltvProgram>>, Int> {
        val channels = ArrayList<XmltvChannel>()
        val batches = ArrayList<List<XmltvProgram>>()
        val total = runBlocking {
            parser.parse(XmltvParser.openStream(ByteArrayInputStream(bytes)), batch, { channels += it }) { batches += it }
        }
        return Triple(channels, batches, total)
    }

    @Test fun parsesChannelsAndProgrammes() {
        val (channels, batches, total) = run(xml.toByteArray())
        assertEquals(2, total)
        assertEquals(1, channels.size)
        assertEquals("bbc1.uk", channels[0].id)
        assertEquals(listOf("BBC One", "BBC 1"), channels[0].displayNames)
        assertEquals("http://img/bbc.png", channels[0].iconUrl)

        val p = batches.flatten()
        assertEquals("News", p[0].title)
        assertEquals("Headlines & weather", p[0].description)
        assertEquals("http://img/news.jpg", p[0].posterUrl)
        assertEquals(1704110400000L, p[0].startTime) // 2024-01-01T12:00:00Z
        assertEquals(1704114000000L, p[0].endTime)
        assertNull(p[1].description)
    }

    @Test fun appliesTimezoneOffsets() {
        val p = run(xml.toByteArray()).second.flatten()
        assertEquals(p[0].startTime, p[1].startTime) // 13:00 +0100 == 12:00 UTC
        assertEquals(p[0].endTime, p[1].endTime)
    }

    @Test fun skipsInvalidProgrammes() {
        val titles = run(xml.toByteArray()).second.flatten().map { it.title }
        assertFalse("Broken" in titles); assertFalse("Backwards" in titles)
    }

    @Test fun readsGzip() {
        val bos = ByteArrayOutputStream()
        GZIPOutputStream(bos).use { it.write(xml.toByteArray()) }
        assertEquals(2, run(bos.toByteArray()).third)
    }

    @Test fun deliversInBatches() {
        val sb = StringBuilder("<tv>")
        repeat(2500) { i ->
            val s = 1704110400L + i * 60
            sb.append("<programme start=\"${fmt(s)} +0000\" stop=\"${fmt(s + 60)} +0000\" channel=\"c\"><title>T$i</title></programme>")
        }
        sb.append("</tv>")
        val (_, batches, total) = run(sb.toString().toByteArray(), batch = 1000)
        assertEquals(2500, total)
        assertEquals(listOf(1000, 1000, 500), batches.map { it.size })
    }

    @Test fun parseTimeVariants() {
        val t = XmltvParser.Companion
        assertEquals(1704110400000L, t.parseXmltvTime("20240101120000 +0000"))
        assertEquals(1704110400000L, t.parseXmltvTime("20240101120000"))
        assertEquals(1704110400000L, t.parseXmltvTime("202401011200"))
        assertEquals(1704106800000L, t.parseXmltvTime("20240101120000 +0100"))
        assertEquals(1704128400000L, t.parseXmltvTime("20240101120000 -0600"))
        assertEquals(1704110400000L, t.parseXmltvTime("20240101130000 +01:00"))
        assertEquals(1704067200000L, t.parseXmltvTime("20240101"))
        assertEquals(951782400000L, t.parseXmltvTime("20000229")) // leap day
        assertNull(t.parseXmltvTime("")); assertNull(t.parseXmltvTime("bad")); assertNull(t.parseXmltvTime("20241301000000"))
    }

    private fun fmt(epochSec: Long): String {
        val c = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
        c.timeInMillis = epochSec * 1000
        return String.format("%04d%02d%02d%02d%02d%02d", c.get(1), c.get(2) + 1, c.get(5), c.get(11), c.get(12), c.get(13))
    }
}
