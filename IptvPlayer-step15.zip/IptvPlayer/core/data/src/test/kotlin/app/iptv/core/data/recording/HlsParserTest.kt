package app.iptv.core.data.recording

import org.junit.Assert.*
import org.junit.Test

class HlsParserTest {
    @Test fun parsesMediaPlaylist() {
        val m = HlsParser.parse(
            """
            #EXTM3U
            #EXT-X-VERSION:3
            #EXT-X-TARGETDURATION:6
            #EXT-X-MEDIA-SEQUENCE:100
            #EXTINF:5.96,
            seg100.ts
            #EXTINF:6.0,title
            http://cdn/seg101.ts
            """.trimIndent()
        ) as HlsPlaylist.Media
        assertEquals(6, m.targetDurationSec); assertEquals(100L, m.mediaSequence)
        assertEquals(listOf("seg100.ts", "http://cdn/seg101.ts"), m.segments.map { it.uri })
        assertEquals(listOf(100L, 101L), m.segments.map { it.sequence })
        assertEquals(5.96, m.segments[0].durationSec, 0.001)
        assertFalse(m.ended); assertFalse(m.encrypted); assertFalse(m.fragmentedMp4)
    }

    @Test fun detectsEndlistEncryptionAndFmp4() {
        assertTrue((HlsParser.parse("#EXTM3U\n#EXTINF:1,\na.ts\n#EXT-X-ENDLIST") as HlsPlaylist.Media).ended)
        assertTrue((HlsParser.parse("#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI=\"k\"\n#EXTINF:1,\na.ts") as HlsPlaylist.Media).encrypted)
        assertFalse((HlsParser.parse("#EXTM3U\n#EXT-X-KEY:METHOD=NONE\n#EXTINF:1,\na.ts") as HlsPlaylist.Media).encrypted)
        assertTrue((HlsParser.parse("#EXTM3U\n#EXT-X-MAP:URI=\"init.mp4\"\n#EXTINF:1,\na.m4s") as HlsPlaylist.Media).fragmentedMp4)
    }

    @Test fun parsesMasterPlaylist() {
        val m = HlsParser.parse(
            "#EXTM3U\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=800000,RESOLUTION=640x360\nlow.m3u8\n" +
                "#EXT-X-STREAM-INF:BANDWIDTH=2500000\nhigh.m3u8\n"
        ) as HlsPlaylist.Master
        assertEquals(listOf("low.m3u8" to 800000L, "high.m3u8" to 2500000L), m.variants.map { it.uri to it.bandwidth })
    }

    @Test fun rejectsNonPlaylists() {
        assertTrue(runCatching { HlsParser.parse("<html>nope</html>") }.exceptionOrNull() is IllegalArgumentException)
    }
}
