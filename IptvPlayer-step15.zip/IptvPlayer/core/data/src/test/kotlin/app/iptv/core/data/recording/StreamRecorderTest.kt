package app.iptv.core.data.recording

import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import okhttp3.mockwebserver.Dispatcher
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.RecordedRequest
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.io.ByteArrayOutputStream

class StreamRecorderTest {
    private lateinit var server: MockWebServer
    private val recorder = StreamRecorder(OkHttpClient())

    @Before fun start() { server = MockWebServer() }
    @After fun stop() { server.shutdown() }

    private fun serve(handler: (String) -> MockResponse) {
        server.dispatcher = object : Dispatcher() {
            override fun dispatch(request: RecordedRequest): MockResponse = handler(request.path.orEmpty())
        }
        server.start()
    }

    @Test fun progressiveStreamIsCopiedAndSurvivesTheServerClosing() {
        var served = false
        serve { path ->
            if (path.startsWith("/live/1.ts") && !served) { served = true; MockResponse().setBody("A".repeat(5000)) }
            else MockResponse().setResponseCode(500) // later reconnects fail until the end time
        }
        val out = ByteArrayOutputStream()
        val total = runBlocking { recorder.record(server.url("/live/1.ts").toString(), emptyMap(), out, System.currentTimeMillis() + 1_200) }
        assertEquals(5000L, total)
        assertEquals("A".repeat(5000), out.toString())
    }

    @Test fun progressiveSendsCustomHeaders() {
        serve { MockResponse().setBody("x") }
        runBlocking { recorder.record(server.url("/s.ts").toString(), mapOf("Referer" to "http://r/", "User-Agent" to "UA/1"), ByteArrayOutputStream(), System.currentTimeMillis() + 300) }
        val req = server.takeRequest()
        assertEquals("http://r/", req.getHeader("Referer")); assertEquals("UA/1", req.getHeader("User-Agent"))
    }

    @Test fun hlsSegmentsAreConcatenatedInOrder() {
        serve { path ->
            when {
                path.startsWith("/hls/index.m3u8") -> MockResponse().setBody(
                    "#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:7\n#EXTINF:2,\ns7.ts\n#EXTINF:2,\ns8.ts\n#EXTINF:2,\ns9.ts\n#EXT-X-ENDLIST\n"
                )
                path.endsWith("s7.ts") -> MockResponse().setBody("AAAA")
                path.endsWith("s8.ts") -> MockResponse().setBody("BBBB")
                path.endsWith("s9.ts") -> MockResponse().setBody("CCCC")
                else -> MockResponse().setResponseCode(404)
            }
        }
        val out = ByteArrayOutputStream()
        val total = runBlocking { recorder.record(server.url("/hls/index.m3u8").toString(), emptyMap(), out, System.currentTimeMillis() + 10_000) }
        assertEquals(12L, total); assertEquals("AAAABBBBCCCC", out.toString())
    }

    @Test fun hlsMasterPicksTheHighestBandwidthVariant() {
        serve { path ->
            when {
                path.startsWith("/m.m3u8") -> MockResponse().setBody("#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1000\nlow/p.m3u8\n#EXT-X-STREAM-INF:BANDWIDTH=9000\nhigh/p.m3u8\n")
                path.startsWith("/high/p.m3u8") -> MockResponse().setBody("#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXTINF:2,\nx.ts\n#EXT-X-ENDLIST\n")
                path.endsWith("/high/x.ts") -> MockResponse().setBody("HIGH")
                path.endsWith("/low/x.ts") -> MockResponse().setBody("LOW")
                else -> MockResponse().setResponseCode(404)
            }
        }
        val out = ByteArrayOutputStream()
        runBlocking { recorder.record(server.url("/m.m3u8").toString(), emptyMap(), out, System.currentTimeMillis() + 10_000) }
        assertEquals("HIGH", out.toString())
    }

    @Test fun hlsOnlyKeepsTheLastFewSegmentsOnFirstRead() {
        serve { path ->
            when {
                path.startsWith("/l.m3u8") -> MockResponse().setBody(
                    "#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:0\n" + (0..4).joinToString("") { "#EXTINF:2,\ns$it.ts\n" } + "#EXT-X-ENDLIST\n"
                )
                path.contains("/s") -> MockResponse().setBody(path.substringAfterLast("/s").substringBefore(".ts"))
                else -> MockResponse().setResponseCode(404)
            }
        }
        val out = ByteArrayOutputStream()
        runBlocking { recorder.record(server.url("/l.m3u8").toString(), emptyMap(), out, System.currentTimeMillis() + 10_000) }
        assertEquals("234", out.toString()) // joined live edge: last three segments
    }

    @Test fun encryptedHlsIsRejected() {
        serve { MockResponse().setBody("#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXT-X-KEY:METHOD=AES-128,URI=\"k\"\n#EXTINF:2,\na.ts\n") }
        val err = runCatching { runBlocking { recorder.record(server.url("/e.m3u8").toString(), emptyMap(), ByteArrayOutputStream(), System.currentTimeMillis() + 5_000) } }.exceptionOrNull()
        assertTrue(err is StreamRecorder.UnsupportedStreamException)
    }
}
