package app.iptv.core.data.stalker

import app.iptv.core.data.FakeApi
import app.iptv.core.data.network.field
import app.iptv.core.domain.error.IptvError
import app.iptv.core.domain.util.StalkerStreamUrl
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.Json
import org.junit.Assert.*
import org.junit.Test

class StalkerTest {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private val mac = "00:1a:79:aa:bb:cc"

    private val genres = """{"js":[{"id":"*","title":"All"},{"id":"3","title":"News"}]}"""
    private val channels = """{"js":{"data":[
        {"id":"11","name":"ARD","number":"1","cmd":"ffrt http://localhost/ch/11","logo":"11.png","tv_genre_id":"3","xmltv_id":"ard.de","tv_archive_duration":"7"},
        {"id":"12","name":"NoCmd"},
        {"id":"13","name":"ViaCmds","cmds":[{"url":"ffmpeg http://x/13"}],"logo":"http://cdn/l.png","tv_genre_id":"0"}]}}"""

    @Test fun macNormalization() {
        assertEquals("00:1A:79:AA:BB:CC", StalkerUrls.normalizeMac("00-1a-79-aa-bb-cc"))
        assertEquals("00:1A:79:AA:BB:CC", StalkerUrls.normalizeMac(" 00:1A:79:AA:BB:CC "))
        assertNull(StalkerUrls.normalizeMac("00:1A:79"))
        assertNull(StalkerUrls.normalizeMac("ZZ:1A:79:AA:BB:CC"))
    }

    @Test fun endpointCandidates() {
        assertEquals(
            listOf("http://h/portal.php", "http://h/stalker_portal/server/load.php", "http://h/server/load.php"),
            StalkerUrls.candidates("http://h/c/")
        )
        assertEquals(
            listOf("http://h/stalker_portal/server/load.php", "http://h/stalker_portal/portal.php"),
            StalkerUrls.candidates("h/stalker_portal/c")
        )
        assertEquals(listOf("http://h/portal.php"), StalkerUrls.candidates("http://h/portal.php"))
        assertEquals(listOf("http://h/stalker_portal/server/load.php"), StalkerUrls.candidates("http://h/stalker_portal/server/load.php"))
        assertTrue(StalkerUrls.candidates("  ").isEmpty())
        assertEquals("http://h/stalker_portal", StalkerUrls.portalRoot("http://h/stalker_portal/server/load.php"))
        assertEquals("http://h", StalkerUrls.portalRoot("http://h/portal.php"))
    }

    @Test fun mapsGenresAndChannels() {
        val m = StalkerMapper("http://h/stalker_portal")
        assertEquals(listOf("News"), m.genres(json.parseToJsonElement(genres).field("js")).map { it.name })

        val list = m.channels(json.parseToJsonElement(channels).field("js").dataArray())
        assertEquals(2, list.size) // channel without cmd is skipped
        val ard = list[0]
        assertEquals("http://h/stalker_portal/misc/logos/320/11.png", ard.logoUrl)
        assertEquals("ard.de", ard.tvgId); assertEquals(7, ard.archiveDays); assertEquals("3", ard.categoryRemoteId); assertEquals(1, ard.number)
        assertEquals("ffrt http://localhost/ch/11", StalkerStreamUrl.decode(ard.streamUrl))
        assertTrue(StalkerStreamUrl.isStalker(ard.streamUrl))
        assertEquals("http://cdn/l.png", list[1].logoUrl)
        assertNull(list[1].categoryRemoteId)
        assertEquals("ffmpeg http://x/13", StalkerStreamUrl.decode(list[1].streamUrl))
    }

    @Test fun cleansResolvedLinks() {
        val m = StalkerMapper("")
        assertEquals("http://x/y?a=1", m.cleanLink("ffmpeg http://x/y?a=1"))
        assertEquals("http://x", m.cleanLink("auto http://x"))
        assertEquals("http://a/b", m.cleanLink("ffrt3 http://a/b"))
        assertEquals("http://plain", m.cleanLink("http://plain"))
    }

    @Test fun invalidMacOrEmptyUrlIsRejectedUpFront() {
        assertTrue(runCatching { StalkerClient(FakeApi { _, _ -> "" }, json, "http://h/c", "nope") }.exceptionOrNull() is IptvError.InvalidInput)
        assertTrue(runCatching { StalkerClient(FakeApi { _, _ -> "" }, json, " ", mac) }.exceptionOrNull() is IptvError.InvalidInput)
    }

    private fun portalApi() = FakeApi { url, _ ->
        when {
            url.startsWith("http://h/portal.php") -> "<html>Not Found</html>"
            "action=handshake" in url && url.startsWith("http://h/stalker_portal/server/load.php") -> """{"js":{"token":"TKN"}}"""
            "action=get_profile" in url -> """{"js":{"id":"1"}}"""
            "action=get_genres" in url -> genres
            "action=get_all_channels" in url -> channels
            "action=create_link" in url -> """{"js":{"cmd":"ffmpeg http://real/stream.m3u8?t=1"}}"""
            else -> "{}"
        }
    }

    @Test fun handshakeFallsThroughCandidatesThenFetchesWithToken() {
        val api = portalApi()
        val client = StalkerClient(api, json, "http://h/c/", mac)
        val live = runBlocking { client.fetchLive() }
        assertEquals(listOf("News"), live.categories.map { it.name })
        assertEquals(2, live.channels.size)

        // first attempt hit portal.php, without auth; the working endpoint was then used with the bearer token
        assertTrue(api.calls.first().first.startsWith("http://h/portal.php") && "action=handshake" in api.calls.first().first)
        assertNull(api.calls.first().second["Authorization"])
        val genresCall = api.calls.first { "action=get_genres" in it.first }
        assertEquals("Bearer TKN", genresCall.second["Authorization"])
        assertTrue(genresCall.second["Cookie"]!!.contains("mac=00:1A:79:AA:BB:CC"))
        assertTrue(genresCall.first.contains("JsHttpRequest=1-xml"))
    }

    @Test fun resolvesStreamLinkAtPlayTime() {
        val link = runBlocking { StalkerClient(portalApi(), json, "http://h/c/", mac).resolveStreamUrl("ffrt http://localhost/ch/11") }
        assertEquals("http://real/stream.m3u8?t=1", link)
    }

    @Test fun unauthorizedMacMapsToInvalidCredentials() {
        val c = StalkerClient(FakeApi { _, _ -> "Authorization failed." }, json, "http://h/c", mac)
        assertTrue(runCatching { runBlocking { c.authenticate() } }.exceptionOrNull() is IptvError.InvalidCredentials)
    }

    @Test fun allCandidatesUnreachableReportsNetworkError() {
        val c = StalkerClient(FakeApi { _, _ -> throw java.io.IOException("down") }, json, "http://h/c", mac)
        assertTrue(runCatching { runBlocking { c.authenticate() } }.exceptionOrNull() is IptvError.Network)
    }

    @Test fun fallsBackToPagedChannelList() {
        val api = FakeApi { url, _ ->
            when {
                "action=handshake" in url -> """{"js":{"token":"T"}}"""
                "action=get_profile" in url -> """{"js":{}}"""
                "action=get_genres" in url -> genres
                "action=get_all_channels" in url -> """{"js":{"data":[]}}"""
                "action=get_ordered_list" in url && "&p=1&" in url -> """{"js":{"total_items":"2","data":[{"id":"1","name":"A","cmd":"c1"}]}}"""
                "action=get_ordered_list" in url && "&p=2&" in url -> """{"js":{"total_items":"2","data":[{"id":"2","name":"B","cmd":"c2"}]}}"""
                else -> """{"js":{"data":[]}}"""
            }
        }
        val live = runBlocking { StalkerClient(api, json, "http://h/portal.php", mac).fetchLive() }
        assertEquals(listOf("A", "B"), live.channels.map { it.name })
    }

    @Test fun shortAndBulkEpg() {
        val api = FakeApi { url, _ ->
            when {
                "action=handshake" in url -> """{"js":{"token":"T"}}"""
                "action=get_short_epg" in url -> """{"js":[{"name":"News","descr":"d","start_timestamp":"1704110400","stop_timestamp":"1704114000"},{"name":"Bad","start_timestamp":"5","stop_timestamp":"1"}]}"""
                "action=get_epg_info" in url -> """{"js":{"data":{"11":[{"name":"Show","time":"2024-01-01 12:00:00","time_to":"2024-01-01 13:00:00"}],"99":[{"name":"Other","start_timestamp":"1704110400","stop_timestamp":"1704114000"}]}}}"""
                else -> """{"js":{}}"""
            }
        }
        val c = StalkerClient(api, json, "http://h/portal.php", mac)
        val short = runBlocking { c.shortEpg("11", "ard.de", 5) }
        assertEquals(1, short.size)
        assertEquals("News", short[0].title); assertEquals("d", short[0].description)
        assertEquals(1704110400000L, short[0].startTime); assertEquals("ard.de", short[0].channelTvgId)

        val bulk = runBlocking { c.fetchEpg(mapOf("11" to "ard.de")) }
        assertEquals(1, bulk.size) // channel 99 not requested
        assertEquals("Show", bulk[0].title); assertEquals(1704110400000L, bulk[0].startTime)
    }
}
