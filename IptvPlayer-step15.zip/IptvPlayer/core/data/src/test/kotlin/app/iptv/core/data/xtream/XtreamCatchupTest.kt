package app.iptv.core.data.xtream

import app.iptv.core.data.FakeApi
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Test

class XtreamCatchupTest {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private val start = 1_704_110_400_000L // 12:00 UTC

    private fun url(tz: String?): String {
        val tzPart = tz?.let { ""","server_info":{"timezone":"$it"}""" }.orEmpty()
        val api = FakeApi { _, _ -> """{"user_info":{"auth":1,"status":"Active"}$tzPart}""" }
        return runBlocking { XtreamClient(api, json, "http://h:80", "u", "p").catchupUrl("55", start, 60) }
    }

    @Test fun usesPanelTimezone() =
        assertEquals("http://h:80/streaming/timeshift.php?username=u&password=p&stream=55&start=2024-01-01:16-00&duration=60", url("Asia/Dubai"))

    @Test fun fallsBackToUtc() = assertEquals(true, url(null).endsWith("start=2024-01-01:12-00&duration=60"))
}
