package app.iptv.core.data.xtream

import app.iptv.core.data.FakeApi
import app.iptv.core.data.network.Base64Lenient
import app.iptv.core.domain.error.IptvError
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.Json
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.*
import org.junit.Test
import retrofit2.HttpException
import retrofit2.Response
import java.io.IOException

class XtreamClientTest {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private fun client(api: FakeApi, format: String = "m3u8") = XtreamClient(api, json, "http://h", "u", "p", format)

    private val authOk = """{"user_info":{"username":"u","auth":1,"status":"Active","exp_date":"4102444800","is_trial":"0","active_cons":"1","max_connections":"2","allowed_output_formats":["m3u8","ts"]},"server_info":{"timezone":"Europe/London"}}"""

    @Test fun authenticateSuccess() {
        val acc = runBlocking { client(FakeApi { _, _ -> authOk }).authenticate() }
        assertEquals(4102444800000L, acc.expiresAt)
        assertEquals(2, acc.maxConnections)
        assertEquals(listOf("m3u8", "ts"), acc.allowedFormats)
        assertEquals("Europe/London", acc.serverTimezone)
        assertFalse(acc.isTrial)
    }

    @Test fun invalidCredentials() {
        assertThrowsError<IptvError.InvalidCredentials>("""{"user_info":{"auth":0}}""")
        assertThrowsError<IptvError.InvalidCredentials>("""{"server_info":{}}""")
    }

    @Test fun expiredAndDisabledAccounts() {
        assertThrowsError<IptvError.AccountExpired>("""{"user_info":{"auth":1,"status":"Expired","exp_date":"1000"}}""")
        assertThrowsError<IptvError.AccountExpired>("""{"user_info":{"auth":1,"status":"Active","exp_date":"1000"}}""")
        assertThrowsError<IptvError.AccountDisabled>("""{"user_info":{"auth":1,"status":"Banned"}}""")
    }

    @Test fun unlimitedAccountHasNoExpiry() {
        val acc = runBlocking { client(FakeApi { _, _ -> """{"user_info":{"auth":1,"status":"Active","exp_date":null}}""" }).authenticate() }
        assertNull(acc.expiresAt)
    }

    @Test fun networkAndHttpErrorsAreMapped() {
        assertThrowsFrom<IptvError.Network> { throw IOException("boom") }
        assertThrowsFrom<IptvError.InvalidCredentials> { throw HttpException(Response.error<Any>(403, "".toResponseBody(null))) }
        assertThrowsFrom<IptvError.Server> { throw HttpException(Response.error<Any>(503, "".toResponseBody(null))) }
        assertThrowsError<IptvError.InvalidResponse>("{\"user_info\":") // truncated JSON
    }

    @Test fun fetchLiveMapsChannelsAndPicksFormat() {
        val api = FakeApi { url, _ ->
            when {
                "action=get_live_categories" in url -> """[{"category_id":"1","category_name":"News"},{"category_id":"2","category_name":"Sports"}]"""
                "action=get_live_streams" in url -> """[
                  {"num":1,"name":"BBC One","stream_id":101,"stream_icon":"http://i/b.png","epg_channel_id":"bbc1.uk","tv_archive":1,"tv_archive_duration":"3","category_id":"1"},
                  {"num":"2","name":"Sky","stream_id":"102","stream_icon":"","epg_channel_id":null,"tv_archive":0,"category_id":"2"},
                  {"name":"no id"}]"""
                else -> authOk
            }
        }
        val live = runBlocking { client(api, "ts").fetchLive() }
        assertEquals(listOf("News", "Sports"), live.categories.map { it.name })
        assertEquals(2, live.channels.size)
        val bbc = live.channels[0]
        assertEquals("http://h/live/u/p/101.ts", bbc.streamUrl)
        assertEquals("bbc1.uk", bbc.tvgId); assertEquals(3, bbc.archiveDays); assertEquals("1", bbc.categoryRemoteId)
        assertNull(live.channels[1].logoUrl); assertNull(live.channels[1].tvgId); assertEquals(0, live.channels[1].archiveDays)
        assertEquals(listOf("http://h/xmltv.php?username=u&password=p"), live.epgUrls)
    }

    @Test fun fallsBackToAllowedFormatWhenPreferredNotOffered() {
        val api = FakeApi { url, _ ->
            when {
                "action=get_live_categories" in url -> "[]"
                "action=get_live_streams" in url -> """[{"name":"A","stream_id":1}]"""
                else -> """{"user_info":{"auth":1,"allowed_output_formats":["ts"]}}"""
            }
        }
        assertEquals("http://h/live/u/p/1.ts", runBlocking { client(api, "m3u8").fetchLive() }.channels[0].streamUrl)
    }

    @Test fun fetchMoviesAndSeries() {
        val api = FakeApi { url, _ ->
            when {
                "action=get_vod_categories" in url || "action=get_series_categories" in url -> """[{"category_id":"7","category_name":"Drama"}]"""
                "action=get_vod_streams" in url -> """[{"name":"Film","stream_id":55,"stream_icon":"http://i/f.jpg","rating":"6.5","added":"1700000000","category_id":"7","container_extension":"mkv"}]"""
                "action=get_series" in url -> """[{"name":"Show","series_id":9,"cover":"http://i/s.jpg","plot":"P","releaseDate":"2019-05-01","rating":"0","last_modified":"1700000000","category_id":"7"}]"""
                else -> authOk
            }
        }
        val c = client(api)
        val m = runBlocking { c.fetchMovies() }.movies.single()
        assertEquals("http://h/movie/u/p/55.mkv", m.streamUrl); assertEquals(6.5f, m.rating!!, 0.001f); assertEquals(1700000000000L, m.addedAt)
        val s = runBlocking { c.fetchSeries() }.series.single()
        assertEquals("2019", s.year); assertNull(s.rating); assertEquals("P", s.plot)
    }

    @Test fun seriesInfoParsesSeasonsAndTolerantFields() {
        val body = """{"seasons":[],"info":{"plot":"A plot","cast":"A, B","releaseDate":"2019-05-01","rating":"7.5"},
          "episodes":{"1":[
            {"id":"101","episode_num":1,"title":"Pilot","container_extension":"mkv","info":{"movie_image":"http://i/1.jpg","plot":"p1","duration_secs":2700},"season":1},
            {"id":"102","episode_num":"2","title":"Second","container_extension":"mp4","info":[],"season":1}],
           "2":[{"id":"201","episode_num":1,"title":"S2E1","container_extension":"mkv","info":{}}]}}"""
        val d = runBlocking { client(FakeApi { _, _ -> body }).seriesInfo("9") }
        assertEquals("A plot", d.plot); assertEquals("2019", d.year); assertEquals(7.5f, d.rating!!, 0.001f)
        assertEquals(3, d.episodes.size)
        assertEquals("http://h/series/u/p/101.mkv", d.episodes[0].streamUrl)
        assertEquals(2700, d.episodes[0].durationSecs)
        assertEquals(2, d.episodes[1].episodeNum); assertEquals("http://h/series/u/p/102.mp4", d.episodes[1].streamUrl)
        assertEquals(2, d.episodes[2].season) // taken from the "2" key
        assertEquals(5L, d.episodes[0].toDomain(5L).seriesId)
    }

    @Test fun vodInfo() {
        val body = """{"info":{"movie_image":"x","plot":"Plot","cast":"X, Y","releasedate":"2021-03-04","rating":"8.1","duration_secs":"6000","backdrop_path":["http://i/bd.jpg"]},"movie_data":{"container_extension":"mp4"}}"""
        val d = runBlocking { client(FakeApi { _, _ -> body }).vodInfo("55") }
        assertEquals("2021", d.year); assertEquals(6000, d.durationSecs); assertEquals("http://i/bd.jpg", d.backdropUrl); assertEquals("mp4", d.containerExtension)
    }

    @Test fun shortEpgDecodesBase64AndTimestamps() {
        val body = """{"epg_listings":[
          {"title":"TmV3cw==","description":"SGVhZGxpbmVz","start_timestamp":"1704110400","stop_timestamp":"1704114000"},
          {"title":"Plain Title","description":"","start":"2024-01-01 13:00:00","end":"2024-01-01 14:00:00"},
          {"title":"TmV3cw==","start_timestamp":"1704114000","stop_timestamp":"1704110400"}]}"""
        val api = FakeApi { _, _ -> body }
        val list = runBlocking { client(api).shortEpg("101", "bbc1.uk", 4) }
        assertEquals(2, list.size)
        assertEquals("News", list[0].title); assertEquals("Headlines", list[0].description)
        assertEquals(1704110400000L, list[0].startTime); assertEquals("bbc1.uk", list[0].channelTvgId)
        assertEquals("Plain Title", list[1].title); assertNull(list[1].description)
        assertEquals(1704114000000L, list[1].startTime)
        assertTrue(api.calls.single().first.endsWith("action=get_short_epg&stream_id=101&limit=4"))
    }

    @Test fun timeshiftUrlUsesAccountTimezone() {
        val c = client(FakeApi { _, _ -> authOk })
        runBlocking { c.authenticate() }
        assertTrue(c.timeshiftUrl("1", 1704110400000L, 30).endsWith("start=2024-01-01:12-00&duration=30")) // London in January = UTC
    }

    @Test fun base64Heuristics() {
        assertEquals("News", Base64Lenient.decodeOrSelf("News"))
        assertEquals("Test", Base64Lenient.decodeOrSelf("Test"))
        assertEquals("Two words", Base64Lenient.decodeOrSelf("Two words"))
        assertEquals("Hello", Base64Lenient.decodeOrSelf("SGVsbG8="))
        assertEquals("Héllo", Base64Lenient.decodeOrSelf("SMOpbGxv"))
    }

    // ---- helpers ----
    private inline fun <reified T : IptvError> assertThrowsFrom(noinline block: () -> String) {
        try {
            runBlocking { client(FakeApi { _, _ -> block() }).authenticate() }
            fail("expected ${T::class.simpleName}")
        } catch (e: IptvError) {
            assertTrue("got ${e::class.simpleName}", e is T)
        }
    }

    private inline fun <reified T : IptvError> assertThrowsError(body: String) = assertThrowsFrom<T> { body }
}
