package app.iptv.core.data.xtream

import org.junit.Assert.*
import org.junit.Test
import java.util.TimeZone

class XtreamUrlBuilderTest {
    private val b = XtreamUrlBuilder("http://h:8080", "u", "p")

    @Test fun normalizesServerInput() {
        assertEquals("http://host:8080", XtreamUrlBuilder.normalizeBase("host:8080"))
        assertEquals("http://host:8080", XtreamUrlBuilder.normalizeBase(" http://host:8080/ "))
        assertEquals("http://host", XtreamUrlBuilder.normalizeBase("http://host/player_api.php?username=a&password=b"))
        assertEquals("https://host", XtreamUrlBuilder.normalizeBase("https://host/c/"))
        assertEquals("http://host/panel", XtreamUrlBuilder.normalizeBase("http://host/panel/get.php"))
        assertEquals("http://c", XtreamUrlBuilder.normalizeBase("http://c"))
    }

    @Test fun liveUrls() {
        assertEquals("http://h:8080/live/u/p/123.m3u8", b.live("123"))
        assertEquals("http://h:8080/live/u/p/123.ts", b.live("123", "ts"))
    }

    @Test fun movieAndSeriesUrls() {
        assertEquals("http://h:8080/movie/u/p/55.mp4", b.movie("55"))
        assertEquals("http://h:8080/movie/u/p/55.mkv", b.movie("55", "mkv"))
        assertEquals("http://h:8080/series/u/p/901.mkv", b.series("901"))
        assertEquals("http://h:8080/series/u/p/901.avi", b.series("901", "avi"))
    }

    @Test fun credentialsAreEncodedInPathAndQuery() {
        val x = XtreamUrlBuilder("h", "us er", "p@ss/word")
        assertEquals("http://h/live/us%20er/p%40ss%2Fword/1.ts", x.live("1", "ts"))
        assertEquals("http://h/player_api.php?username=us+er&password=p%40ss%2Fword", x.playerApi())
    }

    @Test fun playerApiWithActionAndParams() {
        assertEquals("http://h:8080/player_api.php?username=u&password=p", b.playerApi())
        assertEquals(
            "http://h:8080/player_api.php?username=u&password=p&action=get_series_info&series_id=5",
            b.playerApi("get_series_info", mapOf("series_id" to "5"))
        )
        assertEquals(
            "http://h:8080/player_api.php?username=u&password=p&action=get_short_epg&stream_id=9&limit=4",
            b.playerApi("get_short_epg", mapOf("stream_id" to "9", "limit" to "4"))
        )
    }

    @Test fun xmltvUrl() = assertEquals("http://h:8080/xmltv.php?username=u&password=p", b.xmltv())

    @Test fun timeshiftUsesServerTimezone() {
        val start = 1704110400000L // 2024-01-01T12:00:00Z
        assertEquals(
            "http://h:8080/streaming/timeshift.php?username=u&password=p&stream=55&start=2024-01-01:12-00&duration=60",
            b.timeshift("55", start, 60)
        )
        assertTrue(b.timeshift("55", start, 90, TimeZone.getTimeZone("Asia/Dubai")).endsWith("start=2024-01-01:16-00&duration=90"))
    }

    @Test fun detectsCredentialsInGetPhpLink() {
        val c = XtreamUrlBuilder.parseGetPhpUrl("http://host:80/get.php?username=bob&password=s%40cret&type=m3u_plus&output=ts")!!
        assertEquals("bob", c.username); assertEquals("s@cret", c.password); assertEquals("http://host:80", c.serverUrl)
        assertNull(XtreamUrlBuilder.parseGetPhpUrl("http://host/list.m3u"))
        assertNull(XtreamUrlBuilder.parseGetPhpUrl("http://host/get.php?type=m3u"))
    }
}
