plugins { alias(libs.plugins.android.library); alias(libs.plugins.kotlin.android) }
android {
    namespace = "app.iptv.core.domain"
    compileSdk = 34
    defaultConfig { minSdk = 21 }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { api(libs.kotlinx.coroutines.android); api(libs.paging.runtime); testImplementation(libs.junit); testImplementation(libs.kotlinx.coroutines.test) }
