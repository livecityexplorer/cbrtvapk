package app.iptv.core.domain.error

/** User-presentable failures. The UI maps these to localized strings; [message] is an English default. */
sealed class IptvError(message: String, cause: Throwable? = null) : Exception(message, cause) {
    class Network(cause: Throwable? = null) : IptvError("Can't reach the server. Check the address and your connection.", cause)
    class InvalidCredentials(message: String = "Invalid username, password or MAC address.") : IptvError(message)
    class AccountExpired(val expiredAt: Long?) : IptvError("This subscription has expired.")
    class AccountDisabled(status: String) : IptvError("This account is $status.")
    class InvalidResponse(detail: String = "Unexpected response from the server.", cause: Throwable? = null) : IptvError(detail, cause)
    class InvalidInput(message: String) : IptvError(message)
    class Server(val code: Int) : IptvError("The server returned an error ($code).")
    class Unknown(cause: Throwable) : IptvError(cause.message ?: "Something went wrong.", cause)
}
