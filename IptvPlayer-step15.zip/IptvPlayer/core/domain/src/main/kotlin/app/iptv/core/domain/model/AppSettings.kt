package app.iptv.core.domain.model

enum class ThemeMode { DARK, AMOLED }
enum class DecoderMode { HARDWARE, SOFTWARE }

/** Preset buffer windows (ms). Small = fastest zapping, Large = most resilient to a flaky connection. */
enum class BufferSize(val minMs: Int, val maxMs: Int, val startMs: Int, val rebufferMs: Int) {
    SMALL(5_000, 20_000, 1_000, 2_000),
    MEDIUM(15_000, 50_000, 1_500, 3_000),
    LARGE(30_000, 120_000, 3_000, 5_000)
}

enum class SubtitleColor(val argb: Long) {
    WHITE(0xFFFFFFFF), YELLOW(0xFFFFEB3B), GREEN(0xFF69F0AE), CYAN(0xFF18FFFF)
}

/** Everything the user can change in Settings (persisted in DataStore). [pinHash] is "salt:hash", never the PIN. */
data class AppSettings(
    val theme: ThemeMode = ThemeMode.DARK,
    val epgAutoRefresh: Boolean = true,
    val epgIntervalHours: Int = 12,
    val bufferSize: BufferSize = BufferSize.MEDIUM,
    val decoder: DecoderMode = DecoderMode.HARDWARE,
    val defaultAspect: AspectMode = AspectMode.FIT,
    val subtitleSizeSp: Int = 22,
    val subtitleColor: SubtitleColor = SubtitleColor.WHITE,
    val hideAdult: Boolean = false,
    val pinHash: String? = null,
    val disclaimerAccepted: Boolean = false
) {
    val hasPin: Boolean get() = pinHash != null

    companion object {
        val INTERVAL_CHOICES_HOURS = listOf(3, 6, 12, 24, 48)
        const val SUBTITLE_MIN_SP = 14
        const val SUBTITLE_MAX_SP = 40
    }
}

/** Maps the user's choices onto the player tuning; [base] carries per-screen values (e.g. VOD stall timeout). */
fun AppSettings.toPlaybackConfig(base: PlaybackConfig = PlaybackConfig()): PlaybackConfig = base.copy(
    minBufferMs = bufferSize.minMs, maxBufferMs = bufferSize.maxMs,
    startBufferMs = bufferSize.startMs, rebufferMs = bufferSize.rebufferMs,
    preferSoftwareDecoder = decoder == DecoderMode.SOFTWARE
)
