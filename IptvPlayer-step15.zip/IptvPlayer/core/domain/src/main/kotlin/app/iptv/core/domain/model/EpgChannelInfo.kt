package app.iptv.core.domain.model

/** What the EPG importer needs to know about a channel (kept small: playlists can have 10k+ channels). */
data class EpgChannelInfo(val id: Long, val remoteId: String, val tvgId: String?, val tvgName: String?, val name: String)
