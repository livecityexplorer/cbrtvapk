package app.iptv.core.domain.model

enum class CategoryKind { LIVE, MOVIE, SERIES }
enum class ContentType { CHANNEL, MOVIE, EPISODE, RECORDING }
enum class RecordingStatus { SCHEDULED, RECORDING, COMPLETED, FAILED, CANCELLED }

data class Category(
    val id: Long, val playlistId: Long, val remoteId: String, val name: String, val kind: CategoryKind,
    val sortOrder: Int, val isHidden: Boolean, val isLocked: Boolean
)

data class Channel(
    val id: Long, val playlistId: Long, val categoryId: Long?, val remoteId: String, val name: String,
    val logoUrl: String?, val tvgId: String?, val tvgName: String?, val streamUrl: String,
    val number: Int, val archiveDays: Int, val sortOrder: Int, val isLocked: Boolean
) { val hasArchive get() = archiveDays > 0 }

data class EpgProgram(
    val id: Long = 0, val channelTvgId: String, val title: String, val description: String?,
    val startTime: Long, val endTime: Long, val posterUrl: String? = null
) {
    fun isLiveAt(now: Long) = now in startTime until endTime
    fun progressAt(now: Long): Float =
        if (endTime <= startTime) 0f else ((now - startTime).toFloat() / (endTime - startTime)).coerceIn(0f, 1f)
}

data class Movie(
    val id: Long, val playlistId: Long, val categoryId: Long?, val remoteId: String, val name: String,
    val posterUrl: String?, val plot: String?, val year: String?, val rating: Float?, val cast: String?,
    val streamUrl: String, val addedAt: Long
)

data class Series(
    val id: Long, val playlistId: Long, val categoryId: Long?, val remoteId: String, val name: String,
    val posterUrl: String?, val plot: String?, val year: String?, val rating: Float?, val cast: String?, val addedAt: Long
)

data class Episode(
    val id: Long = 0, val seriesId: Long, val season: Int, val episodeNum: Int, val title: String,
    val plot: String?, val imageUrl: String?, val streamUrl: String, val durationSecs: Int
)

data class WatchHistory(
    val id: Long = 0, val type: ContentType, val contentKey: String, val playlistId: Long,
    val title: String, val imageUrl: String?, val streamUrl: String,
    val positionMs: Long, val durationMs: Long, val updatedAt: Long
)

data class Recording(
    val id: Long = 0, val channelId: Long?, val channelName: String, val title: String, val streamUrl: String,
    val startTime: Long, val endTime: Long, val status: RecordingStatus,
    val filePath: String? = null, val sizeBytes: Long = 0
)

/** Parser/client output, not yet persisted. Links to categories via [categoryRemoteId]. */
data class CategoryImport(val remoteId: String, val name: String)
data class ChannelImport(
    val remoteId: String, val name: String, val logoUrl: String?, val tvgId: String?, val tvgName: String?,
    val streamUrl: String, val number: Int = 0, val archiveDays: Int = 0, val categoryRemoteId: String?
)
data class MovieImport(
    val remoteId: String, val name: String, val posterUrl: String?, val plot: String?, val year: String?,
    val rating: Float?, val cast: String?, val streamUrl: String, val categoryRemoteId: String?, val addedAt: Long = 0
)
data class SeriesImport(
    val remoteId: String, val name: String, val posterUrl: String?, val plot: String?, val year: String?,
    val rating: Float?, val cast: String?, val categoryRemoteId: String?, val addedAt: Long = 0
)
