package app.iptv.core.domain.model

enum class AspectMode { FIT, ZOOM, STRETCH, RATIO_16_9, RATIO_4_3 }

/** Playback tuning. Defaults are IPTV-friendly (fast zapping); step 13 maps the user's settings onto this. */
data class PlaybackConfig(
    val maxRetries: Int = 5,
    val retryBaseDelayMs: Long = 1_000,
    val retryMaxDelayMs: Long = 30_000,
    /** Buffering for this long without progress counts as a dropped stream. */
    val stallTimeoutMs: Long = 15_000,
    val minBufferMs: Int = 15_000,
    val maxBufferMs: Int = 50_000,
    /** Small values = faster channel start. */
    val startBufferMs: Int = 1_500,
    val rebufferMs: Int = 3_000,
    val preferSoftwareDecoder: Boolean = false,
    /** Keep playing (audio) when the app is in the background, via a media session + foreground service. Off by default. */
    val backgroundAudio: Boolean = false
)
