package app.iptv.core.domain.model

enum class PlaylistType { M3U, XTREAM, STALKER }

data class Playlist(
    val id: Long = 0,
    val name: String,
    val type: PlaylistType,
    val url: String,
    val username: String? = null,
    val password: String? = null,
    val macAddress: String? = null,
    val epgUrls: List<String> = emptyList(),
    val lastRefresh: Long = 0
)
