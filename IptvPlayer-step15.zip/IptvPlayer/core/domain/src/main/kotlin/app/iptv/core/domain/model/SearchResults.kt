package app.iptv.core.domain.model

data class ProgramHit(val program: EpgProgram, val channel: Channel)

data class SearchResults(
    val channels: List<Channel> = emptyList(),
    val movies: List<Movie> = emptyList(),
    val series: List<Series> = emptyList(),
    val programs: List<ProgramHit> = emptyList()
) {
    val isEmpty: Boolean get() = channels.isEmpty() && movies.isEmpty() && series.isEmpty() && programs.isEmpty()
}
