package app.iptv.core.domain.reminder

import kotlinx.coroutines.flow.Flow

data class ReminderRequest(val channelId: Long, val channelName: String, val programTitle: String, val startTime: Long) {
    companion object {
        const val EXTRA_CHANNEL_ID = "app.iptv.extra.CHANNEL_ID"
        fun key(channelId: Long, startTime: Long) = "reminder_${channelId}_$startTime"
    }
}

interface ReminderScheduler {
    /** Returns false (and schedules nothing) when the programme already started. */
    fun schedule(request: ReminderRequest): Boolean
    fun cancel(channelId: Long, startTime: Long)
    fun observeScheduled(channelId: Long, startTime: Long): Flow<Boolean>
}
