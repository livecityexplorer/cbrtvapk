package app.iptv.core.domain.repository

/** Settings + playlists <-> JSON text (the UI moves the text to/from a file via the Storage Access Framework). */
interface BackupRepository {
    suspend fun export(): String
    /** Returns how many playlists were added (duplicates are skipped) or throws [IllegalArgumentException] for a bad file. */
    suspend fun import(json: String): ImportResult
}

data class ImportResult(val playlistsAdded: Int, val playlistsSkipped: Int, val settingsRestored: Boolean)
