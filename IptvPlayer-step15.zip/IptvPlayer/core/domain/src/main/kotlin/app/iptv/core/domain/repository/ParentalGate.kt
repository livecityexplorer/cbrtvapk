package app.iptv.core.domain.repository

import kotlinx.coroutines.flow.Flow

/**
 * Parental controls: PIN management plus "does this content need the PIN right now?".
 * After a correct PIN the app stays unlocked for [UNLOCK_WINDOW_MS] (or until [lockAll]).
 */
interface ParentalGate {
    val hasPin: Flow<Boolean>
    suspend fun setPin(newPin: String, currentPin: String?): Boolean
    suspend fun clearPin(currentPin: String): Boolean
    /** Checks the PIN; on success opens the unlock window. */
    suspend fun verify(pin: String): Boolean

    suspend fun channelNeedsPin(channelId: Long): Boolean
    suspend fun movieNeedsPin(movieId: Long): Boolean
    suspend fun episodeNeedsPin(episodeId: Long): Boolean
    suspend fun categoryNeedsPin(categoryId: Long): Boolean
    /** True when a PIN exists and the unlock window is not open (for gating Settings sections and lock toggles). */
    suspend fun isLockedNow(): Boolean

    fun lockAll()
    suspend fun setHideAdult(enabled: Boolean)

    companion object { const val UNLOCK_WINDOW_MS = 15 * 60 * 1000L }
}
