package app.iptv.core.domain.repository

import app.iptv.core.domain.model.AppSettings
import kotlinx.coroutines.flow.Flow

enum class LiveViewMode { LIST, GRID }

/** User preferences (DataStore). */
interface PreferencesRepository {
    val activePlaylistId: Flow<Long?>
    suspend fun setActivePlaylistId(id: Long)
    val liveViewMode: Flow<LiveViewMode>
    suspend fun setLiveViewMode(mode: LiveViewMode)
    /** Epoch millis of the last successful EPG refresh (0 = never). */
    val lastEpgRefresh: Flow<Long>
    suspend fun setLastEpgRefresh(timestamp: Long)
    /** SAF tree URI chosen for recordings; null = app-specific storage. */
    val recordingsFolder: Flow<String?>
    suspend fun setRecordingsFolder(uri: String?)
    /** All user-facing settings (theme, EPG, playback, subtitles, parental, disclaimer). */
    val settings: Flow<AppSettings>
    /** Atomically applies [transform] to the stored settings. */
    suspend fun updateSettings(transform: (AppSettings) -> AppSettings)
}
