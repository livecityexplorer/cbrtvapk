package app.iptv.core.domain.repository

import app.iptv.core.domain.model.Channel
import app.iptv.core.domain.model.EpgProgram
import app.iptv.core.domain.model.Recording

enum class InvalidReason { ALREADY_ENDED, TOO_LONG }

sealed interface ScheduleResult {
    /** [conflicts] = other recordings overlapping in time (several streams at once may exceed the provider's connection limit). */
    data class Scheduled(val id: Long, val startsNow: Boolean, val conflicts: List<Recording>) : ScheduleResult
    data class AlreadyScheduled(val id: Long) : ScheduleResult
    data class Invalid(val reason: InvalidReason) : ScheduleResult
}

/** Everything the UI needs for DVR: schedule, start now, stop/cancel, delete. */
interface RecordingController {
    suspend fun scheduleProgram(channel: Channel, program: EpgProgram): ScheduleResult
    suspend fun recordNow(channel: Channel, title: String, endTime: Long): ScheduleResult
    /** Stops a running recording (keeping what was recorded) or cancels a scheduled one. */
    suspend fun stop(id: Long)
    /** Stops if needed, deletes the file and the entry. */
    suspend fun delete(id: Long)
    /** Re-arms alarms after a reboot/app update and closes recordings that were interrupted. */
    suspend fun rescheduleAll()
    /** On Android 12+ exact start times need the user's "Alarms & reminders" permission. */
    fun exactAlarmsAllowed(): Boolean
}
