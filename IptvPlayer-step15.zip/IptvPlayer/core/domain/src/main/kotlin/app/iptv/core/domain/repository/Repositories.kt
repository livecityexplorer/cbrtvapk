package app.iptv.core.domain.repository

import androidx.paging.PagingData
import app.iptv.core.domain.model.*
import kotlinx.coroutines.flow.Flow

interface PlaylistRepository {
    fun observeAll(): Flow<List<Playlist>>
    suspend fun get(id: Long): Playlist?
    /** Inserts when id == 0, otherwise updates. Returns the row id. */
    suspend fun save(playlist: Playlist): Long
    suspend fun delete(id: Long)
    suspend fun markRefreshed(id: Long, timestamp: Long)
}

interface ChannelRepository {
    fun observeCategories(playlistId: Long, kind: CategoryKind): Flow<List<Category>>
    fun channels(playlistId: Long, categoryId: Long?, query: String): Flow<PagingData<Channel>>
    fun observeFavorites(): Flow<List<Channel>>
    fun observeRecent(limit: Int): Flow<List<Channel>>
    suspend fun getChannel(id: Long): Channel?
    suspend fun epgChannels(playlistId: Long): List<EpgChannelInfo>
    /** Channel ids in list order (same order as the Live TV list); used for channel up/down. */
    suspend fun orderedChannelIds(playlistId: Long, categoryId: Long?): List<Long>
    suspend fun searchChannels(query: String, limit: Int): List<Channel>
    /** Upserts (keeping favorites, order and locks) and removes channels/categories no longer in the source. */
    suspend fun replaceLiveContent(playlistId: Long, categories: List<CategoryImport>, channels: List<ChannelImport>)
    suspend fun setCategoryHidden(categoryId: Long, hidden: Boolean)
    suspend fun setCategoryLocked(categoryId: Long, locked: Boolean)
    suspend fun setChannelLocked(channelId: Long, locked: Boolean)
    suspend fun saveChannelOrder(orderedChannelIds: List<Long>)
    /** Moves a channel one step within its category (or the whole playlist when [categoryId] is null). */
    suspend fun moveChannel(playlistId: Long, categoryId: Long?, channelId: Long, up: Boolean)
}

interface EpgRepository {
    fun observeRange(tvgIds: List<String>, from: Long, to: Long): Flow<List<EpgProgram>>
    /** Current and next programme (current first). [now] should change about once a minute. */
    fun observeNowAndNext(tvgId: String, now: Long): Flow<List<EpgProgram>>
    suspend fun nowAndNext(tvgId: String, now: Long): List<EpgProgram>
    suspend fun importPrograms(programs: List<EpgProgram>)
    suspend fun purgeEndedBefore(timestamp: Long)
    suspend fun search(query: String, now: Long, limit: Int): List<EpgProgram>
}

interface VodRepository {
    fun movies(playlistId: Long, categoryId: Long?, query: String): Flow<PagingData<Movie>>
    fun series(playlistId: Long, categoryId: Long?, query: String): Flow<PagingData<Series>>
    fun observeEpisodes(seriesId: Long): Flow<List<Episode>>
    /** Newest first (by the provider's added date), hidden categories excluded. Feeds Home > Recently added. */
    fun observeRecentMovies(playlistId: Long, limit: Int): Flow<List<Movie>>
    fun observeRecentSeries(playlistId: Long, limit: Int): Flow<List<Series>>
    suspend fun getMovie(id: Long): Movie?
    fun observeMovie(id: Long): Flow<Movie?>
    fun observeSeries(id: Long): Flow<Series?>
    suspend fun getEpisode(id: Long): Episode?
    suspend fun getSeries(id: Long): Series?
    suspend fun searchMovies(query: String, limit: Int): List<Movie>
    suspend fun searchSeries(query: String, limit: Int): List<Series>
    suspend fun replaceMovies(playlistId: Long, categories: List<CategoryImport>, movies: List<MovieImport>)
    suspend fun replaceSeries(playlistId: Long, categories: List<CategoryImport>, series: List<SeriesImport>)
    suspend fun updateMovieDetail(id: Long, plot: String?, cast: String?, year: String?, rating: Float?)
    suspend fun updateSeriesDetail(id: Long, plot: String?, cast: String?, year: String?, rating: Float?)
    suspend fun upsertEpisodes(seriesId: Long, episodes: List<Episode>)
}

interface UserDataRepository {
    fun observeFavoriteIds(): Flow<Set<Long>>
    suspend fun setFavorite(channelId: Long, favorite: Boolean)
    suspend fun saveProgress(entry: WatchHistory)
    suspend fun getProgress(type: ContentType, contentKey: String): WatchHistory?
    fun observeProgress(type: ContentType, contentKey: String): Flow<WatchHistory?>
    fun observeProgressByType(type: ContentType): Flow<List<WatchHistory>>
    fun observeContinueWatching(limit: Int): Flow<List<WatchHistory>>
    suspend fun removeHistory(id: Long)
    suspend fun clearHistory()
}

interface RecordingRepository {
    fun observeAll(): Flow<List<Recording>>
    suspend fun get(id: Long): Recording?
    suspend fun save(recording: Recording): Long
    suspend fun delete(id: Long)
    suspend fun dueToStart(now: Long): List<Recording>
    suspend fun updateStatus(id: Long, status: RecordingStatus, filePath: String?)
    suspend fun updateProgress(id: Long, sizeBytes: Long)
}
