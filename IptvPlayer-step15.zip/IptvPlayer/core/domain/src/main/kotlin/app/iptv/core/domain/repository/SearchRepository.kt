package app.iptv.core.domain.repository

import app.iptv.core.domain.model.SearchResults

interface SearchRepository {
    /** Channels, movies, series and upcoming EPG programmes of one playlist matching [query] (<= [limitPerType] each). */
    suspend fun search(playlistId: Long, query: String, limitPerType: Int = 20): SearchResults
}
