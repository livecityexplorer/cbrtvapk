package app.iptv.core.domain.repository

import app.iptv.core.domain.model.Channel
import app.iptv.core.domain.model.EpgProgram

/** Turns a stored channel into a playable URL right before playback. Throws IptvError. */
interface StreamResolver {
    /** Stalker links are resolved via the portal; all other URLs are returned unchanged (may carry `|header=…`). */
    suspend fun resolveLive(channel: Channel): String
    /** Catch-up URL for a past programme, or null when the source has no catch-up support. */
    suspend fun resolveCatchup(channel: Channel, program: EpgProgram): String?
}
