package app.iptv.core.domain.repository

import app.iptv.core.domain.model.Movie
import app.iptv.core.domain.model.Series

/** Fetches the details the lists don't carry (plot, cast, episodes) from the source and stores them. Throws IptvError. */
interface VodDetailsLoader {
    suspend fun loadMovie(movie: Movie)
    suspend fun loadSeries(series: Series)
}
