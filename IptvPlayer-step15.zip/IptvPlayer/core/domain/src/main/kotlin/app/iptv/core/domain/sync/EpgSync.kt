package app.iptv.core.domain.sync

data class EpgSyncResult(val programs: Int, val failedUrls: List<String> = emptyList(), val noSource: Boolean = false)

interface EpgSyncer {
    /** Imports EPG for one playlist from its XMLTV URLs (and the portal for Stalker). Throws IptvError if every source failed. */
    suspend fun refresh(playlistId: Long, onProgress: (programsImported: Int) -> Unit = {}): EpgSyncResult
}
