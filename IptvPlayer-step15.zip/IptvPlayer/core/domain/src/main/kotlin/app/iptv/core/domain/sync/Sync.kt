package app.iptv.core.domain.sync

import app.iptv.core.domain.error.IptvError
import app.iptv.core.domain.model.Playlist
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class SyncStage { CONNECTING, LIVE, MOVIES, SERIES, SAVING }
data class SyncSummary(val channels: Int, val movies: Int, val series: Int, val categories: Int)
data class ConnectionInfo(val status: String? = null, val expiresAt: Long? = null, val maxConnections: Int? = null)

sealed interface SyncState {
    data class Running(val stage: SyncStage, val count: Int = 0) : SyncState
    data class Success(val summary: SyncSummary) : SyncState
    data class Failed(val error: IptvError) : SyncState
}

interface PlaylistSyncer {
    /** Downloads/parses the playlist's sources and stores them. Never throws: failures arrive as [SyncState.Failed]. */
    fun sync(playlistId: Long): Flow<SyncState>
    /** Validates the source without storing anything. Throws [IptvError]. */
    suspend fun testConnection(draft: Playlist): ConnectionInfo
}

/** App-wide sync runner so progress survives screen changes and a playlist is never synced twice at once. */
class SyncManager(private val syncer: PlaylistSyncer, private val scope: CoroutineScope) {
    private val _states = MutableStateFlow<Map<Long, SyncState>>(emptyMap())
    val states: StateFlow<Map<Long, SyncState>> = _states.asStateFlow()
    private val jobs = HashMap<Long, Job>()

    @Synchronized
    fun sync(playlistId: Long) {
        if (jobs[playlistId]?.isActive == true) return
        jobs[playlistId] = scope.launch {
            try {
                syncer.sync(playlistId).collect { s -> _states.update { it + (playlistId to s) } }
            } catch (e: CancellationException) {
                _states.update { it - playlistId }
                throw e
            } catch (e: Throwable) {
                _states.update { it + (playlistId to SyncState.Failed(e as? IptvError ?: IptvError.Unknown(e))) }
            }
        }
    }

    @Synchronized
    fun cancel(playlistId: Long) {
        jobs.remove(playlistId)?.cancel()
        _states.update { it - playlistId }
    }
}
