package app.iptv.core.domain.usecase

import app.iptv.core.domain.model.Playlist
import app.iptv.core.domain.repository.PlaylistRepository
import app.iptv.core.domain.validation.PlaylistField
import app.iptv.core.domain.validation.PlaylistValidator
import app.iptv.core.domain.validation.ValidationError

sealed interface SaveResult {
    data class Saved(val id: Long, val playlist: Playlist) : SaveResult
    data class Invalid(val errors: Map<PlaylistField, ValidationError>) : SaveResult
}

class SavePlaylistUseCase(private val repository: PlaylistRepository) {
    suspend operator fun invoke(draft: Playlist): SaveResult {
        val normalized = PlaylistValidator.normalize(draft)
        val errors = PlaylistValidator.validate(normalized)
        if (errors.isNotEmpty()) return SaveResult.Invalid(errors)
        val id = repository.save(normalized)
        return SaveResult.Saved(id, normalized.copy(id = id))
    }
}
