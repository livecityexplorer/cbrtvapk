package app.iptv.core.domain.util

import app.iptv.core.domain.model.Playlist

object ActivePlaylist {
    /** The stored playlist if it still exists, otherwise the first one. */
    fun resolve(playlists: List<Playlist>, storedId: Long?): Playlist? =
        playlists.firstOrNull { it.id == storedId } ?: playlists.firstOrNull()
}
