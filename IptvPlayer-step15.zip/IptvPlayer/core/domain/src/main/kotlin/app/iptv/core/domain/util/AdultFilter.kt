package app.iptv.core.domain.util

/** Heuristic for "adult" category names (providers have no standard flag). Used by the "Hide adult categories" toggle. */
object AdultFilter {
    private val words = Regex("""\b(xxx|adult|adults|porn|porno|erotic|erotica|hentai|nsfw|playboy|hustler|18\s?plus)\b""", RegexOption.IGNORE_CASE)

    fun isAdult(categoryName: String): Boolean {
        val n = categoryName.lowercase()
        return "18+" in n || "+18" in n || words.containsMatchIn(n)
    }
}
