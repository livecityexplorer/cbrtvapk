package app.iptv.core.domain.util

import app.iptv.core.domain.model.Channel
import app.iptv.core.domain.model.EpgProgram
import kotlin.math.ceil

object Catchup {
    private const val DAY_MS = 24L * 60 * 60 * 1000

    /** The channel has an archive, the programme has started, and it is still inside the archive window. */
    fun isAvailable(channel: Channel, program: EpgProgram, now: Long): Boolean =
        channel.archiveDays > 0 && program.startTime <= now && program.startTime >= now - channel.archiveDays * DAY_MS

    fun durationMinutes(program: EpgProgram): Int =
        ceil((program.endTime - program.startTime) / 60_000.0).toInt().coerceAtLeast(1)
}
