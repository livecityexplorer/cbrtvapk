package app.iptv.core.domain.util

import java.util.Collections

object ChannelOrdering {
    /** New order after moving [id] one step up/down, or null when it can't move (unknown id or already at the edge). */
    fun move(ids: List<Long>, id: Long, up: Boolean): List<Long>? {
        val i = ids.indexOf(id)
        if (i < 0) return null
        val j = if (up) i - 1 else i + 1
        if (j !in ids.indices) return null
        return ids.toMutableList().also { Collections.swap(it, i, j) }
    }
}
