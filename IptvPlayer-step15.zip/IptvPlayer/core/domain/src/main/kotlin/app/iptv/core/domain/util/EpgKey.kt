package app.iptv.core.domain.util

/**
 * The key under which a channel's programmes are stored/queried (EpgProgram.channelTvgId).
 * tvg-id when present (case-insensitive), otherwise a normalized tvg-name/name fallback.
 */
object EpgKey {
    fun normalizeName(s: String): String = buildString(s.length) {
        for (ch in s.lowercase()) if (ch.isLetterOrDigit()) append(ch)
    }

    fun of(tvgId: String?, tvgName: String?, name: String): String =
        tvgId?.trim()?.takeIf { it.isNotEmpty() }?.lowercase()
            ?: ("name:" + normalizeName(tvgName?.takeIf { it.isNotBlank() } ?: name))
}
