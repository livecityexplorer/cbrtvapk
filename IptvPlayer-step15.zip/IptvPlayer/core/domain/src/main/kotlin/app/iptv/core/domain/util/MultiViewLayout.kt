package app.iptv.core.domain.util

data class LayoutRect(val x: Float, val y: Float, val w: Float, val h: Float)

object MultiViewLayout {
    const val MAX_PANES = 4

    /**
     * Slots for [count] (0..4) panes in a [width] x [height] area with [gap] between them:
     * 1 = full, 2 = side by side, 3 = one large on the left + two stacked, 4 = 2x2.
     */
    fun compute(count: Int, width: Float, height: Float, gap: Float = 0f): List<LayoutRect> {
        val n = count.coerceIn(0, MAX_PANES)
        val halfW = (width - gap) / 2f
        val halfH = (height - gap) / 2f
        return when (n) {
            0 -> emptyList()
            1 -> listOf(LayoutRect(0f, 0f, width, height))
            2 -> listOf(LayoutRect(0f, 0f, halfW, height), LayoutRect(halfW + gap, 0f, halfW, height))
            3 -> {
                val bigW = (width - gap) * 2f / 3f
                val smallW = width - gap - bigW
                listOf(
                    LayoutRect(0f, 0f, bigW, height),
                    LayoutRect(bigW + gap, 0f, smallW, halfH),
                    LayoutRect(bigW + gap, halfH + gap, smallW, halfH)
                )
            }
            else -> listOf(
                LayoutRect(0f, 0f, halfW, halfH), LayoutRect(halfW + gap, 0f, halfW, halfH),
                LayoutRect(0f, halfH + gap, halfW, halfH), LayoutRect(halfW + gap, halfH + gap, halfW, halfH)
            )
        }
    }
}
