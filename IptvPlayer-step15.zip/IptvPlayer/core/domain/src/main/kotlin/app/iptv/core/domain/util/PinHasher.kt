package app.iptv.core.domain.util

import java.security.MessageDigest
import java.security.SecureRandom

/** Salted, iterated SHA-256 for the parental PIN. Stored as "hexSalt:hexHash". Pure JVM so it is unit-testable. */
object PinHasher {
    private const val ITERATIONS = 20_000
    const val MIN_LENGTH = 4
    const val MAX_LENGTH = 8

    fun isValidPin(pin: String) = pin.length in MIN_LENGTH..MAX_LENGTH && pin.all { it in '0'..'9' }

    fun hash(pin: String, salt: ByteArray = ByteArray(16).also { SecureRandom().nextBytes(it) }): String =
        salt.toHex() + ":" + digest(pin, salt).toHex()

    fun verify(pin: String, stored: String?): Boolean {
        if (stored == null) return false
        val parts = stored.split(':')
        if (parts.size != 2) return false
        val salt = parts[0].fromHex() ?: return false
        val expected = parts[1].fromHex() ?: return false
        return MessageDigest.isEqual(expected, digest(pin, salt)) // constant-time compare
    }

    private fun digest(pin: String, salt: ByteArray): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        var h = md.digest(salt + pin.toByteArray(Charsets.UTF_8))
        repeat(ITERATIONS) { md.reset(); h = md.digest(h + salt) }
        return h
    }

    private fun ByteArray.toHex() = joinToString("") { "%02x".format(it) }
    private fun String.fromHex(): ByteArray? =
        if (length % 2 != 0 || any { it !in "0123456789abcdef" }) null
        else ByteArray(length / 2) { substring(it * 2, it * 2 + 2).toInt(16).toByte() }
}
