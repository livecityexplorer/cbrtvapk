package app.iptv.core.domain.util

import app.iptv.core.domain.model.AspectMode
import kotlin.math.max
import kotlin.math.min

object Backoff {
    /** Exponential delay for retry [attempt] (1-based): base, 2x, 4x … capped. */
    fun delayMs(attempt: Int, baseMs: Long = 1_000, capMs: Long = 30_000): Long {
        val shift = (attempt - 1).coerceIn(0, 20)
        return min(capMs, baseMs * (1L shl shift))
    }
}

/** Seek step grows while the key is pressed repeatedly: 10 s -> 30 s -> 60 s -> 120 s. */
object SeekStepper {
    private val STEPS = longArrayOf(10_000, 30_000, 60_000, 120_000)
    const val REPEAT_WINDOW_MS = 1_000L

    fun next(previousStepMs: Long, sinceLastPressMs: Long): Long {
        if (sinceLastPressMs > REPEAT_WINDOW_MS) return STEPS.first()
        val i = STEPS.indexOf(previousStepMs)
        return if (i < 0) STEPS.first() else STEPS[min(i + 1, STEPS.lastIndex)]
    }
}

object AspectMath {
    /** Size (in the container's units) the video surface should have inside a container. [videoRatio] <= 0 = unknown. */
    fun surfaceSize(containerW: Float, containerH: Float, videoRatio: Float, mode: AspectMode): Pair<Float, Float> {
        if (containerW <= 0f || containerH <= 0f) return 0f to 0f
        val ratio = when (mode) {
            AspectMode.RATIO_16_9 -> 16f / 9f
            AspectMode.RATIO_4_3 -> 4f / 3f
            else -> videoRatio
        }
        if (mode == AspectMode.STRETCH || ratio <= 0f) return containerW to containerH
        return if (mode == AspectMode.ZOOM) {
            val w = max(containerW, containerH * ratio); w to w / ratio
        } else {
            val w = min(containerW, containerH * ratio); w to w / ratio
        }
    }
}

enum class StreamFormat { HLS, DASH, TS, UNKNOWN;
    companion object {
        fun detect(url: String): StreamFormat {
            val lower = url.lowercase()
            val path = lower.substringBefore('?')
            return when {
                path.endsWith(".m3u8") || ".m3u8" in lower -> HLS
                path.endsWith(".mpd") -> DASH
                path.endsWith(".ts") -> TS
                else -> UNKNOWN
            }
        }
    }
}
