package app.iptv.core.domain.util

import app.iptv.core.domain.model.Recording
import app.iptv.core.domain.model.RecordingStatus
import app.iptv.core.domain.repository.InvalidReason
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object RecordingPolicy {
    /** Recordings run a little past the scheduled end: broadcasters often overrun. */
    const val END_PADDING_MS = 60_000L
    const val MAX_DURATION_MS = 12L * 60 * 60 * 1000

    fun stopAt(endTime: Long) = endTime + END_PADDING_MS

    fun validate(startTime: Long, endTime: Long, now: Long): InvalidReason? = when {
        endTime <= now -> InvalidReason.ALREADY_ENDED
        endTime - maxOf(startTime, now) > MAX_DURATION_MS -> InvalidReason.TOO_LONG
        else -> null
    }
}

object RecordingConflicts {
    val ACTIVE = setOf(RecordingStatus.SCHEDULED, RecordingStatus.RECORDING)

    fun overlapping(existing: List<Recording>, start: Long, end: Long): List<Recording> =
        existing.filter { it.status in ACTIVE && it.startTime < end && start < it.endTime }
}

object RecordingNaming {
    private val ILLEGAL = Regex("""[\\/:*?"<>|\u0000-\u001F]""")
    private val SPACES = Regex("\\s+")

    /** "Channel - Title 20240101_2000.ts" with characters that are illegal in file names replaced. */
    fun fileName(channelName: String, title: String, startTime: Long, tz: TimeZone = TimeZone.getDefault()): String {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).apply { timeZone = tz }.format(Date(startTime))
        val base = listOf(channelName, title).map(::clean).filter { it.isNotEmpty() }.joinToString(" - ").ifEmpty { "Recording" }
        return base.take(100).trim() + " " + stamp + ".ts"
    }

    private fun clean(s: String) = s.replace(ILLEGAL, "_").replace(SPACES, " ").trim().trim('.')
}

object RecordingUrl {
    private val XTREAM_LIVE = Regex("""^(.*/live/[^/]+/[^/]+/\d+)\.m3u8((?:\?.*)?)$""", RegexOption.IGNORE_CASE)

    /** Xtream serves the same channel as plain MPEG-TS, which records without any HLS handling. */
    fun preferTs(url: String): String = XTREAM_LIVE.replace(url, "$1.ts$2")

    fun isHls(url: String): Boolean = url.lowercase().let { ".m3u8" in it }
}
