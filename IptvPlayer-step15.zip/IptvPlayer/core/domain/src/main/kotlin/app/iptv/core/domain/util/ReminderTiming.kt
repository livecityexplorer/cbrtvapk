package app.iptv.core.domain.util

object ReminderTiming {
    const val LEAD_MS = 2 * 60_000L

    /** Delay before notifying, or null when the programme already started. Inside the lead window: notify now. */
    fun delayMillis(startTime: Long, now: Long, lead: Long = LEAD_MS): Long? =
        if (startTime <= now) null else (startTime - lead - now).coerceAtLeast(0L)
}
