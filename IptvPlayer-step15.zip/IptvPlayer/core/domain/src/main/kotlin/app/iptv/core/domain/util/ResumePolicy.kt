package app.iptv.core.domain.util

import app.iptv.core.domain.model.Episode
import app.iptv.core.domain.model.WatchHistory

object ResumePolicy {
    const val MIN_RESUME_MS = 10_000L
    private const val FINISHED_PERCENT = 95

    fun isFinished(positionMs: Long, durationMs: Long) = durationMs > 0 && positionMs >= durationMs * FINISHED_PERCENT / 100

    /** Where playback should start: 0 for new/finished/barely-started titles, else the saved position. */
    fun startPosition(positionMs: Long, durationMs: Long): Long = when {
        durationMs <= 0 || positionMs < MIN_RESUME_MS -> 0L
        isFinished(positionMs, durationMs) -> 0L
        else -> positionMs
    }

    fun progress(positionMs: Long, durationMs: Long): Float =
        if (durationMs <= 0) 0f else (positionMs.toFloat() / durationMs).coerceIn(0f, 1f)
}

object SeriesProgress {
    /**
     * The episode to offer as "Continue": the most recently watched one if unfinished, otherwise the one after it
     * (or the last one again), and the first episode when nothing was watched. [episodes] must be in watch order.
     */
    fun pickContinue(episodes: List<Episode>, progress: Map<Long, WatchHistory>): Episode? {
        if (episodes.isEmpty()) return null
        val latest = episodes.mapNotNull { e -> progress[e.id]?.let { e to it } }.maxByOrNull { it.second.updatedAt }
            ?: return episodes.first()
        val (episode, h) = latest
        if (!ResumePolicy.isFinished(h.positionMs, h.durationMs)) return episode
        return episodes.getOrNull(episodes.indexOf(episode) + 1) ?: episode
    }
}
