package app.iptv.core.domain.util

/** Up to three LIKE-escaped search terms; an empty term matches everything. Escape char is backslash. */
data class SearchTokens(val t1: String, val t2: String, val t3: String)

object SearchQuery {
    const val MIN_LENGTH = 2
    private val WHITESPACE = Regex("\\s+")

    /**
     * "bbc news hd" -> terms "bbc", "news", "hd": every term must appear in the title, in any order.
     * Words beyond the second are kept together as the third term. Returns null when the query is too short to search.
     */
    fun parse(raw: String): SearchTokens? {
        val words = raw.trim().split(WHITESPACE).filter { it.isNotEmpty() }
        if (words.isEmpty() || words.joinToString(" ").length < MIN_LENGTH) return null
        return SearchTokens(
            t1 = escape(words[0]),
            t2 = escape(words.getOrNull(1).orEmpty()),
            t3 = escape(words.drop(2).joinToString(" "))
        )
    }

    /** So that "100%" or "a_b" are searched literally instead of acting as SQL wildcards. */
    fun escape(s: String): String = s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
}
