package app.iptv.core.domain.util

import java.net.URLDecoder
import java.net.URLEncoder

/**
 * Stalker stream links are short-lived and tokenized, so channels store `stalker://itv/<encoded cmd>`.
 * The player resolves it right before playback (create_link) using the channel's playlist.
 */
object StalkerStreamUrl {
    private const val PREFIX = "stalker://itv/"
    fun encode(cmd: String) = PREFIX + URLEncoder.encode(cmd, "UTF-8")
    fun isStalker(url: String) = url.startsWith(PREFIX)
    fun decode(url: String): String = URLDecoder.decode(url.removePrefix(PREFIX), "UTF-8")
}
