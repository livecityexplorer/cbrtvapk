package app.iptv.core.domain.util

import java.net.URLDecoder
import java.net.URLEncoder

/**
 * Per-stream HTTP headers (from #EXTVLCOPT) are carried inside the stream URL using the
 * Kodi-style suffix:  `http://host/stream.m3u8|User-Agent=X&Referer=Y`  (values URL-encoded).
 * The player splits it back with [decode] before building the data source.
 */
object StreamHeaders {
    fun encode(url: String, headers: Map<String, String>): String =
        if (headers.isEmpty()) url
        else url + "|" + headers.entries.joinToString("&") { enc(it.key) + "=" + enc(it.value) }

    fun decode(raw: String): Pair<String, Map<String, String>> {
        val i = raw.lastIndexOf('|')
        if (i < 0) return raw to emptyMap()
        val tail = raw.substring(i + 1)
        if (!tail.contains('=') || tail.contains("://")) return raw to emptyMap()
        val headers = LinkedHashMap<String, String>()
        for (pair in tail.split('&')) {
            val eq = pair.indexOf('=')
            if (eq <= 0) continue
            headers[dec(pair.substring(0, eq))] = dec(pair.substring(eq + 1))
        }
        return raw.substring(0, i) to headers
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun dec(s: String) = URLDecoder.decode(s, "UTF-8")
}
