package app.iptv.core.domain.validation

import app.iptv.core.domain.model.Playlist
import app.iptv.core.domain.model.PlaylistType

enum class PlaylistField { NAME, URL, USERNAME, PASSWORD, MAC, EPG }
enum class ValidationError { REQUIRED, INVALID_URL, INVALID_MAC }

object PlaylistValidator {
    private val URL = Regex("""^[A-Za-z][A-Za-z0-9+.-]*://[^\s/?#]+([/?#]\S*)?$""")
    private val MAC = Regex("""^([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$""")

    fun validate(p: Playlist): Map<PlaylistField, ValidationError> {
        val e = LinkedHashMap<PlaylistField, ValidationError>()
        if (p.name.isBlank()) e[PlaylistField.NAME] = ValidationError.REQUIRED
        val url = p.url.trim()
        if (url.isEmpty()) e[PlaylistField.URL] = ValidationError.REQUIRED
        else if (!isValidUrl(url, allowLocalFile = p.type == PlaylistType.M3U)) e[PlaylistField.URL] = ValidationError.INVALID_URL
        when (p.type) {
            PlaylistType.XTREAM -> {
                if (p.username.isNullOrBlank()) e[PlaylistField.USERNAME] = ValidationError.REQUIRED
                if (p.password.isNullOrEmpty()) e[PlaylistField.PASSWORD] = ValidationError.REQUIRED
            }
            PlaylistType.STALKER -> {
                val mac = p.macAddress?.trim().orEmpty()
                if (mac.isEmpty()) e[PlaylistField.MAC] = ValidationError.REQUIRED
                else if (!MAC.matches(mac)) e[PlaylistField.MAC] = ValidationError.INVALID_MAC
            }
            PlaylistType.M3U -> Unit
        }
        if (p.epgUrls.any { it.isNotBlank() && !isValidUrl(it.trim(), allowLocalFile = false) }) {
            e[PlaylistField.EPG] = ValidationError.INVALID_URL
        }
        return e
    }

    /** http(s) address (scheme optional), or a content:// URI when [allowLocalFile]. */
    fun isValidUrl(raw: String, allowLocalFile: Boolean): Boolean {
        val u = raw.trim()
        if (u.startsWith("content://")) return allowLocalFile && URL.matches(u)
        val withScheme = if (u.contains("://")) u else "http://$u"
        val scheme = withScheme.substringBefore("://").lowercase()
        return (scheme == "http" || scheme == "https") && URL.matches(withScheme)
    }

    fun normalize(p: Playlist): Playlist = p.copy(
        name = p.name.trim(),
        url = normalizeUrl(p.url),
        username = p.username?.trim()?.takeIf { it.isNotEmpty() },
        password = p.password?.takeIf { it.isNotEmpty() },
        macAddress = p.macAddress?.trim()?.uppercase()?.replace('-', ':')?.takeIf { it.isNotEmpty() },
        epgUrls = p.epgUrls.map { normalizeUrl(it) }.filter { it.isNotEmpty() }.distinct()
    )

    private fun normalizeUrl(raw: String): String {
        val u = raw.trim()
        return if (u.isEmpty() || u.contains("://")) u else "http://$u"
    }
}
