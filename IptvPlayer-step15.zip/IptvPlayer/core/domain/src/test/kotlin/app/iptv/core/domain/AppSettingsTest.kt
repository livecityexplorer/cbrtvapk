package app.iptv.core.domain

import app.iptv.core.domain.model.*
import org.junit.Assert.*
import org.junit.Test

class AppSettingsTest {
    @Test fun mapsBufferAndDecoderOntoPlaybackConfig() {
        val c = AppSettings(bufferSize = BufferSize.LARGE, decoder = DecoderMode.SOFTWARE).toPlaybackConfig(PlaybackConfig(stallTimeoutMs = 30_000))
        assertEquals(BufferSize.LARGE.maxMs, c.maxBufferMs); assertTrue(c.preferSoftwareDecoder); assertEquals(30_000, c.stallTimeoutMs)
    }
    @Test fun bufferPresetsAreValidForExoLoadControl() {
        BufferSize.entries.forEach { assertTrue(it.startMs <= it.minMs && it.rebufferMs <= it.minMs && it.minMs <= it.maxMs) }
    }
    @Test fun noPinByDefault() = assertFalse(AppSettings().hasPin)
}
