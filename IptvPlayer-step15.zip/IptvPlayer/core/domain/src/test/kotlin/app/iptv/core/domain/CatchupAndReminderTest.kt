package app.iptv.core.domain

import app.iptv.core.domain.model.Channel
import app.iptv.core.domain.model.EpgProgram
import app.iptv.core.domain.util.Catchup
import app.iptv.core.domain.util.ReminderTiming
import org.junit.Assert.*
import org.junit.Test

class CatchupAndReminderTest {
    private val hour = 3_600_000L
    private val now = 1_704_110_400_000L
    private fun ch(archiveDays: Int) = Channel(1, 1, null, "1", "C", null, null, null, "u", 1, archiveDays, 0, false)
    private fun pr(start: Long, end: Long) = EpgProgram(channelTvgId = "c", title = "t", description = null, startTime = start, endTime = end)

    @Test fun catchupWindow() {
        assertTrue(Catchup.isAvailable(ch(3), pr(now - hour, now + hour), now))          // running now: watch from start
        assertTrue(Catchup.isAvailable(ch(3), pr(now - 71 * hour, now - 70 * hour), now)) // inside 3 days
        assertFalse(Catchup.isAvailable(ch(3), pr(now - 80 * hour, now - 79 * hour), now)) // too old
        assertFalse(Catchup.isAvailable(ch(3), pr(now + hour, now + 2 * hour), now))     // future
        assertFalse(Catchup.isAvailable(ch(0), pr(now - hour, now), now))                // no archive
    }

    @Test fun catchupDurationRoundsUp() {
        assertEquals(60, Catchup.durationMinutes(pr(0, hour)))
        assertEquals(31, Catchup.durationMinutes(pr(0, 30 * 60_000L + 1)))
        assertEquals(1, Catchup.durationMinutes(pr(0, 1)))
    }

    @Test fun reminderDelay() {
        assertEquals(8 * 60_000L, ReminderTiming.delayMillis(now + 10 * 60_000L, now))   // 2 min lead
        assertEquals(0L, ReminderTiming.delayMillis(now + 60_000L, now))                 // inside the lead window
        assertNull(ReminderTiming.delayMillis(now, now))                                 // already started
        assertNull(ReminderTiming.delayMillis(now - 1, now))
    }
}
