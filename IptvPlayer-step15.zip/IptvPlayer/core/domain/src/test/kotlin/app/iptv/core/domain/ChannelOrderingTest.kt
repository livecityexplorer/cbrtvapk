package app.iptv.core.domain

import app.iptv.core.domain.util.ChannelOrdering
import org.junit.Assert.*
import org.junit.Test

class ChannelOrderingTest {
    private val ids = listOf(10L, 20L, 30L, 40L)
    @Test fun movesUp() = assertEquals(listOf(10L, 30L, 20L, 40L), ChannelOrdering.move(ids, 30L, up = true))
    @Test fun movesDown() = assertEquals(listOf(20L, 10L, 30L, 40L), ChannelOrdering.move(ids, 10L, up = false))
    @Test fun edgesAndUnknownIdsDoNothing() {
        assertNull(ChannelOrdering.move(ids, 10L, up = true))
        assertNull(ChannelOrdering.move(ids, 40L, up = false))
        assertNull(ChannelOrdering.move(ids, 99L, up = true))
        assertNull(ChannelOrdering.move(emptyList(), 1L, up = false))
    }
    @Test fun doesNotMutateInput() { ChannelOrdering.move(ids, 20L, true); assertEquals(listOf(10L, 20L, 30L, 40L), ids) }
}
