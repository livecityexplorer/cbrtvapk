package app.iptv.core.domain

import app.iptv.core.domain.util.LayoutRect
import app.iptv.core.domain.util.MultiViewLayout
import org.junit.Assert.*
import org.junit.Test

class MultiViewLayoutTest {
    private fun overlap(a: LayoutRect, b: LayoutRect) =
        a.x < b.x + b.w - 0.001f && b.x < a.x + a.w - 0.001f && a.y < b.y + b.h - 0.001f && b.y < a.y + a.h - 0.001f

    @Test fun slotCounts() {
        assertEquals(0, MultiViewLayout.compute(0, 1920f, 1080f).size)
        (1..4).forEach { assertEquals(it, MultiViewLayout.compute(it, 1920f, 1080f, 8f).size) }
        assertEquals(4, MultiViewLayout.compute(9, 1920f, 1080f).size) // clamped
    }

    @Test fun singleFillsEverything() = assertEquals(listOf(LayoutRect(0f, 0f, 1920f, 1080f)), MultiViewLayout.compute(1, 1920f, 1080f))

    @Test fun twoAreSideBySide() {
        val (a, b) = MultiViewLayout.compute(2, 1920f, 1080f, 0f)
        assertEquals(960f, a.w, 0.01f); assertEquals(960f, b.x, 0.01f); assertEquals(1080f, b.h, 0.01f)
    }

    @Test fun threeHasOneLargeAndTwoStacked() {
        val r = MultiViewLayout.compute(3, 1800f, 1000f, 0f)
        assertEquals(1200f, r[0].w, 0.01f); assertEquals(1000f, r[0].h, 0.01f)
        assertEquals(600f, r[1].w, 0.01f); assertEquals(500f, r[1].h, 0.01f)
        assertEquals(500f, r[2].y, 0.01f)
    }

    @Test fun noOverlapAndInsideBoundsWithGaps() {
        for (n in 1..4) {
            val rects = MultiViewLayout.compute(n, 1920f, 1080f, 12f)
            rects.forEach { assertTrue(it.x >= 0 && it.y >= 0 && it.x + it.w <= 1920.01f && it.y + it.h <= 1080.01f) }
            for (i in rects.indices) for (j in i + 1 until rects.size) assertFalse("n=$n $i/$j", overlap(rects[i], rects[j]))
        }
    }
}
