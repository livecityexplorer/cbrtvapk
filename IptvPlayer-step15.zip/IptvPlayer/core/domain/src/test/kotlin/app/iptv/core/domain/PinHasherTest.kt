package app.iptv.core.domain

import app.iptv.core.domain.util.AdultFilter
import app.iptv.core.domain.util.PinHasher
import org.junit.Assert.*
import org.junit.Test

class PinHasherTest {
    @Test fun verifiesCorrectPinOnly() {
        val h = PinHasher.hash("1234")
        assertTrue(PinHasher.verify("1234", h)); assertFalse(PinHasher.verify("1235", h))
    }
    @Test fun saltMakesHashesDiffer() = assertNotEquals(PinHasher.hash("1234"), PinHasher.hash("1234"))
    @Test fun hashDoesNotContainPin() = assertFalse(PinHasher.hash("987654").contains("987654"))
    @Test fun rejectsMalformedStoredValues() {
        assertFalse(PinHasher.verify("1234", null)); assertFalse(PinHasher.verify("1234", "garbage"))
        assertFalse(PinHasher.verify("1234", "zz:zz"))
    }
    @Test fun pinValidation() {
        assertTrue(PinHasher.isValidPin("1234")); assertTrue(PinHasher.isValidPin("12345678"))
        assertFalse(PinHasher.isValidPin("123")); assertFalse(PinHasher.isValidPin("123456789")); assertFalse(PinHasher.isValidPin("12a4"))
    }
    @Test fun adultFilter() {
        assertTrue(AdultFilter.isAdult("XXX Movies")); assertTrue(AdultFilter.isAdult("Adults 18+"))
        assertTrue(AdultFilter.isAdult("PORN HD")); assertFalse(AdultFilter.isAdult("Sussex News")); assertFalse(AdultFilter.isAdult("Sports"))
    }
}
