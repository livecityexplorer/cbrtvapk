package app.iptv.core.domain

import app.iptv.core.domain.model.AspectMode
import app.iptv.core.domain.util.AspectMath
import app.iptv.core.domain.util.Backoff
import app.iptv.core.domain.util.SeekStepper
import app.iptv.core.domain.util.StreamFormat
import org.junit.Assert.*
import org.junit.Test

class PlayerMathTest {
    @Test fun backoffDoublesAndCaps() {
        assertEquals(listOf(1000L, 2000L, 4000L, 8000L, 16000L, 30000L, 30000L), (1..7).map { Backoff.delayMs(it) })
        assertEquals(500L, Backoff.delayMs(1, baseMs = 500))
        assertEquals(30_000L, Backoff.delayMs(500)) // no overflow for absurd attempt numbers
        assertEquals(1000L, Backoff.delayMs(0))
    }

    @Test fun seekStepGrowsWhileHeldAndResets() {
        var step = SeekStepper.next(0, 5_000)
        assertEquals(10_000L, step)
        step = SeekStepper.next(step, 200); assertEquals(30_000L, step)
        step = SeekStepper.next(step, 200); assertEquals(60_000L, step)
        step = SeekStepper.next(step, 200); assertEquals(120_000L, step)
        step = SeekStepper.next(step, 200); assertEquals(120_000L, step) // capped
        assertEquals(10_000L, SeekStepper.next(step, 1_500))             // pause between presses resets
    }

    @Test fun aspectModes() {
        val r43 = 4f / 3f
        assertEquals(1440f to 1080f, AspectMath.surfaceSize(1920f, 1080f, r43, AspectMode.FIT))
        assertEquals(1920f to 1440f, AspectMath.surfaceSize(1920f, 1080f, r43, AspectMode.ZOOM))
        assertEquals(1920f to 1080f, AspectMath.surfaceSize(1920f, 1080f, r43, AspectMode.STRETCH))
        assertEquals(1920f to 1080f, AspectMath.surfaceSize(1920f, 1080f, r43, AspectMode.RATIO_16_9)) // forced, regardless of video
        assertEquals(1440f to 1080f, AspectMath.surfaceSize(1920f, 1080f, 16f / 9f, AspectMode.RATIO_4_3))
        // 21:9 film on 16:9 screen: FIT letterboxes, ZOOM fills height
        val (fw, fh) = AspectMath.surfaceSize(1920f, 1080f, 21f / 9f, AspectMode.FIT)
        assertEquals(1920f, fw, 0.01f); assertTrue(fh < 1080f)
        val (zw, zh) = AspectMath.surfaceSize(1920f, 1080f, 21f / 9f, AspectMode.ZOOM)
        assertEquals(1080f, zh, 0.01f); assertTrue(zw > 1920f)
        assertEquals(1920f to 1080f, AspectMath.surfaceSize(1920f, 1080f, 0f, AspectMode.FIT)) // unknown video size
        assertEquals(0f to 0f, AspectMath.surfaceSize(0f, 0f, r43, AspectMode.FIT))
    }

    @Test fun streamFormatDetection() {
        assertEquals(StreamFormat.HLS, StreamFormat.detect("http://h/live/u/p/1.m3u8"))
        assertEquals(StreamFormat.HLS, StreamFormat.detect("http://h/x.m3u8?token=abc"))
        assertEquals(StreamFormat.HLS, StreamFormat.detect("http://h/hls/stream.m3u8/index"))
        assertEquals(StreamFormat.DASH, StreamFormat.detect("http://h/a.MPD"))
        assertEquals(StreamFormat.TS, StreamFormat.detect("http://h/live/u/p/1.ts"))
        assertEquals(StreamFormat.UNKNOWN, StreamFormat.detect("http://h:8000/play/a002"))
        assertEquals(StreamFormat.UNKNOWN, StreamFormat.detect("rtmp://h/live/stream"))
    }
}
