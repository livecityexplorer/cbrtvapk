package app.iptv.core.domain

import app.iptv.core.domain.model.Recording
import app.iptv.core.domain.model.RecordingStatus
import app.iptv.core.domain.repository.InvalidReason
import app.iptv.core.domain.util.RecordingConflicts
import app.iptv.core.domain.util.RecordingNaming
import app.iptv.core.domain.util.RecordingPolicy
import app.iptv.core.domain.util.RecordingUrl
import org.junit.Assert.*
import org.junit.Test
import java.util.TimeZone

class RecordingUtilTest {
    private val hour = 3_600_000L
    private val now = 1_704_110_400_000L // 2024-01-01T12:00:00Z

    @Test fun validation() {
        assertNull(RecordingPolicy.validate(now + hour, now + 2 * hour, now))
        assertNull(RecordingPolicy.validate(now - hour, now + hour, now))                       // already running: fine
        assertEquals(InvalidReason.ALREADY_ENDED, RecordingPolicy.validate(now - 2 * hour, now - hour, now))
        assertEquals(InvalidReason.ALREADY_ENDED, RecordingPolicy.validate(now - hour, now, now))
        assertEquals(InvalidReason.TOO_LONG, RecordingPolicy.validate(now, now + 13 * hour, now))
        assertEquals(60_000L + now, RecordingPolicy.stopAt(now))
    }

    private fun rec(id: Long, start: Long, end: Long, status: RecordingStatus = RecordingStatus.SCHEDULED) =
        Recording(id, 1, "c", "t", "u", start, end, status)

    @Test fun conflicts() {
        val existing = listOf(
            rec(1, now, now + hour), rec(2, now + 2 * hour, now + 3 * hour),
            rec(3, now, now + 3 * hour, RecordingStatus.COMPLETED), rec(4, now, now + hour, RecordingStatus.CANCELLED)
        )
        assertEquals(listOf(1L), RecordingConflicts.overlapping(existing, now + hour / 2, now + 2 * hour).map { it.id })
        assertEquals(listOf(1L, 2L), RecordingConflicts.overlapping(existing, now, now + 3 * hour).map { it.id })
        assertTrue(RecordingConflicts.overlapping(existing, now + hour, now + 2 * hour).isEmpty()) // touching ends don't overlap
    }

    @Test fun fileNames() {
        val utc = TimeZone.getTimeZone("UTC")
        assertEquals("BBC One - News at Six 20240101_1200.ts", RecordingNaming.fileName("BBC One", "News at Six", now, utc))
        assertEquals("A_B - C_D_ 20240101_1200.ts", RecordingNaming.fileName("A/B", "C:D?", now, utc))
        assertEquals("Recording 20240101_1200.ts", RecordingNaming.fileName("", "  ", now, utc))
        assertEquals("X - Y 20240101_1200.ts", RecordingNaming.fileName("X", "Y\n\t", now, utc))
        assertTrue(RecordingNaming.fileName("x".repeat(300), "", now, utc).length < 130)
    }

    @Test fun preferTsOnlyRewritesXtreamLiveHls() {
        assertEquals("http://h:80/live/u/p/123.ts", RecordingUrl.preferTs("http://h:80/live/u/p/123.m3u8"))
        assertEquals("http://h/live/u/p/9.ts?x=1", RecordingUrl.preferTs("http://h/live/u/p/9.m3u8?x=1"))
        assertEquals("http://h/other/stream.m3u8", RecordingUrl.preferTs("http://h/other/stream.m3u8"))
        assertEquals("http://h/live/u/p/1.ts", RecordingUrl.preferTs("http://h/live/u/p/1.ts"))
        assertTrue(RecordingUrl.isHls("http://h/a.M3U8?t=1")); assertFalse(RecordingUrl.isHls("http://h/a.ts"))
    }
}
