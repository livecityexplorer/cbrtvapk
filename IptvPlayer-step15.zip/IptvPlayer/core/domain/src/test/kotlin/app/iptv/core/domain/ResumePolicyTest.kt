package app.iptv.core.domain

import app.iptv.core.domain.model.ContentType
import app.iptv.core.domain.model.Episode
import app.iptv.core.domain.model.WatchHistory
import app.iptv.core.domain.util.ResumePolicy
import app.iptv.core.domain.util.SeriesProgress
import org.junit.Assert.*
import org.junit.Test

class ResumePolicyTest {
    private val hour = 3_600_000L

    @Test fun startPosition() {
        assertEquals(0L, ResumePolicy.startPosition(5_000, hour))          // barely started
        assertEquals(30 * 60_000L, ResumePolicy.startPosition(30 * 60_000L, hour))
        assertEquals(0L, ResumePolicy.startPosition(hour - 1_000, hour))   // finished -> start over
        assertEquals(0L, ResumePolicy.startPosition(50_000, 0))            // unknown duration
        assertEquals(0L, ResumePolicy.startPosition(95 * hour / 100, hour)) // exactly 95% counts as finished
    }

    @Test fun finishedAndProgress() {
        assertTrue(ResumePolicy.isFinished(96, 100)); assertFalse(ResumePolicy.isFinished(94, 100)); assertFalse(ResumePolicy.isFinished(1, 0))
        assertEquals(0.5f, ResumePolicy.progress(50, 100), 0.001f)
        assertEquals(1f, ResumePolicy.progress(500, 100), 0.001f)
        assertEquals(0f, ResumePolicy.progress(5, 0), 0.001f)
    }

    private fun ep(id: Long, season: Int, n: Int) = Episode(id, 1, season, n, "e$id", null, null, "u", 3000)
    private fun h(epId: Long, pos: Long, dur: Long, at: Long) =
        WatchHistory(1, ContentType.EPISODE, epId.toString(), 1, "t", null, "u", pos, dur, at)

    private val episodes = listOf(ep(1, 1, 1), ep(2, 1, 2), ep(3, 1, 3), ep(4, 2, 1))

    @Test fun continueFirstWhenNothingWatched() = assertEquals(1L, SeriesProgress.pickContinue(episodes, emptyMap())?.id)

    @Test fun continueUnfinishedLatest() {
        val p = mapOf(1L to h(1, 100, 100, 10), 2L to h(2, 40, 100, 20))
        assertEquals(2L, SeriesProgress.pickContinue(episodes, p)?.id)
    }

    @Test fun continueNextAfterFinishedLatest() {
        val p = mapOf(1L to h(1, 99, 100, 10), 2L to h(2, 98, 100, 20))
        assertEquals(3L, SeriesProgress.pickContinue(episodes, p)?.id)
        // crosses into the next season
        assertEquals(4L, SeriesProgress.pickContinue(episodes, mapOf(3L to h(3, 99, 100, 30)))?.id)
    }

    @Test fun lastEpisodeFinishedOffersItAgain() =
        assertEquals(4L, SeriesProgress.pickContinue(episodes, mapOf(4L to h(4, 99, 100, 30)))?.id)

    @Test fun emptyList() = assertNull(SeriesProgress.pickContinue(emptyList(), emptyMap()))
}
