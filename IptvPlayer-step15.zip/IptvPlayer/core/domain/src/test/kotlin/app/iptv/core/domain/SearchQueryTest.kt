package app.iptv.core.domain

import app.iptv.core.domain.util.SearchQuery
import app.iptv.core.domain.util.SearchTokens
import org.junit.Assert.*
import org.junit.Test

class SearchQueryTest {
    @Test fun tooShortOrBlankIsNotSearched() {
        assertNull(SearchQuery.parse("")); assertNull(SearchQuery.parse("   ")); assertNull(SearchQuery.parse("a")); assertNull(SearchQuery.parse(" a "))
        assertNotNull(SearchQuery.parse("ab"))
    }

    @Test fun splitsIntoTermsAndIgnoresExtraWhitespace() {
        assertEquals(SearchTokens("bbc", "", ""), SearchQuery.parse("  bbc "))
        assertEquals(SearchTokens("bbc", "news", ""), SearchQuery.parse("bbc   news"))
        assertEquals(SearchTokens("sky", "sports", "premier league"), SearchQuery.parse("sky sports premier league"))
    }

    @Test fun likeWildcardsAreEscaped() {
        assertEquals(SearchTokens("100\\%", "a\\_b", ""), SearchQuery.parse("100% a_b"))
        assertEquals("a\\\\b", SearchQuery.escape("a\\b"))
    }
}
