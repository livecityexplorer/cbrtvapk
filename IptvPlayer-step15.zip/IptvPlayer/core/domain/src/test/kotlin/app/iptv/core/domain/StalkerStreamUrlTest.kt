package app.iptv.core.domain

import app.iptv.core.domain.util.StalkerStreamUrl
import org.junit.Assert.*
import org.junit.Test

class StalkerStreamUrlTest {
    @Test fun roundTrip() {
        val cmd = "ffrt http://localhost/ch/11?x=1&y=ä"
        val url = StalkerStreamUrl.encode(cmd)
        assertTrue(StalkerStreamUrl.isStalker(url))
        assertEquals(cmd, StalkerStreamUrl.decode(url))
    }
    @Test fun plainUrlsAreNotStalker() = assertFalse(StalkerStreamUrl.isStalker("http://h/live/1.ts"))
}
