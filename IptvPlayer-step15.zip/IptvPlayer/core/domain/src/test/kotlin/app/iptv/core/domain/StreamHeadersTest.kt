package app.iptv.core.domain

import app.iptv.core.domain.util.EpgKey
import app.iptv.core.domain.util.StreamHeaders
import org.junit.Assert.assertEquals
import org.junit.Test

class StreamHeadersTest {
    @Test fun roundTrip() {
        val enc = StreamHeaders.encode("http://h/s.m3u8", mapOf("User-Agent" to "My Agent/1.0", "Referer" to "http://r.example/?a=1&b=2"))
        val (url, h) = StreamHeaders.decode(enc)
        assertEquals("http://h/s.m3u8", url)
        assertEquals("My Agent/1.0", h["User-Agent"])
        assertEquals("http://r.example/?a=1&b=2", h["Referer"])
    }
    @Test fun plainUrlUntouched() {
        assertEquals("http://h/s.ts" to emptyMap<String, String>(), StreamHeaders.decode("http://h/s.ts"))
    }
    @Test fun pipeInsideUrlIsNotHeaders() {
        val raw = "http://h/a|http://h/b"
        assertEquals(raw to emptyMap<String, String>(), StreamHeaders.decode(raw))
    }
    @Test fun epgKey() {
        assertEquals("bbc1.uk", EpgKey.of(" BBC1.UK ", null, "x"))
        assertEquals("name:bbcone", EpgKey.of(null, "BBC One", "ignored"))
        assertEquals("name:bbcone", EpgKey.of("", null, "BBC-One!"))
    }
}
