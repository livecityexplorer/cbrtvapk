package app.iptv.core.domain.sync

import app.iptv.core.domain.error.IptvError
import app.iptv.core.domain.model.Playlist
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class SyncManagerTest {
    private class FakeSyncer(val body: suspend kotlinx.coroutines.flow.FlowCollector<SyncState>.() -> Unit) : PlaylistSyncer {
        var starts = 0
        override fun sync(playlistId: Long): Flow<SyncState> = flow { starts++; body() }
        override suspend fun testConnection(draft: Playlist) = ConnectionInfo()
    }

    @Test fun tracksProgressAndIgnoresDuplicateRuns() = runTest(UnconfinedTestDispatcher()) {
        val gate = CompletableDeferred<Unit>()
        val syncer = FakeSyncer { emit(SyncState.Running(SyncStage.LIVE, 10)); gate.await(); emit(SyncState.Success(SyncSummary(10, 0, 0, 1))) }
        val m = SyncManager(syncer, backgroundScope)
        m.sync(1L); m.sync(1L)
        assertEquals(1, syncer.starts)
        assertEquals(SyncState.Running(SyncStage.LIVE, 10), m.states.value[1L])
        gate.complete(Unit)
        assertEquals(SyncState.Success(SyncSummary(10, 0, 0, 1)), m.states.value[1L])
    }

    @Test fun canResyncAfterFinishing() = runTest(UnconfinedTestDispatcher()) {
        val syncer = FakeSyncer { emit(SyncState.Failed(IptvError.Network())) }
        val m = SyncManager(syncer, backgroundScope)
        m.sync(1L); m.sync(1L)
        assertEquals(2, syncer.starts)
        assertTrue(m.states.value[1L] is SyncState.Failed)
    }

    @Test fun unexpectedExceptionBecomesFailedState() = runTest(UnconfinedTestDispatcher()) {
        val m = SyncManager(FakeSyncer { throw IllegalStateException("boom") }, backgroundScope)
        m.sync(2L)
        val s = m.states.value[2L] as SyncState.Failed
        assertTrue(s.error is IptvError.Unknown)
    }

    @Test fun cancelClearsState() = runTest(UnconfinedTestDispatcher()) {
        val gate = CompletableDeferred<Unit>()
        val m = SyncManager(FakeSyncer { emit(SyncState.Running(SyncStage.CONNECTING)); gate.await() }, backgroundScope)
        m.sync(3L)
        assertNotNull(m.states.value[3L])
        m.cancel(3L)
        assertNull(m.states.value[3L])
    }
}
