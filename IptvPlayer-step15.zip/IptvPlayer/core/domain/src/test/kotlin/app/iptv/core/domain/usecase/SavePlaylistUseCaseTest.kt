package app.iptv.core.domain.usecase

import app.iptv.core.domain.model.Playlist
import app.iptv.core.domain.model.PlaylistType
import app.iptv.core.domain.repository.PlaylistRepository
import app.iptv.core.domain.validation.PlaylistField
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class SavePlaylistUseCaseTest {
    private class FakeRepo : PlaylistRepository {
        val saved = mutableListOf<Playlist>()
        override fun observeAll(): Flow<List<Playlist>> = flowOf(emptyList())
        override suspend fun get(id: Long): Playlist? = null
        override suspend fun save(playlist: Playlist): Long { saved += playlist; return 7L }
        override suspend fun delete(id: Long) = Unit
        override suspend fun markRefreshed(id: Long, timestamp: Long) = Unit
    }

    @Test fun invalidDraftIsRejectedAndNotSaved() {
        val repo = FakeRepo()
        val r = runBlocking { SavePlaylistUseCase(repo)(Playlist(name = "", type = PlaylistType.XTREAM, url = "host")) }
        assertTrue(r is SaveResult.Invalid)
        assertTrue(PlaylistField.NAME in (r as SaveResult.Invalid).errors && PlaylistField.USERNAME in r.errors)
        assertTrue(repo.saved.isEmpty())
    }

    @Test fun validDraftIsNormalizedAndSaved() {
        val repo = FakeRepo()
        val r = runBlocking { SavePlaylistUseCase(repo)(Playlist(name = " Box ", type = PlaylistType.M3U, url = "a.b/l.m3u")) }
        assertEquals(7L, (r as SaveResult.Saved).id)
        assertEquals("http://a.b/l.m3u", repo.saved.single().url)
        assertEquals("Box", repo.saved.single().name)
    }
}
