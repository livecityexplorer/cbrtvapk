package app.iptv.core.domain.validation

import app.iptv.core.domain.model.Playlist
import app.iptv.core.domain.model.PlaylistType
import app.iptv.core.domain.model.PlaylistType.*
import org.junit.Assert.*
import org.junit.Test

class PlaylistValidatorTest {
    private fun p(type: PlaylistType = M3U, name: String = "My list", url: String = "http://a.b/list.m3u", user: String? = null,
                  pass: String? = null, mac: String? = null, epg: List<String> = emptyList()) =
        Playlist(name = name, type = type, url = url, username = user, password = pass, macAddress = mac, epgUrls = epg)

    @Test fun validM3u() = assertTrue(PlaylistValidator.validate(p()).isEmpty())

    @Test fun nameAndUrlRequired() {
        val e = PlaylistValidator.validate(p(name = " ", url = ""))
        assertEquals(ValidationError.REQUIRED, e[PlaylistField.NAME])
        assertEquals(ValidationError.REQUIRED, e[PlaylistField.URL])
    }

    @Test fun urlRules() {
        assertTrue(PlaylistValidator.isValidUrl("a.b/list.m3u", false))          // scheme optional
        assertTrue(PlaylistValidator.isValidUrl("https://host:8080/x?y=1", false))
        assertTrue(PlaylistValidator.isValidUrl("my_host:80", false))            // underscores in host
        assertFalse(PlaylistValidator.isValidUrl("ftp://a.b/x", false))
        assertFalse(PlaylistValidator.isValidUrl("http://", false))
        assertFalse(PlaylistValidator.isValidUrl("http://a b", false))
        assertFalse(PlaylistValidator.isValidUrl("javascript://x", false))
    }

    @Test fun localFilesAllowedOnlyForM3u() {
        assertTrue(PlaylistValidator.validate(p(url = "content://com.android.providers/doc/12")).isEmpty())
        assertEquals(ValidationError.INVALID_URL, PlaylistValidator.validate(p(XTREAM, url = "content://x/1", user = "u", pass = "p"))[PlaylistField.URL])
    }

    @Test fun xtreamNeedsCredentials() {
        val e = PlaylistValidator.validate(p(XTREAM, url = "host:8080"))
        assertEquals(ValidationError.REQUIRED, e[PlaylistField.USERNAME])
        assertEquals(ValidationError.REQUIRED, e[PlaylistField.PASSWORD])
        assertTrue(PlaylistValidator.validate(p(XTREAM, url = "host:8080", user = "u", pass = "p")).isEmpty())
    }

    @Test fun stalkerNeedsValidMac() {
        assertEquals(ValidationError.REQUIRED, PlaylistValidator.validate(p(STALKER))[PlaylistField.MAC])
        assertEquals(ValidationError.INVALID_MAC, PlaylistValidator.validate(p(STALKER, mac = "00:1A:79"))[PlaylistField.MAC])
        assertTrue(PlaylistValidator.validate(p(STALKER, mac = "00-1a-79-aa-bb-cc")).isEmpty())
    }

    @Test fun invalidEpgUrlIsFlagged() {
        assertEquals(ValidationError.INVALID_URL, PlaylistValidator.validate(p(epg = listOf("http://ok/x.xml", "not a url")))[PlaylistField.EPG])
        assertTrue(PlaylistValidator.validate(p(epg = listOf("", "http://ok/x.xml"))).isEmpty())
    }

    @Test fun normalizeCleansInput() {
        val n = PlaylistValidator.normalize(
            p(STALKER, name = "  Box ", url = " host/c ", mac = "00-1a-79-aa-bb-cc", epg = listOf(" a.b/e.xml ", "", "http://a.b/e.xml", "a.b/e.xml"))
        )
        assertEquals("Box", n.name); assertEquals("http://host/c", n.url); assertEquals("00:1A:79:AA:BB:CC", n.macAddress)
        assertEquals(listOf("http://a.b/e.xml"), n.epgUrls)
        assertEquals("", PlaylistValidator.normalize(p(url = "  ")).url) // blank stays blank so it is reported as REQUIRED
    }
}
