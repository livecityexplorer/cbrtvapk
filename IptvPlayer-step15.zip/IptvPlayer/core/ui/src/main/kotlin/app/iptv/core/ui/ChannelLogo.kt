package app.iptv.core.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import coil.compose.SubcomposeAsyncImage

/** Channel logo with initials as placeholder / error fallback. */
@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun ChannelLogo(url: String?, name: String, modifier: Modifier = Modifier) {
    val initials = remember(name) {
        name.split(' ', '-', '_').filter { it.isNotBlank() }.take(2).joinToString("") { it.first().uppercaseChar().toString() }.ifEmpty { "?" }
    }
    Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
        if (url.isNullOrBlank()) Text(initials, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        else SubcomposeAsyncImage(
            model = url, contentDescription = name, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize().padding(4.dp),
            loading = { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(initials, color = MaterialTheme.colorScheme.onSurfaceVariant) } },
            error = { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(initials, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
        )
    }
}
