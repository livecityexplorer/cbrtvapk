package app.iptv.core.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.launch

private const val MAX_PIN = 8
private const val MIN_PIN = 4

/**
 * PIN entry with an on-screen keypad (works with a D-pad, no soft keyboard needed).
 * [onSubmit] returns true when the PIN was accepted (dialog then calls [onSuccess]); false shows an error and clears the input.
 * Pass [errorText] to customise the message (e.g. "PINs do not match").
 */
@Composable
fun PinDialog(
    title: String,
    onSubmit: suspend (String) -> Boolean,
    onSuccess: () -> Unit,
    onDismiss: () -> Unit,
    subtitle: String? = null,
    errorText: String = stringResource(R.string.pin_wrong)
) {
    var pin by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val firstKey = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { firstKey.requestFocus() } }

    fun submit() {
        if (busy || pin.length < MIN_PIN) return
        busy = true
        scope.launch {
            val ok = onSubmit(pin)
            busy = false
            if (ok) onSuccess() else { error = true; pin = "" }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = MaterialTheme.shapes.extraLarge, tonalElevation = 6.dp) {
            Column(Modifier.padding(24.dp).width(280.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(title, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
                subtitle?.let { Text(it, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center) }
                Text(
                    if (pin.isEmpty()) "–" else "●".repeat(pin.length),
                    style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center, modifier = Modifier.height(40.dp)
                )
                if (error) Text(errorText, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "⌫", "0", "OK")
                keys.chunked(3).forEachIndexed { rowIdx, row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEachIndexed { colIdx, k ->
                            FilledTonalButton(
                                onClick = {
                                    error = false
                                    when (k) {
                                        "⌫" -> pin = pin.dropLast(1)
                                        "OK" -> submit()
                                        else -> if (pin.length < MAX_PIN) pin += k
                                    }
                                },
                                modifier = Modifier.weight(1f).then(if (rowIdx == 0 && colIdx == 1) Modifier.focusRequester(firstKey) else Modifier),
                                contentPadding = PaddingValues(0.dp)
                            ) { Text(k) }
                        }
                    }
                }
                TextButton(onClick = onDismiss) { Text(stringResource(R.string.pin_cancel)) }
            }
        }
    }
}
