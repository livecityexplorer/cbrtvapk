package app.iptv.core.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.paging.LoadState
import androidx.paging.compose.LazyPagingItems
import androidx.paging.compose.itemKey
import androidx.tv.material3.*
import androidx.compose.material3.Text as M3Text

data class BrowseCategory(val id: Long, val name: String)

data class BrowseLabels(
    val allCategories: String,
    val search: String,
    val continueWatching: String,
    /** Shown when a category/playlist has no titles. */
    val empty: String,
    /** Contains one %s for the search text. */
    val noMatch: String,
    val loadError: String,
    val retry: String
)

/**
 * Category sidebar + search + optional "continue watching" row + poster grid. Shared by Movies and Series.
 * Focus: starts in the sidebar; after returning from a detail/player screen focus goes back to the poster you left.
 */
@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun PosterBrowse(
    categories: List<BrowseCategory>, selectedCategoryId: Long?, onSelectCategory: (Long?) -> Unit,
    query: String, onQueryChange: (String) -> Unit,
    items: LazyPagingItems<PosterItem>, continueWatching: List<PosterItem>,
    onOpen: (PosterItem) -> Unit, onOpenContinue: (PosterItem) -> Unit,
    labels: BrowseLabels
) {
    val sidebarFocus = remember { FocusRequester() }
    var focusedKey by rememberSaveable { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { if (focusedKey == null) try { sidebarFocus.requestFocus() } catch (e: Exception) { } }

    Row(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.width(260.dp).fillMaxHeight().padding(start = 24.dp, top = 24.dp, bottom = 24.dp, end = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            item {
                SidebarEntry(labels.allCategories, selectedCategoryId == null, { onSelectCategory(null); focusedKey = null },
                    if (selectedCategoryId == null) Modifier.focusRequester(sidebarFocus) else Modifier)
            }
            items(categories, key = { it.id }) { c ->
                val selected = selectedCategoryId == c.id
                SidebarEntry(c.name, selected, { onSelectCategory(c.id); focusedKey = null }, if (selected) Modifier.focusRequester(sidebarFocus) else Modifier)
            }
        }

        Column(Modifier.weight(1f).fillMaxHeight().padding(24.dp)) {
            OutlinedTextField(
                value = query, onValueChange = { onQueryChange(it); focusedKey = null }, singleLine = true,
                modifier = Modifier.fillMaxWidth(), label = { M3Text(labels.search) }
            )
            Spacer(Modifier.height(12.dp))

            if (continueWatching.isNotEmpty() && query.isBlank()) {
                Text(labels.continueWatching, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 4.dp)) {
                    items(continueWatching, key = { it.id }) { PosterCard(it, onClick = { onOpenContinue(it) }, modifier = Modifier.width(120.dp)) }
                }
                Spacer(Modifier.height(12.dp))
            }

            val gridKey = "${selectedCategoryId}|${query.trim()}"
            key(gridKey) {
                var lastIndex by rememberSaveable { mutableIntStateOf(0) }
                val restorer = remember { FocusRequester() }
                var restored by remember { mutableStateOf(false) }
                val shouldRestore = focusedKey == gridKey
                val refresh = items.loadState.refresh

                LaunchedEffect(items.itemCount, shouldRestore) {
                    if (!restored && shouldRestore && lastIndex < items.itemCount) {
                        val ok = try { restorer.requestFocus(); true } catch (e: Exception) { false }
                        if (ok) restored = true
                    }
                }

                when {
                    refresh is LoadState.Error && items.itemCount == 0 -> Column(
                        Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(labels.loadError, color = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { items.retry() }) { Text(labels.retry) }
                    }
                    refresh is LoadState.Loading && items.itemCount == 0 ->
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    items.itemCount == 0 -> Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text(if (query.isNotBlank()) labels.noMatch.replace("%s", query.trim()) else labels.empty, style = MaterialTheme.typography.bodyLarge)
                    }
                    else -> LazyVerticalGrid(
                        columns = GridCells.Adaptive(150.dp), modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(items.itemCount, key = items.itemKey { it.id }) { index ->
                            val item = items[index] ?: return@items
                            var mod: Modifier = Modifier
                            if (index == lastIndex) mod = mod.focusRequester(restorer)
                            PosterCard(item, onClick = { onOpen(item) }, modifier = mod.onFocusChanged {
                                if (it.hasFocus) { lastIndex = index; focusedKey = gridKey }
                            })
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun SidebarEntry(label: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier) {
    Card(
        onClick = onClick, modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.colors(containerColor = if (selected) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent)
    ) {
        Text(label, Modifier.padding(horizontal = 16.dp, vertical = 12.dp), style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** State shared by the Movies and Series screens' ViewModels. */
data class BrowseState(
    val loading: Boolean = true,
    val hasPlaylist: Boolean = false,
    val categories: List<BrowseCategory> = emptyList(),
    val categoryId: Long? = null
)

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun CenteredMessage(title: String, message: String? = null, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (onAction != null) try { focus.requestFocus() } catch (e: Exception) { } }
    Column(Modifier.fillMaxSize().padding(48.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, style = MaterialTheme.typography.headlineMedium)
        if (message != null) { Spacer(Modifier.height(8.dp)); Text(message, style = MaterialTheme.typography.bodyLarge) }
        if (actionLabel != null && onAction != null) {
            Spacer(Modifier.height(24.dp))
            Button(onClick = onAction, modifier = Modifier.focusRequester(focus)) { Text(actionLabel) }
        }
    }
}

@Composable
fun CenteredLoading() = Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
